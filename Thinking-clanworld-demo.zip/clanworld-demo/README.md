# ClanWorld Demo

A mobile-first 8-bit autonomous-agent strategy game demo for the OpenAgents hackathon concept.

The demo is intentionally playable in **mock mode** so the visual world, Elder control, logs, and phase screenshots work before contracts are deployed.

## What is included

- pnpm monorepo
- Vite + React frontend
- Phaser 3 world map embedded in React
- Mobile-first HUD and pixel UI chrome
- Mock game state independent of contracts
- Elder control page for persistent strategy fields and God → AXL whispers
- Clan dashboard and logs view
- Placeholder sprite sheets generated locally
- Art direction docs for replacing placeholder sprites with real Imagegen assets
- Minimal contract skeleton for the eventual game engine
- Playwright screenshot script plus fallback screenshot artifacts

## Install and run

```bash
corepack enable
pnpm install
pnpm dev
```

## Build

```bash
pnpm build
```

## Screenshots

Preferred after dependencies install:

```bash
pnpm screenshots
```

Fallback screenshots are already included in `artifacts/screenshots`.

## Monorepo layout

```text
apps/web                 React + Phaser frontend
packages/shared          Shared TS types/mock model
packages/contracts       Solidity skeleton
packages/agent-skills    Elder prompt/CLAUDE.md template
artifacts/screenshots    Captured review screenshots
```

## Phase coverage

### Phase 1 — World Map
Full world visible on mobile, HUD overlay, resource row, workers, homebases, bandit camp.

### Phase 2 — Contract Data Wiring
Mock data adapter and shared types mirror contract-facing state model, ready to replace with viem reads.

### Phase 3 — Elder Control
Persistent strategy fields, CLAUDE.md-style doctrine blocks, Divine Whisper message form, AXL-style logs.

### Phase 4 — Live Demo Events
Independent mock event timeline, bandit alert, AXL mercenary message, market watcher worker, log dashboard.

## Notes

The source app uses Phaser 3 inside React. In this sandbox, pnpm/npm installs hung, so I could not install dependencies or run the real Vite/Phaser build here. The repo itself is set up to run normally with pnpm in a regular dev environment.
