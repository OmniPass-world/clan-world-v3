export type RegionId = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8;

export const REGIONS: Record<RegionId, { name: string; kind: string; x: number; y: number }> = {
  1: { name: 'Forest', kind: 'wood', x: 0, y: 0 },
  2: { name: 'Mountains', kind: 'iron', x: 2, y: 0 },
  3: { name: 'Unicorn Town', kind: 'market', x: 1, y: 1 },
  4: { name: 'West Farmland', kind: 'wheat', x: 0, y: 2 },
  5: { name: 'East Farmland', kind: 'wheat', x: 2, y: 2 },
  6: { name: 'West Docks', kind: 'fish', x: 0, y: 3 },
  7: { name: 'East Docks', kind: 'fish', x: 2, y: 3 },
  8: { name: 'Deep Sea', kind: 'fish', x: 1, y: 4 }
};

export type ResourceKey = 'wood' | 'wheat' | 'fish' | 'iron' | 'gold' | 'blueprint';

export interface Resources {
  wood: number;
  wheat: number;
  fish: number;
  iron: number;
  gold: number;
  blueprint: number;
}

export interface WorkerState {
  id: string;
  clan: string;
  regionId: RegionId;
  mission: string;
  carry: Partial<Resources>;
  cooldownSec: number;
  status: 'waiting' | 'traveling' | 'acting' | 'defending';
}

export interface ClanState {
  id: string;
  name: string;
  color: 'red' | 'blue' | 'green' | 'yellow';
  baseRegionId: RegionId;
  baseLevel: number;
  wallLevel: number;
  monumentLevel: number;
  vault: Resources;
  workers: WorkerState[];
}

export interface GameSnapshot {
  tick: number;
  seasonEndTick: number;
  winterIn: number;
  banditStatus: string;
  selectedClanId: string;
  clans: ClanState[];
  messages: Array<{ id: string; kind: 'god' | 'axl' | 'system' | 'trade'; from: string; text: string; tick: number }>;
}
