# ClanWorld Pixel-Art Direction

Style: polished 8-bit / early SNES fantasy strategy map. Crisp nearest-neighbor pixels, no anti-aliasing, strong silhouettes, readable on phones.

## Sprite scale
- Terrain tile display cell: 48x48 logical pixels
- Worker sprite frame: 24x32 px
- Wheelbarrow overlay: 24x16 px
- Base / wall / monument objects: 48x48 px
- Bandit camp: 48x48 px
- Resource icon: 16x16 px

## Character sheet frames needed
For each clan color red/yellow/blue/green:
- idle down/up/left/right
- walk down/up/left/right, 2 frames each
- push empty wheelbarrow, 5 directions
- push half/full wheelbarrow of wood/wheat/fish/iron
- chop wood, 2 frames
- mine iron, 2 frames
- fish, 2 frames
- harvest wheat, 2 frames
- defend shield/sword, 2 frames
- build hammering, 2 frames
- praying/monument worship, 2 frames
- winter cloak variant
- starving/frostbite variant
- frozen x-eyes dead variant

## Object sheet frames needed
- homebase levels 1-5
- wall levels 0-5
- monument levels 0-10
- bandit camp 2-frame flame loop
- bandit troop 2-frame walk
- dock/fishing props
- market stall, unicorn sign, coin sparkle
- resource piles: wood/wheat/fish/iron/gold/blueprint
