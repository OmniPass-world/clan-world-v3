import { test, expect } from '@playwright/test';

const shots = [
  ['phase-1-world', '/'],
  ['phase-2-clan', '/?tab=clan'],
  ['phase-3-elder', '/?tab=elder'],
  ['phase-4-logs', '/?tab=logs']
] as const;

test.describe('ClanWorld visual happy path', () => {
  for (const [name, url] of shots) {
    test(`capture ${name}`, async ({ page }) => {
      await page.goto(url);
      await page.waitForTimeout(800);
      await expect(page.locator('body')).toBeVisible();
      await page.screenshot({ path: `../../artifacts/screenshots/${name}.png`, fullPage: true });
    });
  }
});
