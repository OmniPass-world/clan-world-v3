#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"
HTML="file://$ROOT/apps/web/static-preview.html"
OUT="$ROOT/artifacts/screenshots"
mkdir -p "$OUT"
CHROME="${CHROME:-/usr/bin/chromium}"
for view in world clan elder logs; do
  case "$view" in
    world) name="phase-1-world";;
    clan) name="phase-2-clan";;
    elder) name="phase-3-elder";;
    logs) name="phase-4-logs";;
  esac
  "$CHROME" --headless --disable-gpu --no-sandbox --window-size=390,844 --screenshot="$OUT/$name.png" "$HTML?view=$view" >/dev/null 2>&1
  echo "Captured $OUT/$name.png"
done
