import Phaser from 'phaser';
import { mockGame } from '../data/mockGame';

const regionLayout = [
  { id: 1, name: 'Forest', x: 118, y: 96, color: 0x285f34 },
  { id: 2, name: 'Mountains', x: 522, y: 96, color: 0x59636b },
  { id: 3, name: 'Unicorn Town', x: 320, y: 236, color: 0xbe5bd6 },
  { id: 4, name: 'West Farms', x: 118, y: 376, color: 0xb58637 },
  { id: 5, name: 'East Farms', x: 522, y: 376, color: 0xc9a24a },
  { id: 6, name: 'West Docks', x: 118, y: 520, color: 0x2f6f9f },
  { id: 7, name: 'East Docks', x: 522, y: 520, color: 0x317cae },
  { id: 8, name: 'Deep Sea', x: 320, y: 658, color: 0x183f8c }
];

export class ClanWorldScene extends Phaser.Scene {
  private selected?: number;

  constructor() {
    super('ClanWorldScene');
  }

  preload() {
    this.load.image('terrain', '/assets/sprites/terrain-sheet.png');
    this.load.image('characters', '/assets/sprites/characters-sheet.png');
    this.load.image('objects', '/assets/sprites/objects-sheet.png');
  }

  create() {
    this.cameras.main.setBackgroundColor('#13202a');
    this.cameras.main.setZoom(1);
    this.createChrome();
    this.createMap();
    this.createWorkers();
    this.createBandits();

    this.input.on('wheel', (_pointer: Phaser.Input.Pointer, _dx: number, _dy: number, _dz: number, event: WheelEvent) => {
      const zoom = Phaser.Math.Clamp(this.cameras.main.zoom + (event.deltaY > 0 ? -0.08 : 0.08), 0.7, 2.8);
      this.cameras.main.setZoom(zoom);
    });
  }

  private createChrome() {
    const g = this.add.graphics();
    g.fillStyle(0x111827, 0.92).fillRoundedRect(12, 12, 616, 56, 8);
    g.lineStyle(3, 0xffd166, 1).strokeRoundedRect(12, 12, 616, 56, 8);
    this.add.text(28, 25, `TICK ${mockGame.tick}/360   WINTER IN ${mockGame.winterIn}   ${mockGame.banditStatus}`, {
      fontFamily: 'monospace', fontSize: '16px', color: '#f8f0c6'
    }).setScrollFactor(0);
  }

  private createMap() {
    const g = this.add.graphics();
    g.lineStyle(4, 0x4b5563, 0.8);
    const edges: [number, number][] = [[1,3],[2,3],[1,4],[2,5],[3,4],[3,5],[4,6],[5,7],[6,8],[7,8]];
    edges.forEach(([a,b]) => {
      const ra = regionLayout.find(r => r.id === a)!;
      const rb = regionLayout.find(r => r.id === b)!;
      g.lineBetween(ra.x, ra.y, rb.x, rb.y);
    });

    regionLayout.forEach((r) => {
      const tile = this.add.rectangle(r.x, r.y, 148, 98, r.color, 1).setStrokeStyle(4, this.selected === r.id ? 0xfff2a6 : 0x0b1020);
      tile.setInteractive({ useHandCursor: true });
      tile.on('pointerdown', () => {
        this.selected = r.id;
        this.cameras.main.pan(r.x, r.y, 280, 'Power2');
        this.cameras.main.zoomTo(2.35, 280);
        this.game.events.emit('region-selected', r.id);
      });
      this.add.text(r.x, r.y + 44, r.name, { fontFamily: 'monospace', fontSize: '13px', color: '#fff7d1', align: 'center' }).setOrigin(0.5);
      this.add.rectangle(r.x - 38, r.y - 12, 14, 14, 0xffffff, 0.15);
      this.add.rectangle(r.x - 8, r.y - 18, 14, 14, 0xffffff, 0.12);
      this.add.rectangle(r.x + 24, r.y - 8, 14, 14, 0xffffff, 0.12);
    });
  }

  private createWorkers() {
    mockGame.clans.forEach((clan) => {
      const base = regionLayout.find(r => r.id === clan.baseRegionId)!;
      this.add.rectangle(base.x + 50, base.y - 24, 26, 22, clan.color === 'green' ? 0x2dd36f : clan.color === 'blue' ? 0x4aa3ff : 0xfacc15, 1)
        .setStrokeStyle(2, 0x000000);
      this.add.text(base.x + 50, base.y - 45, `B${clan.baseLevel} W${clan.wallLevel}`, { fontFamily: 'monospace', fontSize: '10px', color: '#111827', backgroundColor: '#f8f0c6' }).setOrigin(0.5);
      this.add.text(base.x + 50, base.y + 12, `M${clan.monumentLevel}`, { fontFamily: 'monospace', fontSize: '11px', color: '#ffffff' }).setOrigin(0.5);

      clan.workers.forEach((worker, i) => {
        const r = regionLayout.find(reg => reg.id === worker.regionId)!;
        const wx = r.x - 38 + i * 24;
        const wy = r.y + 12 + i * 2;
        this.add.rectangle(wx, wy, 14, 18, clan.color === 'green' ? 0x7ee787 : clan.color === 'blue' ? 0x93c5fd : 0xfde68a, 1)
          .setStrokeStyle(2, 0x111827);
        this.add.rectangle(wx + 12, wy + 8, 18, 10, 0x8b5a2b, 1).setStrokeStyle(1, 0x111827);
        this.add.text(wx, wy - 16, worker.id, { fontFamily: 'monospace', fontSize: '10px', color: '#ffffff', backgroundColor: '#111827' }).setOrigin(0.5);
      });
    });
  }

  private createBandits() {
    const forest = regionLayout[0];
    const camp = this.add.triangle(forest.x - 58, forest.y - 32, 0, 22, 18, 0, 36, 22, 0x151515, 1).setStrokeStyle(2, 0xff3b30);
    this.tweens.add({ targets: camp, alpha: 0.35, yoyo: true, repeat: -1, duration: 500 });
    this.add.text(forest.x - 58, forest.y - 60, 'RAID 3', { fontFamily: 'monospace', fontSize: '12px', color: '#ffb3a7', backgroundColor: '#2d0b0b' }).setOrigin(0.5);
  }
}
