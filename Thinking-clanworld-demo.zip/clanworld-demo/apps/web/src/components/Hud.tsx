import { mockGame } from '../data/mockGame';

const clan = mockGame.clans[0];
const resources = [
  ['🪵', clan.vault.wood],
  ['🌾', clan.vault.wheat],
  ['🐟', clan.vault.fish],
  ['⛓️', clan.vault.iron],
  ['🪙', clan.vault.gold],
  ['📜', clan.vault.blueprint]
];

export function Hud() {
  return (
    <aside className="hud-card" data-testid="hud-card">
      <div className="hud-title">Clan {clan.id} · {clan.name}</div>
      <div className="resource-grid">
        {resources.map(([icon, value]) => <span key={icon}>{icon} {value}</span>)}
      </div>
      <div className="meter"><span style={{ width: `${Math.min(100, clan.monumentLevel * 10)}%` }} /></div>
      <p>Monument Lv {clan.monumentLevel}/10 · Wall Lv {clan.wallLevel} · Base Lv {clan.baseLevel}</p>
    </aside>
  );
}
