import { mockGame } from '../data/mockGame';

export function WorkerPanel() {
  const clan = mockGame.clans[0];
  return (
    <section className="panel pixel-panel">
      <h2>Clansmen</h2>
      <div className="worker-list">
        {clan.workers.map((w) => (
          <article className="worker-card" key={w.id}>
            <strong>{w.id}</strong>
            <span>{w.mission}</span>
            <small>Cooldown: {w.cooldownSec ? `${w.cooldownSec}s` : 'ready'}</small>
            <small>Carry: {Object.entries(w.carry).map(([k, v]) => `${k} ${v}`).join(', ') || 'empty'}</small>
          </article>
        ))}
      </div>
    </section>
  );
}
