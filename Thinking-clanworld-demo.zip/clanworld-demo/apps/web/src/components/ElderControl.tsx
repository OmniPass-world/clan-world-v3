import { useState } from 'react';
import { mockGame } from '../data/mockGame';

export function ElderControl() {
  const [saved, setSaved] = useState(false);
  const [whispers, setWhispers] = useState<string[]>(['Winter is coming. Hoard wood and fish.']);

  return (
    <main className="page elder-page" data-testid="elder-page">
      <section className="elder-portrait pixel-panel">
        <div className="portrait-frame">☘</div>
        <div>
          <h1>Elder Ashroot</h1>
          <p>Status: <b>Thinking</b> · Mood: anxious about winter</p>
          <p>Last action: sent Worker C to defend base 0007.</p>
        </div>
      </section>

      <section className="strategy-grid">
        <label className="pixel-panel">Primary Strategy
          <textarea defaultValue={'Build coalition alliance. Fortify base before monument level 5.'} />
        </label>
        <label className="pixel-panel">Secondary Rules
          <textarea defaultValue={'- Focus mining and fishing\n- Never trust player 0006\n- Demand payment before sending defenders'} />
        </label>
        <label className="pixel-panel">Ethos
          <textarea defaultValue={'Paranoid, diplomatic, opportunistic. Avoid unnecessary risk before winter.'} />
        </label>
      </section>
      <button className="pixel-button" onClick={() => setSaved(true)}>Update Elder Doctrine</button>
      {saved && <p className="save-toast">Doctrine updated and ready to append to CLAUDE.md</p>}

      <section className="pixel-panel whisper-box">
        <h2>Send Divine Whisper</h2>
        <form onSubmit={(e) => { e.preventDefault(); const data = new FormData(e.currentTarget); const msg = String(data.get('whisper') || ''); if (msg) setWhispers([msg, ...whispers]); e.currentTarget.reset(); }}>
          <textarea name="whisper" placeholder="Tell your Elder what to prioritize..." />
          <button className="pixel-button">Send God → AXL Message</button>
        </form>
      </section>

      <section className="pixel-panel message-log">
        <h2>Live Messages</h2>
        {[...whispers.map((text, i) => ({ id: `w${i}`, kind: 'god', from: 'You', text, tick: mockGame.tick })), ...mockGame.messages].map((m) => (
          <article key={m.id} className={`log-line ${m.kind}`}><b>{m.from}</b><span>Tick {m.tick}</span><p>{m.text}</p></article>
        ))}
      </section>
    </main>
  );
}
