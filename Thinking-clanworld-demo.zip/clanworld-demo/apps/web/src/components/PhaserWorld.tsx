import { useEffect, useRef } from 'react';
import Phaser from 'phaser';
import { ClanWorldScene } from '../game/ClanWorldScene';

export default function PhaserWorld({ onRegionSelected }: { onRegionSelected?: (id: number) => void }) {
  const hostRef = useRef<HTMLDivElement | null>(null);
  const gameRef = useRef<Phaser.Game | null>(null);

  useEffect(() => {
    if (!hostRef.current || gameRef.current) return;

    const game = new Phaser.Game({
      type: Phaser.AUTO,
      parent: hostRef.current,
      width: 640,
      height: 760,
      backgroundColor: '#13202a',
      pixelArt: true,
      roundPixels: true,
      scene: [ClanWorldScene],
      scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH
      },
      input: {
        activePointers: 3
      }
    });

    game.events.on('region-selected', (id: number) => onRegionSelected?.(id));
    gameRef.current = game;

    return () => {
      game.destroy(true);
      gameRef.current = null;
    };
  }, [onRegionSelected]);

  return <div className="phaser-shell" ref={hostRef} aria-label="ClanWorld Phaser map" />;
}
