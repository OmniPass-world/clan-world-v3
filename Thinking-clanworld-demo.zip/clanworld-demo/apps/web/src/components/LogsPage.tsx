import { mockGame } from '../data/mockGame';

export function LogsPage() {
  return (
    <main className="page logs-page" data-testid="logs-page">
      <h1>Command Center Logs</h1>
      <section className="pixel-panel timeline">
        {mockGame.messages.map((m) => (
          <article key={m.id} className={`log-line ${m.kind}`}>
            <b>{m.kind.toUpperCase()} · {m.from}</b>
            <span>Tick {m.tick}</span>
            <p>{m.text}</p>
          </article>
        ))}
      </section>
    </main>
  );
}
