import { useState } from 'react';
import PhaserWorld from './components/PhaserWorld';
import { Hud } from './components/Hud';
import { WorkerPanel } from './components/WorkerPanel';
import { ElderControl } from './components/ElderControl';
import { LogsPage } from './components/LogsPage';
import { mockGame } from './data/mockGame';

function WorldPage() {
  const [region, setRegion] = useState<number | null>(null);
  return (
    <main className="page world-page" data-testid="world-page">
      <div className="world-stage">
        <PhaserWorld onRegionSelected={setRegion} />
        <Hud />
        <div className="chrome-note">Tap a region to zoom · Pinch/wheel to scale · Drag after zoom</div>
        {region && <div className="region-sheet pixel-panel">Region {region} selected · scout detail panel ready</div>}
      </div>
      <WorkerPanel />
      <section className="panel pixel-panel winter-card">
        <h2>Winter Readiness</h2>
        <p>Wood buffer: 42 / 10 needed</p>
        <p>Wheat: 80 / 20 needed</p>
        <p>Fish: 6.4 / 2 needed</p>
        <strong>Risk: LOW · Bandit risk: HIGH near Forest</strong>
      </section>
    </main>
  );
}

function ClanPage() {
  const clan = mockGame.clans[0];
  return (
    <main className="page clan-page" data-testid="clan-page">
      <h1>Clan Dashboard</h1>
      <section className="dash-grid">
        <div className="pixel-panel"><h2>Base</h2><p>Level {clan.baseLevel}</p><p>Walls {clan.wallLevel}/5</p></div>
        <div className="pixel-panel"><h2>Monument</h2><p>Level {clan.monumentLevel}/10</p><div className="meter"><span style={{ width: `${clan.monumentLevel * 10}%` }} /></div></div>
        <div className="pixel-panel"><h2>Vault</h2><p>Wood {clan.vault.wood}</p><p>Wheat {clan.vault.wheat}</p><p>Fish {clan.vault.fish}</p><p>Iron {clan.vault.iron}</p></div>
      </section>
      <WorkerPanel />
    </main>
  );
}

export default function App() {
  const initialTab = new URLSearchParams(window.location.search).get('tab') as 'world' | 'clan' | 'elder' | 'logs' | null;
  const [tab, setTab] = useState<'world' | 'clan' | 'elder' | 'logs'>(initialTab && ['world', 'clan', 'elder', 'logs'].includes(initialTab) ? initialTab : 'world');
  return (
    <div className="app-shell">
      {tab === 'world' && <WorldPage />}
      {tab === 'clan' && <ClanPage />}
      {tab === 'elder' && <ElderControl />}
      {tab === 'logs' && <LogsPage />}
      <nav className="bottom-nav" aria-label="Main navigation">
        {(['world', 'clan', 'elder', 'logs'] as const).map((t) => <button key={t} className={tab === t ? 'active' : ''} onClick={() => setTab(t)}>{t}</button>)}
      </nav>
    </div>
  );
}
