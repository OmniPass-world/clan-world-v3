import type { GameSnapshot } from '@clanworld/shared';

export const mockGame: GameSnapshot = {
  tick: 87,
  seasonEndTick: 360,
  winterIn: 23,
  banditStatus: 'Camping @ Forest — raid in 3',
  selectedClanId: '0007',
  clans: [
    {
      id: '0007',
      name: 'Ashroot',
      color: 'green',
      baseRegionId: 4,
      baseLevel: 2,
      wallLevel: 1,
      monumentLevel: 4,
      vault: { wood: 42, wheat: 80, fish: 6.4, iron: 3.5, gold: 12, blueprint: 1 },
      workers: [
        { id: 'A', clan: '0007', regionId: 1, mission: 'Chop Wood', carry: { wood: 12 }, cooldownSec: 0, status: 'acting' },
        { id: 'B', clan: '0007', regionId: 3, mission: 'Market Watch', carry: { iron: 2 }, cooldownSec: 18, status: 'waiting' },
        { id: 'C', clan: '0007', regionId: 4, mission: 'Defend Base 0007', carry: {}, cooldownSec: 0, status: 'defending' }
      ]
    },
    {
      id: '0003',
      name: 'Ironhorn',
      color: 'blue',
      baseRegionId: 2,
      baseLevel: 2,
      wallLevel: 2,
      monumentLevel: 3,
      vault: { wood: 18, wheat: 24, fish: 3.1, iron: 9.5, gold: 7, blueprint: 0 },
      workers: [
        { id: 'D', clan: '0003', regionId: 2, mission: 'Mine Iron', carry: { iron: 3.5 }, cooldownSec: 0, status: 'acting' },
        { id: 'E', clan: '0003', regionId: 1, mission: 'Travel to Forest', carry: {}, cooldownSec: 42, status: 'traveling' }
      ]
    },
    {
      id: '0006',
      name: 'Sunwheat',
      color: 'yellow',
      baseRegionId: 5,
      baseLevel: 1,
      wallLevel: 0,
      monumentLevel: 2,
      vault: { wood: 6, wheat: 105, fish: 1.2, iron: 1, gold: 4, blueprint: 0 },
      workers: [
        { id: 'F', clan: '0006', regionId: 5, mission: 'Harvest Wheat', carry: { wheat: 24 }, cooldownSec: 0, status: 'acting' }
      ]
    }
  ],
  messages: [
    { id: 'm1', kind: 'system', from: 'World', text: 'Bandit camp spotted in Forest. Attack in 3 ticks.', tick: 86 },
    { id: 'm2', kind: 'axl', from: 'Clan 0003', text: 'Bandits near you. Pay 4 gold and we send one defender.', tick: 87 },
    { id: 'm3', kind: 'god', from: 'You', text: 'Prioritize walls before monument level 5. Do not trust 0006.', tick: 87 },
    { id: 'm4', kind: 'trade', from: 'Unicorn Town', text: 'Worker B is waiting with 2 iron and watching price movement.', tick: 87 }
  ]
};
