# Screenshot Status

A Playwright screenshot workflow is included at `apps/web/tests/screenshots.spec.ts` and can be run with:

```bash
pnpm screenshots
```

In this container I was able to build and test the app, but Chromium failed to stay alive long enough for Playwright to capture screenshots, likely due the container's browser / sandbox / GPU restrictions.

So the screenshot folder is prepared, and the automation is wired up, but the actual captures need to be run in a less restricted local environment or CI runner with a stable Playwright browser setup.
