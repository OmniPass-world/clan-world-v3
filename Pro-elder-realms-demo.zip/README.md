# Elder Realms Demo

A mobile-first React + Phaser 3 demo for an 8-bit fantasy strategy / agent game world.

## What is included

- full-map world view with zoom and pan
- clan dashboard
- elder control / doctrine editor
- log and communications dashboard
- four phases of the demo
- placeholder sprite sheets generated from a Python script
- Playwright screenshot capture script
- minimal happy-path tests
- pnpm workspace monorepo

## Monorepo layout

- `apps/web` – React + Phaser app
- `packages/shared` – shared mock data and types
- `packages/assets` – art direction and sprite docs
- `scripts/generate_assets.py` – generates placeholder pixel-art assets
- `artifacts/screenshots` – Playwright screenshots

## Quick start

```bash
pnpm install
pnpm generate:assets
pnpm build
pnpm --filter web dev
```

## Useful commands

```bash
pnpm test
pnpm screenshots
pnpm zip
```

## Screenshots

### World
![Phase 1 World](artifacts/screenshots/phase1-world.png)

### Clan
![Phase 1 Clan](artifacts/screenshots/phase1-clan.png)

### Elder
![Phase 3 Elder](artifacts/screenshots/phase3-elder.png)

### Logs
![Phase 4 Logs](artifacts/screenshots/phase4-logs.png)

## Notes

- Phase 1 and Phase 4 are designed to look good even with no contracts deployed.
- Phase 2 keeps the same UI but models a contract-adapter boundary.
- Phase 3 focuses on doctrine editing and God whisper messaging.
- Final production art can replace the generated placeholders without changing the overall scene structure.
