# Pixel Art Direction

This demo uses placeholder sprite sheets generated in code so the project remains fully runnable and editable. The visual direction is intentionally close to a polished 8-bit / 16-bit fantasy strategy game:

- top-down / slightly angled world view
- crisp nearest-neighbor scaling
- strong silhouette readability on phone screens
- decorative UI chrome using chunky borders and warm-gold accents
- regions kept color-distinct for instant scanability

## Palette goals

- dark navy / indigo UI shell
- warm gold for affordances and interactive highlights
- green forest, grey mountains, yellow farms, blue docks and sea
- small clan color accents to keep factions readable

## Recommended final art replacement

Replace the current generated placeholders with:

1. world map background tile sheet
2. worker animation sheet with 16x16 or 24x24 frames
3. structures sheet for bases, walls, monuments, camps, market stalls
4. FX sheet for snow, coin pop, combat pulse, raid banner, sparkle

The demo code is already arranged so those assets can be dropped in later with minimal scene changes.
