# Sprite Specs

## Worker sheet

Current placeholder sheet:
- file: `apps/web/public/assets/worker-sheet.png`
- source grid: 4 columns x 4 rows
- source frame size: 16x16
- exported scaled image size: 128x128
- Phaser config still reads frames as 16x16 logical sprites

### Planned roles / frame groups

- frames 0-3: woodcutter / defender walk or idle loop
- frames 4-7: miner / trader loop
- frames 8-11: farmer / hauler loop
- frames 12-15: fisher loop

## World map background

Current placeholder:
- file: `apps/web/public/assets/world-map.png`
- logical size: 380x480
- rendered as one backdrop image inside Phaser

## Recommended future sheets

### Structures sheet
- 16x16 grid
- base level 1-5
- wall level 0-5
- monument level 0-10
- bandit camp states
- market stall variants

### FX sheet
- 16x16 grid
- sparkle
- coin pop
- winter snow burst
- danger pulse
- blueprint pickup
- shield pulse

### UI icon sheet
- 12x12 or 16x16
- wood, wheat, fish, iron, gold, blueprint, winter, bandit, whisper, AXL
