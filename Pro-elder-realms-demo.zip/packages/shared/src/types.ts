export type RegionId =
  | 'forest'
  | 'mountains'
  | 'unicorn-town'
  | 'west-farms'
  | 'east-farms'
  | 'west-docks'
  | 'east-docks'
  | 'deep-sea';

export type PageId = 'world' | 'clan' | 'elder' | 'logs';
export type PhaseId = 'phase1' | 'phase2' | 'phase3' | 'phase4';

export type ResourceKey = 'wood' | 'wheat' | 'fish' | 'iron' | 'gold' | 'blueprint';

export interface ResourceSet {
  wood: number;
  wheat: number;
  fish: number;
  iron: number;
  gold: number;
  blueprint: number;
}

export interface Worker {
  id: string;
  name: string;
  role: 'hauler' | 'woodcutter' | 'miner' | 'farmer' | 'fisher' | 'defender' | 'trader';
  regionId: RegionId;
  mission: string;
  carry: Partial<Record<ResourceKey, number>>;
  cooldownSeconds: number;
  status: 'waiting' | 'traveling' | 'working' | 'defending' | 'trading';
  path?: RegionId[];
}

export interface ClanSummary {
  clanId: string;
  elderName: string;
  motto: string;
  rank: number;
  baseLevel: number;
  wallLevel: number;
  monumentLevel: number;
  winterReadiness: 'low' | 'medium' | 'high';
  resources: ResourceSet;
  workers: Worker[];
  starvation: boolean;
  location: RegionId;
}

export interface WorldEvent {
  id: string;
  tick: number;
  kind: 'bandit' | 'winter' | 'market' | 'system' | 'axl' | 'combat';
  title: string;
  body: string;
}

export interface AxlMessage {
  id: string;
  kind: 'god' | 'peer' | 'system';
  from: string;
  to: string;
  body: string;
  tick: number;
}

export interface RegionMeta {
  id: RegionId;
  label: string;
  x: number;
  y: number;
  biome: string;
  detail: string;
}

export interface BanditState {
  active: boolean;
  state: 'idle' | 'camping' | 'resting' | 'attacking';
  regionId: RegionId | null;
  countdown: number;
}

export interface AppSnapshot {
  phase: PhaseId;
  title: string;
  subtitle: string;
  tick: number;
  seasonLength: number;
  winterIn: number;
  worldSeedLabel: string;
  bandits: BanditState;
  selectedClanId: string;
  clans: ClanSummary[];
  regions: RegionMeta[];
  events: WorldEvent[];
  messages: AxlMessage[];
  primaryStrategy: string;
  secondaryStrategy: string;
  ethos: string;
  liveDemoEnabled: boolean;
}
