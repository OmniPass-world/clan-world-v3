import type { AppSnapshot, ClanSummary, PhaseId, RegionMeta, Worker } from './types';

export const regions: RegionMeta[] = [
  { id: 'forest', label: 'Forest', x: 116, y: 92, biome: 'Forest', detail: 'Dense timber and bandit cover.' },
  { id: 'mountains', label: 'Mountains', x: 264, y: 92, biome: 'Mountains', detail: 'Iron veins and rare gold procs.' },
  { id: 'unicorn-town', label: 'Unicorn Town', x: 190, y: 156, biome: 'Town', detail: 'Market, gossip, and instant trades.' },
  { id: 'west-farms', label: 'West Farms', x: 116, y: 220, biome: 'Farmland', detail: 'Wheat plots and small roads.' },
  { id: 'east-farms', label: 'East Farms', x: 264, y: 220, biome: 'Farmland', detail: 'Wheat, walls, and monument work.' },
  { id: 'west-docks', label: 'West Docks', x: 116, y: 292, biome: 'Docks', detail: 'Fish, lumber, and shipping.' },
  { id: 'east-docks', label: 'East Docks', x: 264, y: 292, biome: 'Docks', detail: 'Fast harbor trade lane.' },
  { id: 'deep-sea', label: 'Deep Sea', x: 190, y: 364, biome: 'Sea', detail: 'High yield fishing waters.' }
];

const baseClan = (overrides: Partial<ClanSummary>): ClanSummary => ({
  clanId: '0001',
  elderName: 'Elder Ashroot',
  motto: 'Fortify, trade, outlast.',
  rank: 2,
  baseLevel: 2,
  wallLevel: 3,
  monumentLevel: 2,
  winterReadiness: 'medium',
  resources: { wood: 42, wheat: 80, fish: 6.4, iron: 3.5, gold: 12, blueprint: 1 },
  workers: [],
  starvation: false,
  location: 'west-farms',
  ...overrides
});

const clan1Workers: Worker[] = [
  { id: 'a', name: 'A', role: 'woodcutter', regionId: 'forest', mission: 'Chop wood', carry: { wood: 12 }, cooldownSeconds: 0, status: 'working' as const, path: ['west-farms', 'forest'] },
  { id: 'b', name: 'B', role: 'trader', regionId: 'unicorn-town', mission: 'Wait for wood sale', carry: { iron: 2 }, cooldownSeconds: 18, status: 'waiting' as const, path: ['west-farms', 'unicorn-town'] },
  { id: 'c', name: 'C', role: 'defender', regionId: 'west-farms', mission: 'Defend home base', carry: {}, cooldownSeconds: 0, status: 'defending' as const },
  { id: 'd', name: 'D', role: 'fisher', regionId: 'west-docks', mission: 'Fish from dock', carry: { fish: 2 }, cooldownSeconds: 7, status: 'working' as const, path: ['west-farms', 'west-docks'] }
];

const otherClans: ClanSummary[] = [
  baseClan({
    clanId: '0002',
    elderName: 'Elder Glint',
    motto: 'Mine deep. Trade later.',
    rank: 1,
    baseLevel: 3,
    wallLevel: 3,
    monumentLevel: 3,
    winterReadiness: 'high',
    resources: { wood: 26, wheat: 55, fish: 4.1, iron: 10.5, gold: 18, blueprint: 2 },
    location: 'mountains',
    workers: [
      { id: 'e', name: 'E', role: 'miner', regionId: 'mountains', mission: 'Mine iron', carry: { iron: 4 }, cooldownSeconds: 0, status: 'working' },
      { id: 'f', name: 'F', role: 'trader', regionId: 'unicorn-town', mission: 'Arbitrage iron', carry: {}, cooldownSeconds: 0, status: 'waiting' },
      { id: 'g', name: 'G', role: 'defender', regionId: 'mountains', mission: 'Hold wall', carry: {}, cooldownSeconds: 0, status: 'defending' },
      { id: 'h', name: 'H', role: 'hauler', regionId: 'east-farms', mission: 'Deliver wheat', carry: { wheat: 18 }, cooldownSeconds: 5, status: 'traveling', path: ['mountains', 'unicorn-town', 'east-farms'] }
    ]
  }),
  baseClan({
    clanId: '0003',
    elderName: 'Elder Foam',
    motto: 'Fish rich, speak softly.',
    rank: 3,
    baseLevel: 2,
    wallLevel: 2,
    monumentLevel: 1,
    winterReadiness: 'medium',
    resources: { wood: 20, wheat: 40, fish: 14.2, iron: 1.5, gold: 8, blueprint: 0 },
    location: 'east-docks',
    workers: [
      { id: 'i', name: 'I', role: 'fisher', regionId: 'deep-sea', mission: 'Deep sea fishing', carry: { fish: 4 }, cooldownSeconds: 0, status: 'working', path: ['east-docks', 'deep-sea'] },
      { id: 'j', name: 'J', role: 'hauler', regionId: 'east-docks', mission: 'Unload fish', carry: { fish: 6 }, cooldownSeconds: 0, status: 'waiting' },
      { id: 'k', name: 'K', role: 'defender', regionId: 'east-docks', mission: 'Guard docks', carry: {}, cooldownSeconds: 0, status: 'defending' },
      { id: 'l', name: 'L', role: 'trader', regionId: 'unicorn-town', mission: 'Buy wood', carry: { gold: 3 }, cooldownSeconds: 10, status: 'trading', path: ['east-docks', 'unicorn-town'] }
    ]
  }),
  baseClan({
    clanId: '0004',
    elderName: 'Elder Thorn',
    motto: 'Walls first. Trust nobody.',
    rank: 4,
    baseLevel: 1,
    wallLevel: 4,
    monumentLevel: 0,
    winterReadiness: 'low',
    resources: { wood: 12, wheat: 22, fish: 1.2, iron: 2, gold: 5, blueprint: 1 },
    starvation: true,
    location: 'forest',
    workers: [
      { id: 'm', name: 'M', role: 'woodcutter', regionId: 'forest', mission: 'Emergency logging', carry: { wood: 8 }, cooldownSeconds: 0, status: 'working' },
      { id: 'n', name: 'N', role: 'defender', regionId: 'forest', mission: 'Hold gate', carry: {}, cooldownSeconds: 0, status: 'defending' },
      { id: 'o', name: 'O', role: 'farmer', regionId: 'west-farms', mission: 'Harvest wheat', carry: { wheat: 5 }, cooldownSeconds: 0, status: 'working', path: ['forest', 'west-farms'] },
      { id: 'p', name: 'P', role: 'trader', regionId: 'unicorn-town', mission: 'Plead for fish', carry: { gold: 1 }, cooldownSeconds: 0, status: 'waiting', path: ['forest', 'unicorn-town'] }
    ]
  })
];

const baseClans: ClanSummary[] = [baseClan({ workers: clan1Workers }), ...otherClans];

const makeSnapshot = (phase: PhaseId): AppSnapshot => {
  const phaseMeta = {
    phase1: {
      title: 'Phase 1 · Mock World Demo',
      subtitle: 'Fully visual demo with mocked game state and polished HUD.',
      tick: 87,
      winterIn: 23,
      bandits: { active: true, state: 'camping' as const, regionId: 'forest' as const, countdown: 3 },
      worldSeedLabel: 'mock-seed-87',
      liveDemoEnabled: false
    },
    phase2: {
      title: 'Phase 2 · Contract Adapter Demo',
      subtitle: 'Same world UI, but shaped around a contract adapter boundary.',
      tick: 124,
      winterIn: 96,
      bandits: { active: false, state: 'idle' as const, regionId: null, countdown: 0 },
      worldSeedLabel: 'adapter-seed-124',
      liveDemoEnabled: false
    },
    phase3: {
      title: 'Phase 3 · Elder Control Demo',
      subtitle: 'Doctrine editing, God whispers, and AXL inbox UI.',
      tick: 201,
      winterIn: 19,
      bandits: { active: true, state: 'resting' as const, regionId: 'west-farms' as const, countdown: 2 },
      worldSeedLabel: 'adapter-seed-201',
      liveDemoEnabled: false
    },
    phase4: {
      title: 'Phase 4 · Live Story Demo',
      subtitle: 'Scripted demo loop: whisper → bargain → defense → reward → monument.',
      tick: 244,
      winterIn: 86,
      bandits: { active: true, state: 'camping' as const, regionId: 'east-farms' as const, countdown: 2 },
      worldSeedLabel: 'demo-seed-244',
      liveDemoEnabled: true
    }
  }[phase];

  const baseMessages = [
    { id: '1', kind: 'god' as const, from: 'God AXL', to: 'Elder Ashroot', body: 'Winter is close. Pause monument work and stockpile wood.', tick: phaseMeta.tick - 4 },
    { id: '2', kind: 'peer' as const, from: 'Elder Glint', to: 'Elder Ashroot', body: 'Send two defenders to West Farms and I will pay 5 Gold.', tick: phaseMeta.tick - 3 },
    { id: '3', kind: 'system' as const, from: 'System', to: 'All', body: 'Bandits are camping in Forest. Raid in 3 ticks.', tick: phaseMeta.tick - 2 },
    { id: '4', kind: 'peer' as const, from: 'Elder Ashroot', to: 'Elder Glint', body: 'Accepted. Payment on successful defense.', tick: phaseMeta.tick - 1 }
  ];

  const baseEvents = [
    { id: 'ev1', tick: phaseMeta.tick - 4, kind: 'market' as const, title: 'Iron sold in Unicorn Town', body: 'Worker B sold 2 iron and captured 3.4 gold.' },
    { id: 'ev2', tick: phaseMeta.tick - 2, kind: 'bandit' as const, title: 'Bandits spotted in Forest', body: 'Raid banner raised. Red pulse shown on world map.' },
    { id: 'ev3', tick: phaseMeta.tick - 1, kind: 'axl' as const, title: 'Defense deal struck', body: 'Clan 0002 offered payment for west farm defense.' },
    { id: 'ev4', tick: phaseMeta.tick, kind: phase === 'phase4' ? 'combat' as const : 'system' as const, title: phase === 'phase4' ? 'Monument stone delivered' : 'World state synced', body: phase === 'phase4' ? 'Blueprint fragment delivered. Monument progress advanced.' : 'Contract adapter returned fresh world snapshot.' }
  ];

  return {
    phase,
    title: phaseMeta.title,
    subtitle: phaseMeta.subtitle,
    tick: phaseMeta.tick,
    seasonLength: 360,
    winterIn: phaseMeta.winterIn,
    worldSeedLabel: phaseMeta.worldSeedLabel,
    bandits: phaseMeta.bandits,
    selectedClanId: '0001',
    clans: baseClans,
    regions,
    events: baseEvents,
    messages: baseMessages,
    primaryStrategy: 'Build coalition with nearby farms. Prioritize walls before monument level 5. Keep one defender at home at all times.',
    secondaryStrategy: '- Never trust Clan 0004\n- Trade fish for wood whenever winter readiness falls below medium\n- Keep one worker near Unicorn Town for reactive arbitrage',
    ethos: 'Be paranoid, diplomatic, and opportunistic. Avoid unnecessary risk before winter, but exploit visible market queues.',
    liveDemoEnabled: phaseMeta.liveDemoEnabled
  };
};

export const snapshots: Record<PhaseId, AppSnapshot> = {
  phase1: makeSnapshot('phase1'),
  phase2: makeSnapshot('phase2'),
  phase3: makeSnapshot('phase3'),
  phase4: makeSnapshot('phase4')
};

export const getSnapshot = (phase: PhaseId) => snapshots[phase];
