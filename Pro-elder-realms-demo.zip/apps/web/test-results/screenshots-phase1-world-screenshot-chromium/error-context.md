# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: screenshots.spec.ts >> phase1 world screenshot
- Location: tests/screenshots.spec.ts:12:5

# Error details

```
Error: browserType.launch: Target page, context or browser has been closed
Browser logs:

<launching> /usr/bin/chromium --inspector-pipe --headless --no-startup-window --no-sandbox --disable-gpu --disable-dev-shm-usage --use-gl=swiftshader --disable-features=VizDisplayCompositor
<launched> pid=8227
[pid=8227][err] [8249:8249:0425/055035.761703:ERROR:base/files/file_path_watcher_inotify.cc:923] Failed to read /proc/sys/fs/inotify/max_user_watches
[pid=8227][err] [8248:8248:0425/055035.764970:ERROR:base/files/file_path_watcher_inotify.cc:923] Failed to read /proc/sys/fs/inotify/max_user_watches
[pid=8227][err] [8227:8254:0425/055035.778341:ERROR:base/files/file_path_watcher_inotify.cc:923] Failed to read /proc/sys/fs/inotify/max_user_watches
[pid=8227][err] [8227:8255:0425/055035.778324:ERROR:dbus/bus.cc:406] Failed to connect to the bus: Failed to connect to socket /run/dbus/system_bus_socket: No such file or directory
[pid=8227][err] [8227:8255:0425/055035.797072:ERROR:dbus/bus.cc:406] Failed to connect to the bus: Could not parse server address: Unknown address type (examples of valid types are "tcp" and on UNIX "unix")
[pid=8227][err] [8227:8255:0425/055035.797382:ERROR:dbus/bus.cc:406] Failed to connect to the bus: Failed to connect to socket /run/dbus/system_bus_socket: No such file or directory
[pid=8227][err] [8227:8253:0425/055035.797799:ERROR:net/base/address_tracker_linux.cc:242] Could not bind NETLINK socket: Permission denied (13)
[pid=8227][err] [8227:8255:0425/055035.798202:ERROR:dbus/bus.cc:406] Failed to connect to the bus: Failed to connect to socket /run/dbus/system_bus_socket: No such file or directory
[pid=8227][err] [8227:8255:0425/055035.889303:ERROR:dbus/bus.cc:406] Failed to connect to the bus: Could not parse server address: Unknown address type (examples of valid types are "tcp" and on UNIX "unix")
[pid=8227][err] [8227:8255:0425/055035.982719:ERROR:dbus/bus.cc:406] Failed to connect to the bus: Could not parse server address: Unknown address type (examples of valid types are "tcp" and on UNIX "unix")
[pid=8227][err] [8227:8227:0425/055036.074314:ERROR:dbus/object_proxy.cc:573] Failed to call method: org.freedesktop.DBus.NameHasOwner: object_path= /org/freedesktop/DBus: unknown error type: 
[pid=8227][err] [8227:8255:0425/055036.074489:ERROR:dbus/bus.cc:406] Failed to connect to the bus: Could not parse server address: Unknown address type (examples of valid types are "tcp" and on UNIX "unix")
[pid=8227][err] [8227:8227:0425/055036.076593:ERROR:dbus/object_proxy.cc:573] Failed to call method: org.freedesktop.DBus.NameHasOwner: object_path= /org/freedesktop/DBus: unknown error type: 
[pid=8227][err] [8227:8227:0425/055036.083055:ERROR:dbus/object_proxy.cc:573] Failed to call method: org.freedesktop.DBus.NameHasOwner: object_path= /org/freedesktop/DBus: unknown error type: 
[pid=8227][err] [8227:8255:0425/055036.156025:ERROR:dbus/bus.cc:406] Failed to connect to the bus: Failed to connect to socket /run/dbus/system_bus_socket: No such file or directory
[pid=8227][err] [8227:8255:0425/055036.160272:ERROR:dbus/bus.cc:406] Failed to connect to the bus: Failed to connect to socket /run/dbus/system_bus_socket: No such file or directory
[pid=8227][err] [8227:8227:0425/055036.160865:ERROR:dbus/object_proxy.cc:573] Failed to call method: org.freedesktop.DBus.NameHasOwner: object_path= /org/freedesktop/DBus: unknown error type: 
[pid=8227][err] [8227:8227:0425/055036.167257:ERROR:dbus/object_proxy.cc:573] Failed to call method: org.freedesktop.DBus.Properties.GetAll: object_path= /org/freedesktop/UPower/devices/DisplayDevice: unknown error type: 
[pid=8227][err] [8275:8294:0425/055036.179325:ERROR:base/files/file_path_watcher_inotify.cc:923] Failed to read /proc/sys/fs/inotify/max_user_watches
Call log:
  - <launching> /usr/bin/chromium --inspector-pipe --headless --no-startup-window --no-sandbox --disable-gpu --disable-dev-shm-usage --use-gl=swiftshader --disable-features=VizDisplayCompositor
  - <launched> pid=8227
  - [pid=8227][err] [8249:8249:0425/055035.761703:ERROR:base/files/file_path_watcher_inotify.cc:923] Failed to read /proc/sys/fs/inotify/max_user_watches
  - [pid=8227][err] [8248:8248:0425/055035.764970:ERROR:base/files/file_path_watcher_inotify.cc:923] Failed to read /proc/sys/fs/inotify/max_user_watches
  - [pid=8227][err] [8227:8254:0425/055035.778341:ERROR:base/files/file_path_watcher_inotify.cc:923] Failed to read /proc/sys/fs/inotify/max_user_watches
  - [pid=8227][err] [8227:8255:0425/055035.778324:ERROR:dbus/bus.cc:406] Failed to connect to the bus: Failed to connect to socket /run/dbus/system_bus_socket: No such file or directory
  - [pid=8227][err] [8227:8255:0425/055035.797072:ERROR:dbus/bus.cc:406] Failed to connect to the bus: Could not parse server address: Unknown address type (examples of valid types are "tcp" and on UNIX "unix")
  - [pid=8227][err] [8227:8255:0425/055035.797382:ERROR:dbus/bus.cc:406] Failed to connect to the bus: Failed to connect to socket /run/dbus/system_bus_socket: No such file or directory
  - [pid=8227][err] [8227:8253:0425/055035.797799:ERROR:net/base/address_tracker_linux.cc:242] Could not bind NETLINK socket: Permission denied (13)
  - [pid=8227][err] [8227:8255:0425/055035.798202:ERROR:dbus/bus.cc:406] Failed to connect to the bus: Failed to connect to socket /run/dbus/system_bus_socket: No such file or directory
  - [pid=8227][err] [8227:8255:0425/055035.889303:ERROR:dbus/bus.cc:406] Failed to connect to the bus: Could not parse server address: Unknown address type (examples of valid types are "tcp" and on UNIX "unix")
  - [pid=8227][err] [8227:8255:0425/055035.982719:ERROR:dbus/bus.cc:406] Failed to connect to the bus: Could not parse server address: Unknown address type (examples of valid types are "tcp" and on UNIX "unix")
  - [pid=8227][err] [8227:8227:0425/055036.074314:ERROR:dbus/object_proxy.cc:573] Failed to call method: org.freedesktop.DBus.NameHasOwner: object_path= /org/freedesktop/DBus: unknown error type:
  - [pid=8227][err] [8227:8255:0425/055036.074489:ERROR:dbus/bus.cc:406] Failed to connect to the bus: Could not parse server address: Unknown address type (examples of valid types are "tcp" and on UNIX "unix")
  - [pid=8227][err] [8227:8227:0425/055036.076593:ERROR:dbus/object_proxy.cc:573] Failed to call method: org.freedesktop.DBus.NameHasOwner: object_path= /org/freedesktop/DBus: unknown error type:
  - [pid=8227][err] [8227:8227:0425/055036.083055:ERROR:dbus/object_proxy.cc:573] Failed to call method: org.freedesktop.DBus.NameHasOwner: object_path= /org/freedesktop/DBus: unknown error type:
  - [pid=8227][err] [8227:8255:0425/055036.156025:ERROR:dbus/bus.cc:406] Failed to connect to the bus: Failed to connect to socket /run/dbus/system_bus_socket: No such file or directory
  - [pid=8227][err] [8227:8255:0425/055036.160272:ERROR:dbus/bus.cc:406] Failed to connect to the bus: Failed to connect to socket /run/dbus/system_bus_socket: No such file or directory
  - [pid=8227][err] [8227:8227:0425/055036.160865:ERROR:dbus/object_proxy.cc:573] Failed to call method: org.freedesktop.DBus.NameHasOwner: object_path= /org/freedesktop/DBus: unknown error type:
  - [pid=8227][err] [8227:8227:0425/055036.167257:ERROR:dbus/object_proxy.cc:573] Failed to call method: org.freedesktop.DBus.Properties.GetAll: object_path= /org/freedesktop/UPower/devices/DisplayDevice: unknown error type:
  - [pid=8227][err] [8275:8294:0425/055036.179325:ERROR:base/files/file_path_watcher_inotify.cc:923] Failed to read /proc/sys/fs/inotify/max_user_watches
  - [pid=8227] <gracefully close start>
  - [pid=8227] <kill>
  - [pid=8227] <will force kill>
  - [pid=8227][err] [0425/055036.375716:ERROR:third_party/crashpad/crashpad/util/linux/socket.cc:182] incorrect payload size 0
  - [pid=8227][err] [0425/055036.379630:ERROR:third_party/crashpad/crashpad/util/linux/socket.cc:182] incorrect payload size 0
  - [pid=8227] <process did exit: exitCode=0, signal=null>
  - [pid=8227] starting temporary directories cleanup
  - [pid=8227] finished temporary directories cleanup
  - [pid=8227] <gracefully close end>

```