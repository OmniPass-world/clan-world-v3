import { defineConfig, devices } from '@playwright/test';
import { fileURLToPath } from 'node:url';

const appDir = fileURLToPath(new URL('.', import.meta.url));

export default defineConfig({
  testDir: './tests',
  testMatch: 'screenshots.spec.ts',
  timeout: 60_000,
  use: {
    baseURL: 'http://127.0.0.1:4173',
    trace: 'off'
  },
  webServer: {
    command: 'pnpm preview',
    port: 4173,
    reuseExistingServer: false,
    cwd: appDir,
    timeout: 120_000
  },
  projects: [
    {
      name: 'chromium',
      use: {
        ...devices['iPhone 14 Pro'],
        viewport: { width: 430, height: 932 },
        launchOptions: {
          executablePath: '/usr/bin/chromium',
          args: [
            '--no-sandbox',
            '--disable-gpu',
            '--disable-dev-shm-usage',
            '--use-gl=swiftshader',
            '--disable-features=VizDisplayCompositor'
          ]
        },
        chromiumSandbox: false
      }
    }
  ]
});
