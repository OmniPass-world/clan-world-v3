import { useEffect } from 'react';
import { NavLink, Navigate, Route, Routes, useLocation, useNavigate } from 'react-router-dom';
import { type PageId, type PhaseId } from '@elder-realms/shared';
import { AppStateProvider, useAppState } from './lib/useAppState';
import { parsePhase, phaseOptions } from './lib/phase';
import { WorldPage } from './pages/WorldPage';
import { ClanPage } from './pages/ClanPage';
import { ElderPage } from './pages/ElderPage';
import { LogsPage } from './pages/LogsPage';

const navItems: { id: PageId; label: string; path: string }[] = [
  { id: 'world', label: 'World', path: '/world' },
  { id: 'clan', label: 'Clan', path: '/clan' },
  { id: 'elder', label: 'Elder', path: '/elder' },
  { id: 'logs', label: 'Logs', path: '/logs' }
];

const Shell = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { phase, setPhase, snapshot } = useAppState();

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const nextPhase = parsePhase(params.get('phase'));
    if (nextPhase !== phase) setPhase(nextPhase);
  }, [location.search, phase, setPhase]);

  const updatePhase = (next: PhaseId) => {
    const path = location.pathname || '/world';
    navigate(`${path}?phase=${next}`);
  };

  return (
    <div className="shell">
      <header className="topbar panel">
        <div>
          <div className="eyebrow">Elder Realms · Mobile Demo</div>
          <h1>{snapshot.title}</h1>
          <p>{snapshot.subtitle}</p>
        </div>
        <div className="phase-selector">
          {phaseOptions.map((option) => (
            <button
              key={option.id}
              className={option.id === phase ? 'phase-btn active' : 'phase-btn'}
              onClick={() => updatePhase(option.id)}
            >
              {option.label}
            </button>
          ))}
        </div>
      </header>

      <main className="main-grid">
        <Routes>
          <Route path="/world" element={<WorldPage />} />
          <Route path="/clan" element={<ClanPage />} />
          <Route path="/elder" element={<ElderPage />} />
          <Route path="/logs" element={<LogsPage />} />
          <Route path="*" element={<Navigate to={`/world?phase=${phase}`} replace />} />
        </Routes>
      </main>

      <nav className="bottom-nav panel">
        {navItems.map((item) => (
          <NavLink key={item.id} to={`${item.path}?phase=${phase}`} className={({ isActive }) => (isActive ? 'nav-chip active' : 'nav-chip')}>
            {item.label}
          </NavLink>
        ))}
      </nav>
    </div>
  );
};

export const App = () => {
  const location = useLocation();
  const initialPhase = parsePhase(new URLSearchParams(location.search).get('phase'));

  return (
    <AppStateProvider initialPhase={initialPhase}>
      <Shell />
    </AppStateProvider>
  );
};
