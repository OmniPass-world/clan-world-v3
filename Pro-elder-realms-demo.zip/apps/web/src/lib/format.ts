export const fmt = (value: number) => {
  const fixed = Number.isInteger(value) ? 0 : 1;
  return value.toFixed(fixed);
};

export const titleCase = (value: string) => value.replace(/\b\w/g, (s) => s.toUpperCase());
