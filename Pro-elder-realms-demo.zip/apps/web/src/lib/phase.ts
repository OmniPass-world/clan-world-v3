import type { PhaseId } from '@elder-realms/shared';

export const phaseOptions: { id: PhaseId; label: string }[] = [
  { id: 'phase1', label: 'Phase 1' },
  { id: 'phase2', label: 'Phase 2' },
  { id: 'phase3', label: 'Phase 3' },
  { id: 'phase4', label: 'Phase 4' }
];

export const parsePhase = (raw: string | null): PhaseId => {
  if (raw === 'phase1' || raw === 'phase2' || raw === 'phase3' || raw === 'phase4') {
    return raw;
  }
  return 'phase1';
};
