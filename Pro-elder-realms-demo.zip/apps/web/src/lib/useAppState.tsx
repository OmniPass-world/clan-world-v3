import { getSnapshot, type AppSnapshot, type ClanSummary, type PhaseId } from '@elder-realms/shared';
import { createContext, useContext, useMemo, useState } from 'react';

interface AppState {
  phase: PhaseId;
  setPhase: (phase: PhaseId) => void;
  snapshot: AppSnapshot;
  selectedClan: ClanSummary;
  setSelectedClanId: (id: string) => void;
  doctrine: {
    primary: string;
    secondary: string;
    ethos: string;
  };
  updateDoctrine: (partial: Partial<AppState['doctrine']>) => void;
  whisperDraft: string;
  setWhisperDraft: (value: string) => void;
  sentWhispers: { id: string; body: string }[];
  sendWhisper: () => void;
}

const AppStateContext = createContext<AppState | null>(null);

export const AppStateProvider = ({ initialPhase, children }: { initialPhase: PhaseId; children: React.ReactNode }) => {
  const [phase, setPhase] = useState<PhaseId>(initialPhase);
  const [selectedClanId, setSelectedClanId] = useState<string>('0001');
  const snapshot = useMemo(() => getSnapshot(phase), [phase]);
  const [doctrine, setDoctrine] = useState({
    primary: snapshot.primaryStrategy,
    secondary: snapshot.secondaryStrategy,
    ethos: snapshot.ethos
  });
  const [whisperDraft, setWhisperDraft] = useState('Winter is coming. Pause monument work and stockpile wood.');
  const [sentWhispers, setSentWhispers] = useState<{ id: string; body: string }[]>([]);

  const selectedClan = snapshot.clans.find((clan) => clan.clanId === selectedClanId) ?? snapshot.clans[0];

  const updateDoctrine = (partial: Partial<AppState['doctrine']>) => {
    setDoctrine((prev) => ({ ...prev, ...partial }));
  };

  const sendWhisper = () => {
    const body = whisperDraft.trim();
    if (!body) return;
    setSentWhispers((prev) => [{ id: `${Date.now()}`, body }, ...prev]);
    setWhisperDraft('');
  };

  const value: AppState = {
    phase,
    setPhase,
    snapshot,
    selectedClan,
    setSelectedClanId,
    doctrine,
    updateDoctrine,
    whisperDraft,
    setWhisperDraft,
    sentWhispers,
    sendWhisper
  };

  return <AppStateContext.Provider value={value}>{children}</AppStateContext.Provider>;
};

export const useAppState = () => {
  const ctx = useContext(AppStateContext);
  if (!ctx) throw new Error('AppStateProvider missing');
  return ctx;
};
