import { InfoCard } from '../components/InfoCard';
import { useAppState } from '../lib/useAppState';

export const ElderPage = () => {
  const { doctrine, updateDoctrine, whisperDraft, setWhisperDraft, sendWhisper, sentWhispers, snapshot, selectedClan } = useAppState();

  return (
    <div className="page-grid two-col" data-page="elder">
      <section className="stack-col">
        <InfoCard title="Oracle View" tone="gold">
          <div className="hero-row">
            <div>
              <h2>{selectedClan.elderName}</h2>
              <p>Status: Thinking · Mood: Anxious about winter · Last action: Sent B to Unicorn Town.</p>
            </div>
            <div className="status-pill">Connected</div>
          </div>
        </InfoCard>

        <InfoCard title="Persistent Doctrine">
          <label className="field">
            <span>Primary Strategy</span>
            <textarea value={doctrine.primary} onChange={(e) => updateDoctrine({ primary: e.target.value })} rows={5} />
          </label>
          <label className="field">
            <span>Secondary Rules</span>
            <textarea value={doctrine.secondary} onChange={(e) => updateDoctrine({ secondary: e.target.value })} rows={5} />
          </label>
          <label className="field">
            <span>Personality / Ethos</span>
            <textarea value={doctrine.ethos} onChange={(e) => updateDoctrine({ ethos: e.target.value })} rows={4} />
          </label>
          <button className="primary-btn">Update Elder Doctrine</button>
          <pre className="code-preview">{`<primary_strategy>\n${doctrine.primary}\n</primary_strategy>\n\n<secondary_strategy>\n${doctrine.secondary}\n</secondary_strategy>\n\n<ethos>\n${doctrine.ethos}\n</ethos>`}</pre>
        </InfoCard>
      </section>

      <section className="stack-col">
        <InfoCard title="Send Divine Whisper">
          <label className="field">
            <span>Whisper to Elder...</span>
            <textarea value={whisperDraft} onChange={(e) => setWhisperDraft(e.target.value)} rows={5} />
          </label>
          <button className="primary-btn" onClick={sendWhisper}>Send Divine Whisper</button>
        </InfoCard>

        <InfoCard title="Message Log">
          <div className="tab-strip">
            <span className="tab active">All</span>
            <span className="tab">God</span>
            <span className="tab">AXL</span>
            <span className="tab">System</span>
          </div>
          <div className="event-stack">
            {sentWhispers.map((message) => (
              <article key={message.id} className="log-item accent">
                <div className="log-head"><strong>God AXL → {selectedClan.elderName}</strong><span>Now</span></div>
                <p>{message.body}</p>
              </article>
            ))}
            {snapshot.messages.map((message) => (
              <article key={message.id} className="log-item">
                <div className="log-head"><strong>{message.from} → {message.to}</strong><span>T{message.tick}</span></div>
                <p>{message.body}</p>
              </article>
            ))}
          </div>
        </InfoCard>
      </section>
    </div>
  );
};
