import { InfoCard } from '../components/InfoCard';
import { ResourceChips } from '../components/ResourceChips';
import { WorldMapPhaser } from '../components/WorldMapPhaser';
import { useAppState } from '../lib/useAppState';
import { titleCase } from '../lib/format';

export const WorldPage = () => {
  const { snapshot, selectedClan, setSelectedClanId } = useAppState();

  return (
    <div className="page-grid world-layout" data-page="world">
      <section className="panel hero-card map-card">
        <div className="hud-top">
          <div>
            <div className="eyebrow">God View</div>
            <h2>Whole World Map</h2>
          </div>
          <div className="tick-strip">
            <div><span>Tick</span><strong>{snapshot.tick}/{snapshot.seasonLength}</strong></div>
            <div><span>Winter In</span><strong>{snapshot.winterIn}</strong></div>
            <div><span>Bandits</span><strong>{snapshot.bandits.active ? `${titleCase(snapshot.bandits.state)} @ ${snapshot.bandits.regionId}` : 'None'}</strong></div>
          </div>
        </div>

        <WorldMapPhaser
          regions={snapshot.regions}
          clans={snapshot.clans}
          bandits={snapshot.bandits}
          tick={snapshot.tick}
          liveDemo={snapshot.liveDemoEnabled}
        />

        <div className="map-help">
          <span>Tap a region to zoom.</span>
          <span>Pinch or double-tap to reset.</span>
          <span>Drag to pan while zoomed.</span>
        </div>
      </section>

      <aside className="stack-col">
        <InfoCard title="Selected Clan">
          <div className="clan-selector-list">
            {snapshot.clans.map((clan) => (
              <button key={clan.clanId} className={clan.clanId === selectedClan.clanId ? 'clan-select active' : 'clan-select'} onClick={() => setSelectedClanId(clan.clanId)}>
                <span>{clan.clanId}</span>
                <strong>{clan.elderName}</strong>
              </button>
            ))}
          </div>
          <div className="mini-stat-grid">
            <div><span>Base</span><strong>{selectedClan.baseLevel}</strong></div>
            <div><span>Wall</span><strong>{selectedClan.wallLevel}</strong></div>
            <div><span>Monument</span><strong>{selectedClan.monumentLevel}</strong></div>
            <div><span>Readiness</span><strong>{selectedClan.winterReadiness.toUpperCase()}</strong></div>
          </div>
          <ResourceChips resources={selectedClan.resources} />
        </InfoCard>

        <InfoCard title="Phase Notes" tone={snapshot.phase === 'phase4' ? 'gold' : 'default'}>
          <ul className="compact-list">
            <li>Phase 1 and 4 are contract-independent visual demos.</li>
            <li>Phase 2 is shaped around a future contract adapter.</li>
            <li>Phase 3 adds doctrine editing and whisper controls.</li>
            <li>Mobile-friendly HUD stays readable in portrait mode.</li>
          </ul>
        </InfoCard>

        <InfoCard title="Recent Events" tone={snapshot.bandits.active ? 'danger' : 'good'}>
          <div className="event-stack">
            {snapshot.events.map((event) => (
              <article key={event.id} className="log-item">
                <div className="log-head">
                  <strong>{event.title}</strong>
                  <span>T{event.tick}</span>
                </div>
                <p>{event.body}</p>
              </article>
            ))}
          </div>
        </InfoCard>
      </aside>
    </div>
  );
};
