import { InfoCard } from '../components/InfoCard';
import { useAppState } from '../lib/useAppState';

export const LogsPage = () => {
  const { snapshot } = useAppState();

  return (
    <div className="page-grid two-col" data-page="logs">
      <section className="stack-col">
        <InfoCard title="World Event Log">
          <div className="event-stack dense">
            {snapshot.events.map((event) => (
              <article className="log-item" key={event.id}>
                <div className="log-head"><strong>{event.kind.toUpperCase()}</strong><span>T{event.tick}</span></div>
                <h3>{event.title}</h3>
                <p>{event.body}</p>
              </article>
            ))}
          </div>
        </InfoCard>
      </section>
      <section className="stack-col">
        <InfoCard title="AXL Comms Dashboard" tone="gold">
          <div className="agent-grid">
            {['Ashroot', 'Glint', 'Foam', 'Thorn'].map((name) => (
              <div key={name} className="agent-box">
                <strong>{name}</strong>
                <span>0G state synced</span>
              </div>
            ))}
          </div>
          <div className="signal-lines">
            <div className="signal a" />
            <div className="signal b" />
            <div className="signal c" />
          </div>
          <p className="muted">Animated signal lanes hint at AXL messages and tool-call activity without needing a heavy real-time backend for the demo.</p>
        </InfoCard>

        <InfoCard title="Recent Messages">
          <div className="event-stack dense">
            {snapshot.messages.map((message) => (
              <article className="log-item" key={message.id}>
                <div className="log-head"><strong>{message.from}</strong><span>T{message.tick}</span></div>
                <p>{message.body}</p>
              </article>
            ))}
          </div>
        </InfoCard>
      </section>
    </div>
  );
};
