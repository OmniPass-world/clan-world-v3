import { InfoCard } from '../components/InfoCard';
import { ResourceChips } from '../components/ResourceChips';
import { useAppState } from '../lib/useAppState';
import { fmt } from '../lib/format';

export const ClanPage = () => {
  const { selectedClan } = useAppState();
  const readinessNeed = {
    wood: 10,
    wheat: 20,
    fish: 2
  };

  return (
    <div className="page-grid two-col" data-page="clan">
      <section className="stack-col">
        <InfoCard title={`${selectedClan.elderName} · ${selectedClan.clanId}`}>
          <div className="hero-row">
            <div>
              <h2>{selectedClan.motto}</h2>
              <p>Rank #{selectedClan.rank} · Base in {selectedClan.location}</p>
            </div>
            <div className="rank-pips">🏰 {selectedClan.baseLevel} · 🛡 {selectedClan.wallLevel} · 🗿 {selectedClan.monumentLevel}</div>
          </div>
          <ResourceChips resources={selectedClan.resources} />
        </InfoCard>

        <InfoCard title="Winter Readiness" tone={selectedClan.winterReadiness === 'low' ? 'danger' : 'good'}>
          <div className="readiness-grid">
            <div><span>Wood buffer</span><strong>{fmt(selectedClan.resources.wood)} / {readinessNeed.wood}</strong></div>
            <div><span>Wheat</span><strong>{fmt(selectedClan.resources.wheat)} / {readinessNeed.wheat}</strong></div>
            <div><span>Fish</span><strong>{fmt(selectedClan.resources.fish)} / {readinessNeed.fish}</strong></div>
            <div><span>Risk</span><strong>{selectedClan.winterReadiness.toUpperCase()}</strong></div>
          </div>
          <p className="muted">Starvation weakens workers but only winter cold kills. This card helps explain why the Elder is panicking.</p>
        </InfoCard>
      </section>

      <section className="stack-col">
        <InfoCard title="Clansmen">
          <div className="worker-list">
            {selectedClan.workers.map((worker) => (
              <article className="worker-card" key={worker.id}>
                <div className="worker-head">
                  <strong>{worker.name}</strong>
                  <span>{worker.role}</span>
                </div>
                <div className="worker-grid">
                  <div><span>Region</span><strong>{worker.regionId}</strong></div>
                  <div><span>Status</span><strong>{worker.status}</strong></div>
                  <div><span>Mission</span><strong>{worker.mission}</strong></div>
                  <div><span>Cooldown</span><strong>{worker.cooldownSeconds === 0 ? 'Ready' : `${worker.cooldownSeconds}s`}</strong></div>
                </div>
                <div className="carry-row">
                  {Object.entries(worker.carry).length === 0 ? <span className="muted">No carry</span> : Object.entries(worker.carry).map(([key, value]) => <span key={key}>{key}: {fmt(value ?? 0)}</span>)}
                </div>
              </article>
            ))}
          </div>
        </InfoCard>
      </section>
    </div>
  );
};
