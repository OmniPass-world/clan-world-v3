import Phaser from 'phaser';
import { useEffect, useRef } from 'react';
import type { BanditState, ClanSummary, RegionMeta } from '@elder-realms/shared';

const clanColors = ['0xffc857', '0x76e3ff', '0x8efc88', '0xff7f9f'];

const roleFrame: Record<string, number> = {
  woodcutter: 0,
  miner: 4,
  farmer: 8,
  fisher: 12,
  defender: 2,
  trader: 6,
  hauler: 10
};

interface Props {
  regions: RegionMeta[];
  clans: ClanSummary[];
  bandits: BanditState;
  tick: number;
  liveDemo: boolean;
}

class WorldScene extends Phaser.Scene {
  private props!: Props;
  private selectedRegion: string | null = null;
  private lastTapTime = 0;
  private movingSprite?: Phaser.GameObjects.Sprite;

  constructor() {
    super('world-scene');
  }

  init(data: Props) {
    this.props = data;
  }

  preload() {
    this.load.image('map', '/assets/world-map.png');
    this.load.spritesheet('workers', '/assets/worker-sheet.png', { frameWidth: 16, frameHeight: 16 });
  }

  create() {
    const map = this.add.image(190, 240, 'map');
    map.setDisplaySize(380, 480);

    const cam = this.cameras.main;
    cam.setBounds(0, 0, 380, 480);
    cam.setZoom(1);

    const dragState = { dragging: false, lastX: 0, lastY: 0 };
    this.input.on('pointerdown', (pointer: Phaser.Input.Pointer) => {
      dragState.dragging = true;
      dragState.lastX = pointer.x;
      dragState.lastY = pointer.y;
    });
    this.input.on('pointermove', (pointer: Phaser.Input.Pointer) => {
      if (!dragState.dragging || !pointer.isDown || cam.zoom <= 1.2) return;
      cam.scrollX -= (pointer.x - dragState.lastX) / cam.zoom;
      cam.scrollY -= (pointer.y - dragState.lastY) / cam.zoom;
      dragState.lastX = pointer.x;
      dragState.lastY = pointer.y;
    });
    this.input.on('pointerup', () => {
      dragState.dragging = false;
    });

    this.props.regions.forEach((region) => {
      const badge = this.add.circle(region.x, region.y, 14, 0x171321, 0.8).setStrokeStyle(2, 0xffcf57, 0.8);
      const txt = this.add.text(region.x, region.y - 3, region.label.replace(' ', '\n'), {
        fontFamily: 'monospace',
        fontSize: '8px',
        color: '#fff3d3',
        align: 'center'
      }).setOrigin(0.5, 0.5);
      const zone = this.add.zone(region.x, region.y, 36, 36).setInteractive({ useHandCursor: true });
      zone.on('pointerup', () => {
        const now = this.time.now;
        if (now - this.lastTapTime < 250) {
          this.resetZoom();
        } else {
          this.zoomToRegion(region.id);
        }
        this.lastTapTime = now;
      });
      txt.setDepth(4);
      badge.setDepth(3);
      zone.setDepth(5);
    });

    this.props.clans.forEach((clan, clanIndex) => {
      const region = this.props.regions.find((r) => r.id === clan.location);
      if (!region) return;
      this.add.rectangle(region.x + 22, region.y - 14 + clanIndex * 5, 8, 8, parseInt(clanColors[clanIndex % clanColors.length], 16)).setDepth(4);
      this.add.rectangle(region.x + 22, region.y - 14 + clanIndex * 5, 8, 8).setStrokeStyle(1, 0x180d1c).setDepth(5);
      clan.workers.forEach((worker, workerIndex) => {
        const workerRegion = this.props.regions.find((r) => r.id === worker.regionId) ?? region;
        const sprite = this.add.sprite(workerRegion.x - 12 + (workerIndex % 2) * 10, workerRegion.y + 12 + Math.floor(workerIndex / 2) * 10, 'workers', roleFrame[worker.role] ?? 0);
        sprite.setScale(1.2);
        sprite.setTint(parseInt(clanColors[clanIndex % clanColors.length], 16));
        sprite.setDepth(6);
        this.tweens.add({
          targets: sprite,
          y: sprite.y - 2,
          duration: 700 + workerIndex * 90,
          yoyo: true,
          repeat: -1
        });
      });
    });

    if (this.props.bandits.active && this.props.bandits.regionId) {
      const banditRegion = this.props.regions.find((r) => r.id === this.props.bandits.regionId);
      if (banditRegion) {
        const flag = this.add.rectangle(banditRegion.x - 22, banditRegion.y - 18, 10, 14, 0xb42f42).setDepth(7);
        this.add.rectangle(banditRegion.x - 20, banditRegion.y - 19, 3, 16, 0xf5efe0).setDepth(7);
        this.add.text(banditRegion.x - 22, banditRegion.y - 32, `${this.props.bandits.countdown}`, {
          fontFamily: 'monospace',
          fontSize: '12px',
          color: '#ffd2d9'
        }).setOrigin(0.5).setDepth(8);
        this.tweens.add({ targets: flag, alpha: 0.3, duration: 500, repeat: -1, yoyo: true });
      }
    }

    if (this.props.liveDemo) {
      this.runDemo();
    }
  }

  private zoomToRegion(regionId: string) {
    const region = this.props.regions.find((r) => r.id === regionId);
    if (!region) return;
    this.selectedRegion = regionId;
    this.cameras.main.pan(region.x, region.y, 400, 'Sine.easeInOut');
    this.cameras.main.zoomTo(2.6, 400);
  }

  private resetZoom() {
    this.selectedRegion = null;
    this.cameras.main.pan(190, 240, 300, 'Sine.easeInOut');
    this.cameras.main.zoomTo(1, 300);
  }

  private runDemo() {
    const from = this.props.regions.find((r) => r.id === 'west-farms');
    const to = this.props.regions.find((r) => r.id === 'east-farms');
    if (!from || !to) return;
    this.movingSprite = this.add.sprite(from.x + 26, from.y + 18, 'workers', 2).setScale(1.4).setTint(0xffc857).setDepth(9);
    this.add.text(188, 20, 'LIVE DEMO', {
      fontFamily: 'monospace',
      fontSize: '12px',
      color: '#ffef93',
      backgroundColor: '#3d2740',
      padding: { x: 6, y: 2 }
    }).setOrigin(0.5, 0).setDepth(10);
    this.time.delayedCall(900, () => {
      const line = this.add.line(0, 0, from.x + 26, from.y + 18, to.x - 10, to.y - 10, 0xffef93, 0.9).setLineWidth(2).setOrigin(0, 0).setDepth(8);
      this.tweens.add({
        targets: this.movingSprite,
        x: to.x - 10,
        y: to.y - 10,
        duration: 1400,
        ease: 'Sine.easeInOut'
      });
      this.time.delayedCall(1700, () => {
        this.add.circle(to.x - 6, to.y - 20, 14, 0xffef93, 0.25).setDepth(9);
        this.add.text(to.x - 4, to.y - 34, '+Blueprint', {
          fontFamily: 'monospace',
          fontSize: '10px',
          color: '#fff7ca'
        }).setOrigin(0.5).setDepth(10);
        line.destroy();
      });
    });
  }
}

export const WorldMapPhaser = (props: Props) => {
  const ref = useRef<HTMLDivElement | null>(null);
  const gameRef = useRef<Phaser.Game | null>(null);

  useEffect(() => {
    if (!ref.current) return;
    const game = new Phaser.Game({
      type: Phaser.CANVAS,
      width: 380,
      height: 480,
      parent: ref.current,
      backgroundColor: '#0f1220',
      scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH,
        width: 380,
        height: 480
      },
      render: { pixelArt: true, antialias: false },
      scene: [WorldScene]
    });
    gameRef.current = game;
    game.scene.start('world-scene', props);

    return () => {
      game.destroy(true);
      gameRef.current = null;
    };
  }, [props.bandits, props.clans, props.liveDemo, props.regions, props.tick]);

  return <div className="phaser-shell" ref={ref} />;
};
