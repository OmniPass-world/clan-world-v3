export const InfoCard = ({ title, children, tone = 'default' }: { title: string; children: React.ReactNode; tone?: 'default' | 'danger' | 'good' | 'gold' }) => {
  return (
    <section className={`panel info-card ${tone}`}>
      <div className="section-title">{title}</div>
      {children}
    </section>
  );
};
