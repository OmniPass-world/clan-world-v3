import { fmt } from '../lib/format';
import type { ResourceSet } from '@elder-realms/shared';

const icons: Record<keyof ResourceSet, string> = {
  wood: '🪵',
  wheat: '🌾',
  fish: '🐟',
  iron: '⛓',
  gold: '🪙',
  blueprint: '📜'
};

export const ResourceChips = ({ resources }: { resources: ResourceSet }) => {
  return (
    <div className="resource-row">
      {(Object.keys(resources) as (keyof ResourceSet)[]).map((key) => (
        <div key={key} className="resource-chip">
          <span>{icons[key]}</span>
          <strong>{fmt(resources[key])}</strong>
        </div>
      ))}
    </div>
  );
};
