import { expect, test } from '@playwright/test';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const phases = ['phase1', 'phase2', 'phase3', 'phase4'] as const;
const pages = ['world', 'clan', 'elder', 'logs'] as const;
const outputDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../../artifacts/screenshots');

for (const phase of phases) {
  for (const pageName of pages) {
    test(`${phase} ${pageName} screenshot`, async ({ page }) => {
      fs.mkdirSync(outputDir, { recursive: true });
      await page.goto(`/#/${pageName}?phase=${phase}`);
      await page.waitForLoadState('networkidle');
      await page.waitForTimeout(pageName === 'world' && phase === 'phase4' ? 2600 : 800);
      await expect(page.locator('body')).toContainText('Elder Realms');
      await page.screenshot({ path: path.join(outputDir, `${phase}-${pageName}.png`), fullPage: true });
    });
  }
}
