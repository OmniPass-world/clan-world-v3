import { describe, expect, it } from 'vitest';
import { parsePhase } from '../src/lib/phase';
import { getSnapshot } from '@elder-realms/shared';

describe('phase handling', () => {
  it('falls back to phase1 for invalid input', () => {
    expect(parsePhase('weird')).toBe('phase1');
  });

  it('loads a live-demo snapshot for phase4', () => {
    expect(getSnapshot('phase4').liveDemoEnabled).toBe(true);
  });
});
