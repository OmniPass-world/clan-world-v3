#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
ZIP_PATH="/mnt/data/elder-realms-demo.zip"
rm -f "$ZIP_PATH"
zip -qr "$ZIP_PATH" . -x "*/node_modules/*" "*/dist/*" "*.DS_Store"
echo "$ZIP_PATH"
