from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
ASSET_DIR = ROOT / 'apps' / 'web' / 'public' / 'assets'
ASSET_DIR.mkdir(parents=True, exist_ok=True)

SCALE = 2
W, H = 190, 240

palette = {
    'bg': '#5cb4ff',
    'cloud': '#dff7ff',
    'forest': '#2d6b45',
    'forest2': '#1d4f34',
    'mountain': '#7a8090',
    'mountain2': '#52576b',
    'town': '#efdf9a',
    'town2': '#c9a54b',
    'farm': '#c9b054',
    'farm2': '#8d7f35',
    'dock': '#4f84b8',
    'dock2': '#2c5b8c',
    'sea': '#2c4a92',
    'sea2': '#17316e',
    'sand': '#d2c399',
    'road': '#9b7655',
    'wall': '#7c5642'
}

img = Image.new('RGBA', (W, H), palette['bg'])
d = ImageDraw.Draw(img)

# Ocean lower half
for y in range(H):
    if y > 170:
        color = palette['sea'] if (y // 2) % 2 == 0 else palette['sea2']
        d.line([(0, y), (W, y)], fill=color)

# Clouds
for (x, y) in [(20, 18), (135, 22), (155, 48)]:
    d.rectangle([x, y, x + 12, y + 4], fill=palette['cloud'])
    d.rectangle([x + 2, y - 2, x + 10, y + 6], fill=palette['cloud'])

# Region islands / landmasses
# Forest
forest = [28, 30, 74, 76]
d.rounded_rectangle(forest, radius=4, fill=palette['forest'])
for tx, ty in [(36, 36), (50, 40), (60, 52), (42, 60), (62, 34)]:
    d.rectangle([tx, ty, tx + 4, ty + 8], fill=palette['forest2'])
    d.rectangle([tx - 2, ty - 2, tx + 6, ty + 2], fill=palette['forest'])

# Mountains
mtn = [108, 30, 160, 74]
d.rounded_rectangle(mtn, radius=4, fill='#91a2aa')
for tri in [(118, 64), (132, 42), (146, 66), (154, 48)]:
    x, peak = tri
    d.polygon([(x - 8, 70), (x, peak), (x + 8, 70)], fill=palette['mountain'])
    d.polygon([(x - 4, 66), (x, peak + 5), (x + 4, 66)], fill=palette['mountain2'])

# Town
city = [72, 66, 118, 96]
d.rounded_rectangle(city, radius=4, fill=palette['town'])
for bx, by in [(79, 76), (88, 72), (97, 76), (106, 72)]:
    d.rectangle([bx, by, bx + 6, by + 9], fill=palette['town2'])
    d.rectangle([bx + 2, by - 3, bx + 4, by], fill='#ff5ca0')

# Farms west/east
for rect in ([28, 98, 82, 140], [108, 98, 162, 140]):
    d.rounded_rectangle(rect, radius=4, fill=palette['farm'])
    for sx in range(rect[0] + 5, rect[2] - 4, 8):
        d.line([(sx, rect[1] + 4), (sx, rect[3] - 5)], fill=palette['farm2'])
    for sy in range(rect[1] + 5, rect[3] - 4, 8):
        d.line([(rect[0] + 4, sy), (rect[2] - 5, sy)], fill=palette['farm2'])

# Docks west/east
for rect in ([26, 145, 82, 180], [108, 145, 164, 180]):
    d.rounded_rectangle(rect, radius=4, fill=palette['dock'])
    for px in range(rect[0] + 5, rect[2] - 6, 10):
        d.rectangle([px, rect[3] - 8, px + 3, rect[3] + 4], fill=palette['dock2'])
        d.rectangle([px + 3, rect[3] - 8, px + 10, rect[3] - 5], fill='#a57a4f')

# Deep sea island / waves
for y in range(184, H, 6):
    for x in range(10, W, 24):
        d.line([(x, y), (x + 12, y)], fill='#93bbff')
        d.point((x + 2, y - 1), fill='#d8ecff')

# Connecting roads
for path in [((56, 76), (94, 82)), ((94, 96), (54, 116)), ((96, 96), (136, 116)), ((54, 140), (54, 145)), ((136, 140), (136, 145))]:
    d.line([path[0], path[1]], fill=palette['road'], width=3)

# Base / walls / monument icons
for (x, y, c) in [(50, 112, '#ffcf57'), (138, 42, '#76e3ff'), (138, 160, '#8efc88'), (50, 44, '#ff7f9f')]:
    d.rectangle([x, y, x + 6, y + 6], fill=c)
    d.rectangle([x - 2, y + 6, x + 8, y + 8], fill=palette['wall'])

# upscale pixel-perfect
img = img.resize((W * SCALE, H * SCALE), resample=Image.Resampling.NEAREST)
img.save(ASSET_DIR / 'world-map.png')

# Worker sprite sheet 4x4 frames, 16x16 each
sheet = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
sd = ImageDraw.Draw(sheet)
role_colors = ['#ffcf57', '#ffcf57', '#ffcf57', '#ffcf57', '#76e3ff', '#76e3ff', '#76e3ff', '#76e3ff', '#8efc88', '#8efc88', '#8efc88', '#8efc88', '#ff7f9f', '#ff7f9f', '#ff7f9f', '#ff7f9f']
accents = ['#7e3b20', '#523b99', '#7e3b20', '#523b99']
for i in range(16):
    x = (i % 4) * 16
    y = (i // 4) * 16
    c = role_colors[i]
    a = accents[i % 4]
    # shadow
    sd.rectangle([x + 5, y + 13, x + 11, y + 14], fill=(0, 0, 0, 80))
    # body
    sd.rectangle([x + 6, y + 5, x + 10, y + 11], fill=c)
    sd.rectangle([x + 7, y + 2, x + 9, y + 4], fill='#f0d5b0')
    # feet pose variation
    foot_shift = 0 if i % 2 == 0 else 1
    sd.rectangle([x + 6, y + 12, x + 7, y + 14], fill=a)
    sd.rectangle([x + 9 + foot_shift, y + 12, x + 10 + foot_shift, y + 14], fill=a)
    # tool hints by frame group
    row = i // 4
    if row == 0:  # woodcutter/defender mix
        sd.line([(x + 11, y + 5), (x + 13, y + 10)], fill='#b7b7b7', width=1)
        sd.rectangle([x + 12, y + 8, x + 14, y + 10], fill='#9a9a9a')
    elif row == 1:  # miner/trader
        sd.line([(x + 11, y + 6), (x + 13, y + 10)], fill='#d0d0d0', width=1)
        sd.line([(x + 12, y + 8), (x + 14, y + 8)], fill='#d0d0d0', width=1)
    elif row == 2:  # farmer/hauler
        sd.rectangle([x + 11, y + 8, x + 14, y + 11], fill='#8a5a35')
    else:  # fisher
        sd.line([(x + 11, y + 5), (x + 14, y + 11)], fill='#3d2f20', width=1)
        sd.point((x + 14, y + 11), fill='#dfefff')

sheet = sheet.resize((128, 128), resample=Image.Resampling.NEAREST)
sheet.save(ASSET_DIR / 'worker-sheet.png')

print(f'Generated assets in {ASSET_DIR}')
