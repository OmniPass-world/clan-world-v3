# Pixel Art Direction

This project ships with placeholder pixel assets generated locally for demo purposes.

## Style goals
- 8-bit inspired pixel art
- crisp nearest-neighbor scaling
- readable on modern phones
- fantasy strategy mood with playful HUD chrome

## Dimensions
- Terrain tile: 16x16 px
- Worker frame: 16x16 px
- Structure frame: 32x32 px
- HUD icons: 16x16 px

## Current included placeholder sheets
- `terrain_tiles.png`
- `workers_sheet.png`
- `structures_sheet.png`
- `hud_icons.png`

## Recommended final production sheets
- Terrain: 64+ tiles including transitions, winter variants, and decorative overlays
- Workers: 4 clans x 10+ actions x 4-8 directional frames
- Structures: homebase L1-L5, walls L0-L5, monument L0-L10, bandit camp L1-L3, dock states
- Effects: snowfall, sparkles, attack burst, market coins, speech pips
