# Sprite Manifest

## Terrain
- Forest
- Mountains
- Unicorn Town
- Farmland
- Docks
- Deep Sea

## Workers (placeholder included)
Rows: red, yellow, blue, green clans
Columns: idle, walk, chop, mine, fish, defend

## Required future worker frames
- push wheelbarrow empty / half / full
- unload / withdraw
- build walls / build monument / repair
- winter and frostbite variants
- death / frozen variant
- pray / whisper / waiting

## Structures
- Home base
- Wall
- Monument
- Bandit camp
- Dock / pier accent

## HUD
- wood, wheat, fish, iron, gold, blueprint icons
