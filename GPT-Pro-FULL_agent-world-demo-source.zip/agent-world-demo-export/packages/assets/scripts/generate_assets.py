from PIL import Image, ImageDraw
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'generated'
OUT.mkdir(parents=True, exist_ok=True)
DOCS = ROOT / 'docs'
DOCS.mkdir(parents=True, exist_ok=True)

SCALE = 4

def px(img, x, y, color, s=1):
    d = ImageDraw.Draw(img)
    d.rectangle([x*SCALE, y*SCALE, (x+s)*SCALE-1, (y+s)*SCALE-1], fill=color)

# Palettes
BG = (18, 24, 38, 255)
BLACK = (31, 33, 44, 255)
WHITE = (240, 243, 250, 255)
TREE = (44, 128, 76, 255)
TREE2 = (32, 88, 52, 255)
MOUNTAIN = (124, 129, 154, 255)
MOUNTAIN2 = (83, 87, 103, 255)
TOWN = (189, 93, 193, 255)
ROAD = (192, 160, 107, 255)
FIELD = (199, 169, 58, 255)
FIELD2 = (143, 111, 34, 255)
SEA = (45, 103, 196, 255)
SEA2 = (23, 66, 142, 255)
DOCK = (121, 85, 48, 255)
SNOW = (223, 236, 255, 255)
RED = (201, 79, 79, 255)
BLUE = (84, 122, 224, 255)
GREEN = (92, 191, 98, 255)
YELLOW = (220, 188, 72, 255)
ORANGE = (225, 138, 49, 255)
GOLD = (238, 194, 69, 255)

# Terrain tiles sprite sheet 16x16 tiles, 5x3 tiles
terrain = Image.new('RGBA', (16*5*SCALE, 16*3*SCALE), (0,0,0,0))

def draw_forest(ox, oy):
    for y in range(16):
        for x in range(16):
            px(terrain, ox+x, oy+y, (75, 132, 69,255))
    for x,y in [(3,3),(9,2),(5,9),(11,10)]:
        for dx,dy in [(0,1),(1,0),(1,1),(1,2),(2,1)]:
            px(terrain, ox+x+dx, oy+y+dy, TREE)
        px(terrain, ox+x+1, oy+y+3, TREE2)

def draw_mountain(ox, oy):
    for y in range(16):
        for x in range(16):
            px(terrain, ox+x, oy+y, (121, 171, 94,255))
    peaks=[(2,8),(6,4),(10,7)]
    for x,y in peaks:
        for i in range(4):
            px(terrain, ox+x+i, oy+y+i, MOUNTAIN)
            px(terrain, ox+x+7-i, oy+y+i, MOUNTAIN)
            for xx in range(x+i+1, x+7-i):
                px(terrain, ox+xx, oy+y+i, MOUNTAIN if i<3 else MOUNTAIN2)
        px(terrain, ox+x+3, oy+y, SNOW)
        px(terrain, ox+x+4, oy+y+1, SNOW)

def draw_town(ox, oy):
    for y in range(16):
        for x in range(16):
            px(terrain, ox+x, oy+y, (166, 186, 117,255))
    for x in range(2,14): px(terrain, ox+x, oy+12, ROAD)
    for x,y,w,h,c in [(2,5,4,5,TOWN),(8,6,5,4,(100,87,182,255))]:
        for yy in range(h):
            for xx in range(w): px(terrain, ox+x+xx, oy+y+yy, c)
        for xx in range(w): px(terrain, ox+x+xx, oy+y-1, RED if c==TOWN else BLUE)
    px(terrain, ox+11, oy+4, WHITE); px(terrain, ox+11, oy+5, WHITE)

def draw_field(ox, oy):
    for y in range(16):
        for x in range(16):
            px(terrain, ox+x, oy+y, (144, 171, 89,255))
    for r in [3,6,9,12]:
        for x in range(1,15): px(terrain, ox+x, oy+r, FIELD)
    for x in range(1,15,2):
        for y in [2,5,8,11,14]: px(terrain, ox+x, oy+y, FIELD2)

def draw_dock(ox, oy):
    for y in range(16):
        for x in range(16):
            px(terrain, ox+x, oy+y, SEA if y>7 else (190, 189, 145,255))
    for y in range(8,16):
        px(terrain, ox+6, oy+y, DOCK); px(terrain, ox+7, oy+y, DOCK)
    for x in range(3,11):
        px(terrain, ox+x, oy+9, DOCK)
    px(terrain, ox+10, oy+10, WHITE); px(terrain, ox+11, oy+11, WHITE)

def draw_sea(ox, oy):
    for y in range(16):
        for x in range(16):
            px(terrain, ox+x, oy+y, SEA if (x+y)%4 else SEA2)
    for x,y in [(2,3),(9,6),(6,11)]:
        px(terrain, ox+x, oy+y, WHITE); px(terrain, ox+x+1, oy+y, WHITE)

for i,fn in enumerate([draw_forest, draw_mountain, draw_town, draw_field, draw_dock, draw_sea]):
    fn((i%5)*16, (i//5)*16)
terrain.save(OUT/'terrain_tiles.png')

# Worker sprite sheet 16x16 tiles, 4 clans x 6 states
worker = Image.new('RGBA', (16*6*SCALE, 16*4*SCALE), (0,0,0,0))
clrs=[RED,YELLOW,BLUE,GREEN]
states=['idle','walk','chop','mine','fish','defend']
for row,c in enumerate(clrs):
    for col,state in enumerate(states):
        ox, oy = col*16, row*16
        # shadow
        for x in range(5,11): px(worker, ox+x, oy+13, (0,0,0,70))
        # body
        for x in range(6,10):
            for y in range(6,12): px(worker, ox+x, oy+y, c)
        for x in range(5,11):
            for y in range(3,7): px(worker, ox+x, oy+y, (235, 205, 171,255))
        px(worker, ox+7, oy+4, BLACK); px(worker, ox+9, oy+4, BLACK)
        # hat
        for x in range(5,11): px(worker, ox+x, oy+2, BLACK)
        for x in range(6,10): px(worker, ox+x, oy+1, BLACK)
        # state props
        if state == 'walk':
            px(worker, ox+5, oy+12, BLACK); px(worker, ox+10, oy+12, BLACK)
        elif state == 'chop':
            for x,y in [(11,7),(12,8),(10,8),(9,9)]: px(worker, ox+x, oy+y, MOUNTAIN)
            for y in range(8,14): px(worker, ox+13, oy+y, TREE2)
        elif state == 'mine':
            for x,y in [(11,7),(12,8),(10,8),(9,9)]: px(worker, ox+x, oy+y, MOUNTAIN)
            for y in range(10,14): px(worker, ox+13, oy+y, MOUNTAIN2)
        elif state == 'fish':
            for x in range(10,14): px(worker, ox+x, oy+6+(x-10), BLACK)
            px(worker, ox+13, oy+11, SEA)
        elif state == 'defend':
            for y in range(6,13): px(worker, ox+12, oy+y, MOUNTAIN2)
            for x in range(10,14): px(worker, ox+x, oy+5, BLACK)
            for y in range(7,12): px(worker, ox+4, oy+y, BLACK)
worker.save(OUT/'workers_sheet.png')

# Structures
structures = Image.new('RGBA', (32*4*SCALE, 32*2*SCALE), (0,0,0,0))

def rect(img, ox, oy, x, y, w, h, c):
    d = ImageDraw.Draw(img)
    d.rectangle([(ox+x)*SCALE,(oy+y)*SCALE,(ox+x+w)*SCALE-1,(oy+y+h)*SCALE-1], fill=c)

# base, wall, monument, bandit camp, docks, castle maybe
for idx in range(4):
    ox = idx*32
    # base
    rect(structures, ox, 0, 6, 14, 20, 12, (130,94,53,255))
    rect(structures, ox, 0, 10, 8, 12, 8, (190,164,116,255))
    rect(structures, ox, 0, 8, 6, 16, 3, RED if idx%2==0 else BLUE)
    # wall variations in bottom row
    rect(structures, ox, 32, 5, 20, 22, 6, MOUNTAIN2)
    for x in range(6,26,4): rect(structures, ox, 32, x, 17, 2, 4, MOUNTAIN)
    if idx==1:
        rect(structures, ox, 32, 12, 6, 8, 18, GOLD)
    elif idx==2:
        rect(structures, ox, 32, 10, 8, 12, 12, BLACK); rect(structures, ox, 32, 12, 10, 8, 8, RED)
    elif idx==3:
        rect(structures, ox, 32, 9, 10, 14, 10, DOCK); rect(structures, ox, 32, 14, 6, 4, 18, BLACK)
structures.save(OUT/'structures_sheet.png')

# UI icons
icons = Image.new('RGBA', (16*6*SCALE, 16*SCALE), (0,0,0,0))
# wood
for y in range(3,13): px(icons, 4, y, DOCK)
for x in range(5,11): px(icons, x, 5, TREE)
# wheat
for y in range(4,13): px(icons, 16+7, y, FIELD2)
for y in [5,7,9,11]:
    px(icons, 16+5, y, FIELD); px(icons, 16+9, y+1, FIELD)
# fish
for x,y in [(32+4,8),(32+5,7),(32+6,6),(32+7,6),(32+8,7),(32+9,8),(32+8,9),(32+7,10),(32+6,10),(32+5,9)]: px(icons, x,y, SEA)
# iron
for x in range(48+4,48+11): px(icons, x, 9-(x-(48+4))//2, MOUNTAIN2)
# gold
for x in range(64+5,64+10):
    for y in range(5,10): px(icons, x, y, GOLD)
# blueprint
for x in range(80+4,80+12):
    for y in range(4,12): px(icons, x, y, (213,205,181,255))
for x in range(80+5,80+11): px(icons, x, 6, BLUE)
icons.save(OUT/'hud_icons.png')

with open(DOCS/'art-direction.md','w') as f:
    f.write('''# Pixel Art Direction\n\nThis project ships with placeholder pixel assets generated locally for demo purposes.\n\n## Style goals\n- 8-bit inspired pixel art\n- crisp nearest-neighbor scaling\n- readable on modern phones\n- fantasy strategy mood with playful HUD chrome\n\n## Dimensions\n- Terrain tile: 16x16 px\n- Worker frame: 16x16 px\n- Structure frame: 32x32 px\n- HUD icons: 16x16 px\n\n## Current included placeholder sheets\n- `terrain_tiles.png`\n- `workers_sheet.png`\n- `structures_sheet.png`\n- `hud_icons.png`\n\n## Recommended final production sheets\n- Terrain: 64+ tiles including transitions, winter variants, and decorative overlays\n- Workers: 4 clans x 10+ actions x 4-8 directional frames\n- Structures: homebase L1-L5, walls L0-L5, monument L0-L10, bandit camp L1-L3, dock states\n- Effects: snowfall, sparkles, attack burst, market coins, speech pips\n''')

with open(DOCS/'sprite-manifest.md','w') as f:
    f.write('''# Sprite Manifest\n\n## Terrain\n- Forest\n- Mountains\n- Unicorn Town\n- Farmland\n- Docks\n- Deep Sea\n\n## Workers (placeholder included)\nRows: red, yellow, blue, green clans\nColumns: idle, walk, chop, mine, fish, defend\n\n## Required future worker frames\n- push wheelbarrow empty / half / full\n- unload / withdraw\n- build walls / build monument / repair\n- winter and frostbite variants\n- death / frozen variant\n- pray / whisper / waiting\n\n## Structures\n- Home base\n- Wall\n- Monument\n- Bandit camp\n- Dock / pier accent\n\n## HUD\n- wood, wheat, fish, iron, gold, blueprint icons\n''')

print('Generated assets into', OUT)
