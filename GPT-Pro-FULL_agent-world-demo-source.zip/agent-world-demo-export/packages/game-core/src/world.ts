import type { RegionId } from './types';

export interface RegionDef {
  id: RegionId;
  name: string;
  biome: 'forest' | 'mountain' | 'town' | 'farm' | 'dock' | 'sea';
  x: number;
  y: number;
  w: number;
  h: number;
  labelX: number;
  labelY: number;
}

export const WORLD_WIDTH = 480;
export const WORLD_HEIGHT = 800;

export const REGIONS: RegionDef[] = [
  { id: 'forest', name: 'Forest', biome: 'forest', x: 48, y: 48, w: 176, h: 160, labelX: 92, labelY: 72 },
  { id: 'mountains', name: 'Mountains', biome: 'mountain', x: 256, y: 48, w: 176, h: 160, labelX: 286, labelY: 72 },
  { id: 'unicorn-town', name: 'Unicorn Town', biome: 'town', x: 148, y: 236, w: 184, h: 120, labelX: 174, labelY: 254 },
  { id: 'west-farms', name: 'West Farms', biome: 'farm', x: 32, y: 392, w: 176, h: 116, labelX: 58, labelY: 412 },
  { id: 'east-farms', name: 'East Farms', biome: 'farm', x: 272, y: 392, w: 176, h: 116, labelX: 298, labelY: 412 },
  { id: 'west-docks', name: 'West Docks', biome: 'dock', x: 40, y: 548, w: 168, h: 108, labelX: 66, labelY: 568 },
  { id: 'east-docks', name: 'East Docks', biome: 'dock', x: 280, y: 548, w: 168, h: 108, labelX: 306, labelY: 568 },
  { id: 'deep-sea', name: 'Deep Sea', biome: 'sea', x: 96, y: 684, w: 288, h: 88, labelX: 188, labelY: 706 }
];

export const regionById = (id: RegionId) => REGIONS.find((region) => region.id === id)!;
