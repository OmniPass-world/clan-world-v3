export type RegionId =
  | 'forest'
  | 'mountains'
  | 'unicorn-town'
  | 'west-farms'
  | 'east-farms'
  | 'west-docks'
  | 'east-docks'
  | 'deep-sea';

export type WorkerAction = 'idle' | 'walk' | 'chop' | 'mine' | 'fish' | 'defend' | 'build' | 'trade';
export type PhaseId = 1 | 2 | 3 | 4;

export interface ResourcePack {
  wood: number;
  wheat: number;
  fish: number;
  iron: number;
  gold: number;
  blueprint: number;
}

export interface WorkerState {
  id: string;
  label: string;
  clanId: string;
  role: string;
  regionId: RegionId;
  action: WorkerAction;
  mission: string;
  carry: Partial<ResourcePack>;
  cooldownSeconds: number;
  x: number;
  y: number;
}

export interface ClanSummary {
  id: string;
  name: string;
  color: 'red' | 'yellow' | 'blue' | 'green';
  emblem: string;
  baseRegionId: RegionId;
  monumentLevel: number;
  wallLevel: number;
  baseLevel: number;
  winterRisk: 'LOW' | 'MEDIUM' | 'HIGH';
  resources: ResourcePack;
  workers: WorkerState[];
  starving: boolean;
}

export interface BanditState {
  active: boolean;
  state: 'idle' | 'camping' | 'attacking' | 'resting';
  regionId: RegionId;
  countdown: number;
  description: string;
}

export interface LogEntry {
  id: string;
  kind: 'system' | 'whisper' | 'axl' | 'trade';
  actor: string;
  message: string;
  tick: number;
}

export interface StrategyFields {
  primary: string;
  secondary: string;
  ethos: string;
}

export interface WorldHud {
  tick: number;
  maxTick: number;
  winterIn: number;
  season: 'Spring' | 'Winter';
}

export interface WorldState {
  hud: WorldHud;
  focusedClanId: string;
  clans: ClanSummary[];
  bandits: BanditState;
  logs: LogEntry[];
  strategy: StrategyFields;
  whisperDraft: string;
  selectedEntityId?: string;
  selectedRegionId?: RegionId;
  liveDataStatus: 'mock' | 'simulated-contract';
  marketPreview: {
    woodGold: number[];
    fishGold: number[];
    wheatGold: number[];
    ironGold: number[];
  };
  timelineLabel: string;
}
