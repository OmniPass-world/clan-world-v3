import type { ClanSummary, LogEntry, PhaseId, ResourcePack, StrategyFields, WorkerState, WorldState } from './types';

const baseStrategy: StrategyFields = {
  primary: 'Build coalition with nearby farms. Prioritize walls before monument level 5.',
  secondary: '- Keep one worker near Unicorn Town when possible.\n- Demand payment before sending defenders.\n- Do not trust Clan 0006.',
  ethos: 'Be paranoid, diplomatic, and opportunistic. Avoid unnecessary risk before winter.'
};

const marketSeries = {
  woodGold: [1.4, 1.5, 1.6, 1.3, 1.7, 1.8, 1.6, 1.9],
  fishGold: [1.2, 1.25, 1.3, 1.28, 1.5, 1.55, 1.48, 1.6],
  wheatGold: [0.9, 0.92, 1.0, 0.98, 1.05, 1.1, 1.08, 1.2],
  ironGold: [2.0, 2.05, 2.15, 2.1, 2.25, 2.35, 2.3, 2.45]
};

const makeResources = (overrides: Partial<ResourcePack>): ResourcePack => ({
  wood: 42,
  wheat: 80,
  fish: 6.4,
  iron: 3.5,
  gold: 12,
  blueprint: 1,
  ...overrides
});

const globalLogs: Record<number, LogEntry[]> = {
  0: [
    { id: 'log-0', kind: 'system', actor: 'Keeper', message: 'World heartbeat stabilized. All clans visible on the map.', tick: 86 },
    { id: 'log-1', kind: 'whisper', actor: 'God', message: 'Watch the wood market and stay winter-safe.', tick: 86 }
  ],
  1: [{ id: 'log-2', kind: 'system', actor: 'Bandits', message: 'A red flag rises in the Forest. Raid in 3.', tick: 87 }],
  2: [{ id: 'log-3', kind: 'axl', actor: 'Elder Ashroot', message: 'Offering defense for 2 gold + any blueprint fragment.', tick: 88 }],
  3: [{ id: 'log-4', kind: 'trade', actor: 'Trader B', message: 'Sold 4 wood in Unicorn Town for 6.2 gold.', tick: 89 }],
  4: [{ id: 'log-5', kind: 'system', actor: 'Bandits', message: 'Raid hits West Farms. Defense holds.', tick: 90 }],
  5: [{ id: 'log-6', kind: 'system', actor: 'Loot', message: 'Blueprint fragment secured after the defense.', tick: 91 }],
  6: [{ id: 'log-7', kind: 'system', actor: 'Winter', message: 'Snowfall begins. Food burn doubles.', tick: 92 }],
  7: [{ id: 'log-8', kind: 'system', actor: 'Builder A', message: 'Monument upgraded to level 4.', tick: 93 }]
};

const resourceSteps = [
  makeResources({ wood: 42, wheat: 80, fish: 6.4, iron: 3.5, gold: 12, blueprint: 1 }),
  makeResources({ wood: 46, wheat: 80, fish: 6.2, iron: 3.5, gold: 12, blueprint: 1 }),
  makeResources({ wood: 38, wheat: 79, fish: 6.0, iron: 3.5, gold: 12, blueprint: 1 }),
  makeResources({ wood: 34, wheat: 78, fish: 5.8, iron: 2.5, gold: 18.2, blueprint: 1 }),
  makeResources({ wood: 34, wheat: 77, fish: 5.7, iron: 2.5, gold: 18.2, blueprint: 1 }),
  makeResources({ wood: 34, wheat: 77, fish: 5.6, iron: 2.5, gold: 18.2, blueprint: 2 }),
  makeResources({ wood: 24, wheat: 74, fish: 5.0, iron: 2.5, gold: 18.2, blueprint: 2 }),
  makeResources({ wood: 20, wheat: 71, fish: 4.8, iron: 2.5, gold: 18.2, blueprint: 2 })
];

const workerAStates: WorkerState[] = [
  { id: 'a', label: 'A', role: 'Woodcutter', clanId: '001', regionId: 'forest', action: 'chop', mission: 'Chop wood', carry: { wood: 12 }, cooldownSeconds: 0, x: 116, y: 124 },
  { id: 'a', label: 'A', role: 'Woodcutter', clanId: '001', regionId: 'forest', action: 'walk', mission: 'Travel to town', carry: { wood: 14, iron: 1 }, cooldownSeconds: 32, x: 182, y: 214 },
  { id: 'a', label: 'A', role: 'Woodcutter', clanId: '001', regionId: 'unicorn-town', action: 'trade', mission: 'Sell wood + iron', carry: { wood: 10, iron: 1 }, cooldownSeconds: 44, x: 240, y: 288 },
  { id: 'a', label: 'A', role: 'Woodcutter', clanId: '001', regionId: 'west-farms', action: 'defend', mission: 'Defend West Farms', carry: {}, cooldownSeconds: 0, x: 110, y: 446 },
  { id: 'a', label: 'A', role: 'Woodcutter', clanId: '001', regionId: 'west-farms', action: 'defend', mission: 'Hold the line', carry: {}, cooldownSeconds: 0, x: 110, y: 446 },
  { id: 'a', label: 'A', role: 'Woodcutter', clanId: '001', regionId: 'unicorn-town', action: 'build', mission: 'Raise monument', carry: { blueprint: 1 }, cooldownSeconds: 16, x: 180, y: 298 },
  { id: 'a', label: 'A', role: 'Woodcutter', clanId: '001', regionId: 'unicorn-town', action: 'build', mission: 'Stack wood for winter', carry: { wood: 6 }, cooldownSeconds: 26, x: 162, y: 286 },
  { id: 'a', label: 'A', role: 'Woodcutter', clanId: '001', regionId: 'unicorn-town', action: 'build', mission: 'Upgrade monument', carry: { blueprint: 2 }, cooldownSeconds: 38, x: 182, y: 286 }
];

const workerBStates: WorkerState[] = [
  { id: 'b', label: 'B', role: 'Trader', clanId: '001', regionId: 'unicorn-town', action: 'idle', mission: 'Await market signal', carry: { iron: 2 }, cooldownSeconds: 0, x: 240, y: 290 },
  { id: 'b', label: 'B', role: 'Trader', clanId: '001', regionId: 'unicorn-town', action: 'trade', mission: 'Sell 4 wood', carry: { wood: 10, iron: 1 }, cooldownSeconds: 18, x: 244, y: 286 },
  { id: 'b', label: 'B', role: 'Trader', clanId: '001', regionId: 'unicorn-town', action: 'trade', mission: 'Market arbitrage', carry: { gold: 3 }, cooldownSeconds: 41, x: 248, y: 284 },
  { id: 'b', label: 'B', role: 'Trader', clanId: '001', regionId: 'unicorn-town', action: 'trade', mission: 'Collect gold', carry: { gold: 6 }, cooldownSeconds: 0, x: 248, y: 284 },
  { id: 'b', label: 'B', role: 'Trader', clanId: '001', regionId: 'unicorn-town', action: 'idle', mission: 'Holding town lane', carry: { gold: 6 }, cooldownSeconds: 0, x: 246, y: 286 },
  { id: 'b', label: 'B', role: 'Trader', clanId: '001', regionId: 'unicorn-town', action: 'walk', mission: 'Return with supplies', carry: { gold: 6 }, cooldownSeconds: 58, x: 222, y: 330 },
  { id: 'b', label: 'B', role: 'Trader', clanId: '001', regionId: 'unicorn-town', action: 'walk', mission: 'Return with wood', carry: { wood: 4 }, cooldownSeconds: 58, x: 202, y: 352 },
  { id: 'b', label: 'B', role: 'Trader', clanId: '001', regionId: 'unicorn-town', action: 'idle', mission: 'Waiting', carry: { wood: 4 }, cooldownSeconds: 10, x: 190, y: 292 }
];

const workerCStates: WorkerState[] = [
  { id: 'c', label: 'C', role: 'Defender', clanId: '001', regionId: 'west-farms', action: 'idle', mission: 'Await orders', carry: {}, cooldownSeconds: 0, x: 112, y: 444 },
  { id: 'c', label: 'C', role: 'Defender', clanId: '001', regionId: 'west-farms', action: 'walk', mission: 'Move to West Farms', carry: {}, cooldownSeconds: 54, x: 126, y: 410 },
  { id: 'c', label: 'C', role: 'Defender', clanId: '001', regionId: 'west-farms', action: 'defend', mission: 'Defend base', carry: {}, cooldownSeconds: 38, x: 116, y: 446 },
  { id: 'c', label: 'C', role: 'Defender', clanId: '001', regionId: 'west-farms', action: 'defend', mission: 'Defend base', carry: {}, cooldownSeconds: 12, x: 116, y: 446 },
  { id: 'c', label: 'C', role: 'Defender', clanId: '001', regionId: 'west-farms', action: 'defend', mission: 'Defense engaged', carry: {}, cooldownSeconds: 0, x: 116, y: 446 },
  { id: 'c', label: 'C', role: 'Defender', clanId: '001', regionId: 'west-farms', action: 'defend', mission: 'Defense complete', carry: {}, cooldownSeconds: 0, x: 116, y: 446 },
  { id: 'c', label: 'C', role: 'Defender', clanId: '001', regionId: 'west-farms', action: 'idle', mission: 'Rest after raid', carry: { blueprint: 1 }, cooldownSeconds: 0, x: 124, y: 446 },
  { id: 'c', label: 'C', role: 'Defender', clanId: '001', regionId: 'west-farms', action: 'idle', mission: 'Hold village gate', carry: { blueprint: 1 }, cooldownSeconds: 0, x: 124, y: 446 }
];

function primaryClan(step: number): ClanSummary {
  return {
    id: '001',
    name: 'Ashroot Keep',
    color: 'blue',
    emblem: '🌙',
    baseRegionId: 'west-farms',
    monumentLevel: step >= 7 ? 4 : 3,
    wallLevel: step >= 6 ? 3 : 2,
    baseLevel: 2,
    winterRisk: step >= 6 ? 'HIGH' : step >= 5 ? 'MEDIUM' : 'LOW',
    resources: resourceSteps[step % 8],
    workers: [workerAStates[step % 8], workerBStates[step % 8], workerCStates[step % 8]],
    starving: step >= 7
  };
}

const rivals = (): ClanSummary[] => [
  {
    id: '002',
    name: 'Red Thorn',
    color: 'red',
    emblem: '🗡️',
    baseRegionId: 'forest',
    monumentLevel: 2,
    wallLevel: 1,
    baseLevel: 2,
    winterRisk: 'MEDIUM',
    resources: makeResources({ wood: 30, wheat: 55, fish: 3, iron: 6, gold: 7, blueprint: 1 }),
    workers: [],
    starving: false
  },
  {
    id: '003',
    name: 'Sun Vale',
    color: 'yellow',
    emblem: '☀️',
    baseRegionId: 'east-farms',
    monumentLevel: 3,
    wallLevel: 2,
    baseLevel: 2,
    winterRisk: 'LOW',
    resources: makeResources({ wood: 52, wheat: 88, fish: 5, iron: 2, gold: 9, blueprint: 2 }),
    workers: [],
    starving: false
  },
  {
    id: '004',
    name: 'Tide Watch',
    color: 'green',
    emblem: '🌊',
    baseRegionId: 'east-docks',
    monumentLevel: 1,
    wallLevel: 1,
    baseLevel: 1,
    winterRisk: 'MEDIUM',
    resources: makeResources({ wood: 26, wheat: 44, fish: 11, iron: 1, gold: 5, blueprint: 0 }),
    workers: [],
    starving: false
  }
];

export function getWorldState(phase: PhaseId, step: number): WorldState {
  const clan = primaryClan(step);
  const tick = 86 + step;
  const logs = Object.keys(globalLogs)
    .map(Number)
    .filter((logStep) => logStep <= step)
    .flatMap((logStep) => globalLogs[logStep])
    .sort((a, b) => b.tick - a.tick);

  return {
    hud: {
      tick,
      maxTick: 360,
      winterIn: Math.max(0, 23 - step),
      season: step >= 6 ? 'Winter' : 'Spring'
    },
    focusedClanId: '001',
    clans: [clan, ...rivals()],
    bandits:
      step === 0
        ? { active: false, state: 'idle', regionId: 'forest', countdown: 0, description: 'No active bandits' }
        : step < 4
          ? { active: true, state: 'camping', regionId: 'forest', countdown: 4 - step, description: 'Bandits camp in the Forest' }
          : step === 4
            ? { active: true, state: 'attacking', regionId: 'west-farms', countdown: 0, description: 'Raid in progress at West Farms' }
            : step === 5
              ? { active: true, state: 'resting', regionId: 'west-farms', countdown: 2, description: 'Bandits rest after the failed raid' }
              : { active: false, state: 'idle', regionId: 'mountains', countdown: 0, description: 'Bandits routed. Cooldown active.' },
    logs,
    strategy: baseStrategy,
    whisperDraft: 'Winter is coming. Stop monument work if wood falls below 18.',
    liveDataStatus: phase >= 2 ? 'simulated-contract' : 'mock',
    marketPreview: marketSeries,
    timelineLabel:
      step === 0 ? 'Phase 1: panoramic world map with mock data.'
      : step === 3 ? 'Phase 2: simulated contract-driven market action.'
      : step === 5 ? 'Phase 3: player whisper influences diplomacy.'
      : step >= 6 ? 'Phase 4: winter + raid + monument demo loop.'
      : 'Demo loop active.'
  };
}
