import { HashRouter, Link, Route, Routes, useLocation } from 'react-router-dom';
import { PhaserWorld } from './components/PhaserWorld';
import { Sparkline } from './components/Sparkline';
import { SelectionCard } from './components/SelectionCard';
import { AgentControl } from './components/AgentControl';
import { LogsPanel } from './components/LogsPanel';
import { ClanOverview } from './components/ClanOverview';
import { useDemoWorld } from './hooks/useDemoWorld';
import './styles.css';
import type { PhaseId } from '@agent-world/game-core';

export default function App() {
  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<DemoShell phase={0} />} />
        <Route path="/phase-1" element={<DemoShell phase={1} />} />
        <Route path="/phase-2" element={<DemoShell phase={2} />} />
        <Route path="/phase-3" element={<DemoShell phase={3} />} />
        <Route path="/phase-4" element={<DemoShell phase={4} />} />
      </Routes>
    </HashRouter>
  );
}

function DemoShell({ phase }: { phase: PhaseId | 0 }) {
  const location = useLocation();
  const {
    state,
    step,
    setStep,
    maxStep,
    playing,
    setPlaying,
    selected,
    setSelected,
    activeTab,
    setActiveTab,
    updateStrategy,
    whisperDraft,
    setWhisperDraft,
    sendWhisper
  } = useDemoWorld(phase);

  const focusedClan = state.clans.find((clan) => clan.id === state.focusedClanId) ?? state.clans[0];
  const phaseLabel = phase === 0 ? 'Full demo' : `Phase ${phase}`;

  return (
    <div className="app-shell">
      <div className="app-frame">
        <header className="topbar">
          <div>
            <div className="eyebrow">Meridian / Agent World Demo</div>
            <h1>8-bit autonomous clan UI</h1>
            <p className="muted">Mobile-first React + Phaser demo with mock-safe phases and simulated live data.</p>
          </div>
          <div className="phase-badges">
            <span className="status-pill success">{phaseLabel}</span>
            <span className="status-pill">{state.timelineLabel}</span>
          </div>
        </header>

        <nav className="phase-nav" aria-label="Phase navigation">
          {[['/', 'Full'], ['/phase-1', '1'], ['/phase-2', '2'], ['/phase-3', '3'], ['/phase-4', '4']].map(([href, label]) => (
            <Link key={href} to={href} className={`phase-link ${location.pathname === href ? 'is-active' : ''}`}>Phase {label}</Link>
          ))}
        </nav>

        <section className="hero-stats panel">
          <div className="hero-stats__grid">
            <div className="hero-stat"><span>Tick</span><strong>{state.hud.tick}/{state.hud.maxTick}</strong></div>
            <div className="hero-stat"><span>Season</span><strong>{state.hud.season}</strong></div>
            <div className="hero-stat"><span>Winter in</span><strong>{state.hud.winterIn}</strong></div>
            <div className="hero-stat"><span>Bandits</span><strong>{state.bandits.description}</strong></div>
          </div>
          <div className="resource-bar">
            {[
              ['Wood', focusedClan.resources.wood],
              ['Wheat', focusedClan.resources.wheat],
              ['Fish', focusedClan.resources.fish],
              ['Iron', focusedClan.resources.iron],
              ['Gold', focusedClan.resources.gold],
              ['Blueprint', focusedClan.resources.blueprint]
            ].map(([label, value]) => (
              <div key={label as string} className="resource-chip"><span>{label}</span><strong>{Number(value).toFixed(1)}</strong></div>
            ))}
          </div>
        </section>

        <div className="tab-row">
          {(['world', 'clan', 'elder', 'logs'] as const).map((tab) => (
            <button key={tab} className={`tab-chip ${activeTab === tab ? 'is-active' : ''}`} onClick={() => setActiveTab(tab)}>{tab}</button>
          ))}
        </div>

        <main className="content-stack">
          {activeTab === 'world' && (
            <>
              <section className="panel map-panel">
                <div className="panel__header">
                  <div>
                    <div className="eyebrow">World / god view</div>
                    <h2>Panoramic world map</h2>
                  </div>
                  <div className="map-controls">
                    <button className="mini-button" onClick={() => setPlaying(!playing)}>{playing ? 'Pause' : 'Play'}</button>
                    <button className="mini-button" onClick={() => setStep((current) => Math.max(0, current - 1))}>◀</button>
                    <span className="status-pill">Scene {step + 1}/{maxStep + 1}</span>
                    <button className="mini-button" onClick={() => setStep((current) => Math.min(maxStep, current + 1))}>▶</button>
                  </div>
                </div>
                <PhaserWorld state={state} onSelect={(payload) => setSelected(payload)} />
                <div className="map-caption">Tap a region to zoom. Tap workers or bases to inspect. Drag while zoomed to pan.</div>
              </section>

              <SelectionCard selection={selected as never} />

              {phase >= 2 || phase === 0 ? (
                <section className="panel">
                  <div className="panel__header">
                    <div>
                      <div className="eyebrow">Simulated contract layer</div>
                      <h2>Market overview</h2>
                    </div>
                    <div className="status-pill success">{state.liveDataStatus}</div>
                  </div>
                  <div className="chart-grid">
                    <Sparkline label="Wood / Gold" values={state.marketPreview.woodGold} />
                    <Sparkline label="Wheat / Gold" values={state.marketPreview.wheatGold} />
                    <Sparkline label="Fish / Gold" values={state.marketPreview.fishGold} />
                    <Sparkline label="Iron / Gold" values={state.marketPreview.ironGold} />
                  </div>
                  <div className="stat-grid three">
                    <div className="mini-stat"><span>Adapter</span><strong>{state.liveDataStatus}</strong></div>
                    <div className="mini-stat"><span>Focused clan</span><strong>{focusedClan.name}</strong></div>
                    <div className="mini-stat"><span>Bandit state</span><strong>{state.bandits.state}</strong></div>
                  </div>
                </section>
              ) : (
                <section className="panel">
                  <div className="eyebrow">Phase 2 lock</div>
                  <h2>Market overview</h2>
                  <p className="notice">Phase 2 adds the simulated contract data layer, charts, and derived state cards.</p>
                </section>
              )}
            </>
          )}

          {activeTab === 'clan' && <ClanOverview clans={state.clans} />}

          {activeTab === 'elder' && (
            <AgentControl
              strategy={state.strategy}
              whisperDraft={whisperDraft}
              onChangeStrategy={updateStrategy}
              onChangeWhisper={setWhisperDraft}
              onSendWhisper={sendWhisper}
              enabled={phase >= 3 || phase === 0}
            />
          )}

          {activeTab === 'logs' && <LogsPanel logs={state.logs} enabled={phase >= 2 || phase === 0} />}
        </main>
      </div>
    </div>
  );
}
