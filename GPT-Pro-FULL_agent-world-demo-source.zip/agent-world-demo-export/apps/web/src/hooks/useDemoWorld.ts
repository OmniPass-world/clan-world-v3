import { useEffect, useMemo, useState } from 'react';
import { getWorldState } from '@agent-world/game-core';
import type { LogEntry, PhaseId, StrategyFields, WorldState } from '@agent-world/game-core';

const STARTING_STEPS: Record<PhaseId | 0, number> = {
  0: 2,
  1: 0,
  2: 3,
  3: 5,
  4: 1
};

export function useDemoWorld(phase: PhaseId | 0) {
  const maxStep = 7;
  const [step, setStep] = useState(STARTING_STEPS[phase]);
  const [playing, setPlaying] = useState(phase === 0 || phase === 4);
  const [extraLogs, setExtraLogs] = useState<LogEntry[]>([]);
  const [strategy, setStrategy] = useState<StrategyFields | null>(null);
  const [whisperDraft, setWhisperDraft] = useState('Winter is coming. Stop monument work if wood falls below 18.');
  const [selected, setSelected] = useState<unknown>(null);
  const [activeTab, setActiveTab] = useState<'world' | 'clan' | 'elder' | 'logs'>('world');

  useEffect(() => {
    setStep(STARTING_STEPS[phase]);
    setPlaying(phase === 0 || phase === 4);
    setActiveTab('world');
  }, [phase]);

  useEffect(() => {
    if (!playing) return;
    const timer = window.setInterval(() => {
      setStep((current) => (current >= maxStep ? 0 : current + 1));
    }, 2200);
    return () => window.clearInterval(timer);
  }, [playing]);

  const baseState = useMemo(() => getWorldState((phase || 4) as PhaseId, step), [phase, step]);
  useEffect(() => {
    if (!strategy) {
      setStrategy(baseState.strategy);
    }
  }, [baseState.strategy, strategy]);
  useEffect(() => {
    setWhisperDraft(baseState.whisperDraft);
  }, [phase]);

  const state: WorldState = useMemo(() => ({
    ...baseState,
    strategy: strategy ?? baseState.strategy,
    whisperDraft,
    logs: [...extraLogs, ...baseState.logs].sort((a, b) => b.tick - a.tick)
  }), [baseState, extraLogs, strategy, whisperDraft]);

  const updateStrategy = (key: keyof StrategyFields, value: string) => {
    setStrategy((current) => ({ ...(current ?? baseState.strategy), [key]: value }));
  };

  const sendWhisper = () => {
    const message = whisperDraft.trim();
    if (!message) return;
    setExtraLogs((current) => [
      {
        id: `user-${Date.now()}`,
        kind: 'whisper',
        actor: 'God',
        message,
        tick: state.hud.tick
      },
      {
        id: `elder-${Date.now() + 1}`,
        kind: 'axl',
        actor: 'Elder Ashroot',
        message: 'Acknowledged. I will rebalance wood, defense, and market posture.',
        tick: state.hud.tick
      },
      ...current
    ]);
    setWhisperDraft('');
    setActiveTab('logs');
  };

  return {
    state,
    step,
    setStep,
    maxStep,
    playing,
    setPlaying,
    selected,
    setSelected,
    activeTab,
    setActiveTab,
    updateStrategy,
    whisperDraft,
    setWhisperDraft,
    sendWhisper
  };
}
