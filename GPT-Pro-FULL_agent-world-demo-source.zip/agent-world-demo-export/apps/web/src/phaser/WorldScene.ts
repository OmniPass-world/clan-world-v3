import Phaser from 'phaser';
import { REGIONS, WORLD_HEIGHT, WORLD_WIDTH, regionById } from '@agent-world/game-core';
import type { ClanSummary, RegionId, WorkerState, WorldState } from '@agent-world/game-core';
import terrainUrl from '../../../../packages/assets/generated/terrain_tiles.png';
import workersUrl from '../../../../packages/assets/generated/workers_sheet.png';
import structuresUrl from '../../../../packages/assets/generated/structures_sheet.png';

type SelectionPayload =
  | { type: 'region'; id: RegionId }
  | { type: 'worker'; id: string; worker: WorkerState }
  | { type: 'clan'; id: string; clan: ClanSummary };

const TERRAIN_FRAMES = {
  forest: 0,
  mountain: 1,
  town: 2,
  farm: 3,
  dock: 4,
  sea: 5
} as const;

const ACTION_FRAMES: Record<WorkerState['action'], number> = {
  idle: 0,
  walk: 1,
  chop: 2,
  mine: 3,
  fish: 4,
  defend: 5,
  build: 5,
  trade: 1
};

const CLAN_ROWS: Record<ClanSummary['color'], number> = {
  red: 0,
  yellow: 1,
  blue: 2,
  green: 3
};

export class DemoWorldScene extends Phaser.Scene {
  private state?: WorldState;
  private selectionCallback?: (payload: SelectionPayload) => void;
  private regionZones = new Map<RegionId, Phaser.GameObjects.Zone>();
  private dynamicLayer?: Phaser.GameObjects.Container;
  private cameraZoomedRegion?: RegionId;
  private dragLast?: { x: number; y: number };

  constructor() {
    super('demo-world');
  }

  init(data: { selectionCallback?: (payload: SelectionPayload) => void }) {
    this.selectionCallback = data.selectionCallback;
  }

  preload() {
    this.load.spritesheet('terrain', terrainUrl, { frameWidth: 64, frameHeight: 64 });
    this.load.spritesheet('workers', workersUrl, { frameWidth: 64, frameHeight: 64 });
    this.load.spritesheet('structures', structuresUrl, { frameWidth: 128, frameHeight: 128 });
  }

  create() {
    this.cameras.main.setBackgroundColor('#182232');
    this.cameras.main.setBounds(0, 0, WORLD_WIDTH, WORLD_HEIGHT);
    this.input.setTopOnly(false);
    this.renderWorldFrame();
    this.dynamicLayer = this.add.container(0, 0);
    this.bindInteractions();
  }

  private renderWorldFrame() {
    const bg = this.add.rectangle(WORLD_WIDTH / 2, WORLD_HEIGHT / 2, WORLD_WIDTH - 4, WORLD_HEIGHT - 4, 0x111b28);
    bg.setStrokeStyle(4, 0xe7d4a7, 1);
    bg.setDepth(-10);
    const inner = this.add.rectangle(WORLD_WIDTH / 2, WORLD_HEIGHT / 2, WORLD_WIDTH - 20, WORLD_HEIGHT - 20, 0x1b2a3d);
    inner.setStrokeStyle(2, 0x5e442f, 1);
    inner.setDepth(-9);

    REGIONS.forEach((region) => {
      const tileSize = 32;
      for (let x = region.x; x < region.x + region.w; x += tileSize) {
        for (let y = region.y; y < region.y + region.h; y += tileSize) {
          const frame = TERRAIN_FRAMES[region.biome];
          const tile = this.add.image(x, y, 'terrain', frame).setOrigin(0, 0).setScale(0.5);
          tile.setAlpha(0.98);
        }
      }
      const border = this.add.rectangle(region.x + region.w / 2, region.y + region.h / 2, region.w, region.h);
      border.setStrokeStyle(2, 0xf4e3bf, 0.75);
      border.setFillStyle(0xffffff, 0.03);
      const label = this.add.text(region.labelX, region.labelY, region.name, {
        fontFamily: 'monospace',
        fontSize: '13px',
        color: '#f7e8ca',
        stroke: '#1a1a1a',
        strokeThickness: 3
      });
      label.setDepth(1);
      const zone = this.add.zone(region.x + region.w / 2, region.y + region.h / 2, region.w, region.h).setInteractive();
      zone.on('pointerup', () => {
        this.zoomToRegion(region.id);
        this.selectionCallback?.({ type: 'region', id: region.id });
      });
      this.regionZones.set(region.id, zone);
    });

    this.add.text(28, 18, 'WORLD MAP', {
      fontFamily: 'monospace',
      fontSize: '16px',
      color: '#f9e6b5',
      stroke: '#000',
      strokeThickness: 4
    });
  }

  private bindInteractions() {
    this.input.on('pointerdown', (pointer: Phaser.Input.Pointer) => {
      this.dragLast = { x: pointer.x, y: pointer.y };
    });
    this.input.on('pointermove', (pointer: Phaser.Input.Pointer) => {
      if (!pointer.isDown || !this.dragLast || this.cameras.main.zoom <= 1.2) return;
      const dx = pointer.x - this.dragLast.x;
      const dy = pointer.y - this.dragLast.y;
      this.cameras.main.scrollX -= dx / this.cameras.main.zoom;
      this.cameras.main.scrollY -= dy / this.cameras.main.zoom;
      this.dragLast = { x: pointer.x, y: pointer.y };
    });
    this.input.on('pointerup', () => {
      this.dragLast = undefined;
    });
    const resetZone = this.add.zone(WORLD_WIDTH / 2, WORLD_HEIGHT / 2, WORLD_WIDTH, WORLD_HEIGHT).setInteractive();
    resetZone.setDepth(-100);
    resetZone.on('pointerup', (_pointer: Phaser.Input.Pointer, _lx: number, _ly: number, event: Phaser.Types.Input.EventData) => {
      if (this.cameraZoomedRegion) {
        event.stopPropagation();
        this.resetZoom();
      }
    });
  }

  zoomToRegion(regionId: RegionId) {
    if (this.cameraZoomedRegion === regionId) {
      this.resetZoom();
      return;
    }
    const region = regionById(regionId);
    this.cameraZoomedRegion = regionId;
    this.cameras.main.pan(region.x + region.w / 2, region.y + region.h / 2, 250, 'Quad.easeOut', true);
    this.cameras.main.zoomTo(2.25, 250);
  }

  resetZoom() {
    this.cameraZoomedRegion = undefined;
    this.cameras.main.pan(WORLD_WIDTH / 2, WORLD_HEIGHT / 2, 250, 'Quad.easeOut', true);
    this.cameras.main.zoomTo(1, 250);
  }

  setWorldState(state: WorldState) {
    this.state = state;
    this.renderDynamicState();
  }

  private renderDynamicState() {
    if (!this.state || !this.dynamicLayer) return;
    this.dynamicLayer.removeAll(true);

    this.state.clans.forEach((clan) => {
      const region = regionById(clan.baseRegionId);
      const baseY = region.y + region.h - 28;
      const baseX = region.x + 32 + (Number(clan.id) % 2) * 56;
      const base = this.add.image(baseX, baseY, 'structures', 0).setOrigin(0.5, 1).setScale(0.33);
      base.setInteractive({ cursor: 'pointer' });
      base.on('pointerup', () => this.selectionCallback?.({ type: 'clan', id: clan.id, clan }));
      const badge = this.add.circle(baseX + 18, baseY - 38, 9, Phaser.Display.Color.HexStringToColor(colorHex(clan.color)).color);
      const badgeText = this.add.text(baseX + 13, baseY - 43, clan.emblem, { fontSize: '10px' });
      const level = this.add.text(baseX - 20, baseY - 8, `M${clan.monumentLevel} W${clan.wallLevel}`, {
        fontFamily: 'monospace',
        fontSize: '9px',
        color: '#fffbe8',
        stroke: '#000',
        strokeThickness: 3
      });
      this.dynamicLayer!.add([base, badge, badgeText, level]);
    });

    const focused = this.state.clans.find((clan) => clan.id === this.state!.focusedClanId);
    focused?.workers.forEach((worker, idx) => {
      const clan = this.state!.clans.find((entry) => entry.id === worker.clanId) ?? this.state!.clans[0];
      const frame = CLAN_ROWS[clan.color] * 6 + ACTION_FRAMES[worker.action];
      const sprite = this.add.image(worker.x, worker.y, 'workers', frame).setScale(0.36).setInteractive({ cursor: 'pointer' });
      sprite.on('pointerup', () => this.selectionCallback?.({ type: 'worker', id: worker.id, worker }));
      this.tweens.add({
        targets: sprite,
        y: worker.y + (idx % 2 === 0 ? -2 : 2),
        yoyo: true,
        repeat: -1,
        duration: 600 + idx * 60,
        ease: 'Sine.inOut'
      });
      const label = this.add.text(worker.x - 8, worker.y + 14, worker.label, {
        fontFamily: 'monospace',
        fontSize: '10px',
        color: '#fffdf5',
        stroke: '#000',
        strokeThickness: 3
      });
      this.dynamicLayer!.add([sprite, label]);
    });

    if (this.state.bandits.active) {
      const region = regionById(this.state.bandits.regionId);
      const camp = this.add.image(region.x + region.w - 26, region.y + 38, 'structures', 6).setScale(0.28);
      const flag = this.add.text(region.x + region.w - 56, region.y + 18, this.state.bandits.state === 'attacking' ? 'RAID!' : `RAID ${this.state.bandits.countdown}`, {
        fontFamily: 'monospace',
        fontSize: '11px',
        color: '#ffb3b3',
        stroke: '#000',
        strokeThickness: 3
      });
      this.dynamicLayer!.add([camp, flag]);
    }

    if (this.state.hud.season === 'Winter') {
      const snow = this.add.particles(0, 0, 'terrain', {
        frame: 1,
        scale: { start: 0.03, end: 0.01 },
        lifespan: 3000,
        speedY: { min: 25, max: 70 },
        speedX: { min: -10, max: 10 },
        alpha: { start: 0.7, end: 0.1 },
        quantity: 2,
        frequency: 100,
        x: { min: 0, max: WORLD_WIDTH },
        y: { min: -10, max: 0 }
      });
      this.dynamicLayer!.add(snow);
    }
  }
}

function colorHex(color: ClanSummary['color']) {
  switch (color) {
    case 'red':
      return '#db625e';
    case 'yellow':
      return '#ddc86e';
    case 'blue':
      return '#6f92ff';
    case 'green':
      return '#6bd476';
  }
}
