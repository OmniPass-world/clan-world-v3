import type { ClanSummary } from '@agent-world/game-core';

interface Props {
  clans: ClanSummary[];
}

export function ClanOverview({ clans }: Props) {
  return (
    <div className="stack-md">
      {clans.map((clan) => (
        <section className="panel" key={clan.id}>
          <div className="panel__header">
            <div>
              <div className="eyebrow">Clan {clan.id}</div>
              <h2>{clan.emblem} {clan.name}</h2>
            </div>
            <div className={`status-pill ${clan.winterRisk === 'HIGH' ? 'danger' : clan.winterRisk === 'MEDIUM' ? 'warn' : 'success'}`}>{clan.winterRisk}</div>
          </div>
          <div className="stat-grid three">
            <div className="mini-stat"><span>Base</span><strong>{clan.baseLevel}</strong></div>
            <div className="mini-stat"><span>Wall</span><strong>{clan.wallLevel}</strong></div>
            <div className="mini-stat"><span>Monument</span><strong>{clan.monumentLevel}</strong></div>
          </div>
          <div className="stat-grid three">
            <div className="mini-stat"><span>Wood</span><strong>{clan.resources.wood.toFixed(1)}</strong></div>
            <div className="mini-stat"><span>Wheat</span><strong>{clan.resources.wheat.toFixed(1)}</strong></div>
            <div className="mini-stat"><span>Gold</span><strong>{clan.resources.gold.toFixed(1)}</strong></div>
          </div>
          {clan.workers.length > 0 && (
            <div className="worker-list">
              {clan.workers.map((worker) => (
                <div className="worker-row" key={worker.id}>
                  <strong>{worker.label}</strong>
                  <span>{worker.regionId}</span>
                  <span>{worker.mission}</span>
                </div>
              ))}
            </div>
          )}
        </section>
      ))}
    </div>
  );
}
