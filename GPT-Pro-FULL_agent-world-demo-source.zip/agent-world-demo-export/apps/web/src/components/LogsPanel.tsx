import { useMemo, useState } from 'react';
import type { LogEntry } from '@agent-world/game-core';

const filters: Array<LogEntry['kind'] | 'all'> = ['all', 'whisper', 'axl', 'trade', 'system'];

interface Props {
  logs: LogEntry[];
  enabled: boolean;
}

export function LogsPanel({ logs, enabled }: Props) {
  const [filter, setFilter] = useState<(typeof filters)[number]>('all');
  const filtered = useMemo(() => logs.filter((log) => filter === 'all' || log.kind === filter), [logs, filter]);

  return (
    <section className="panel">
      <div className="panel__header">
        <div>
          <div className="eyebrow">Comms + audit</div>
          <h2>Message log</h2>
        </div>
        {!enabled ? <div className="status-pill">Phase 2+</div> : <div className="status-pill success">Live</div>}
      </div>
      {!enabled && <p className="notice">Logs unlock in Phase 2 once the simulated contract and event layers are active.</p>}
      <div className="filter-row">
        {filters.map((item) => (
          <button key={item} className={`filter-chip ${filter === item ? 'is-active' : ''}`} onClick={() => setFilter(item)}>
            {item}
          </button>
        ))}
      </div>
      <div className="log-list">
        {filtered.map((log) => (
          <article key={log.id} className="log-item">
            <div className="log-item__top">
              <strong>{log.actor}</strong>
              <span>Tick {log.tick}</span>
            </div>
            <div className="log-item__kind">{log.kind.toUpperCase()}</div>
            <p>{log.message}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
