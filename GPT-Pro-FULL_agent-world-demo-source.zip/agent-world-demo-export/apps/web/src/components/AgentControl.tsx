import type { StrategyFields } from '@agent-world/game-core';

interface Props {
  strategy: StrategyFields;
  whisperDraft: string;
  onChangeStrategy: (key: keyof StrategyFields, value: string) => void;
  onChangeWhisper: (value: string) => void;
  onSendWhisper: () => void;
  enabled: boolean;
}

export function AgentControl({ strategy, whisperDraft, onChangeStrategy, onChangeWhisper, onSendWhisper, enabled }: Props) {
  return (
    <div className="stack-lg">
      <section className="panel">
        <div className="panel__header">
          <div>
            <div className="eyebrow">Elder control</div>
            <h2>Elder Ashroot</h2>
            <p className="muted">Persistent doctrine feeds the agent memory, while whispers act as immediate intent nudges.</p>
          </div>
          <div className="status-pill success">Thinking</div>
        </div>
        {!enabled && <p className="notice">Phase 3 unlocks the editable doctrine and divine whisper composer.</p>}
        <label className="field">
          <span>Primary strategy</span>
          <textarea value={strategy.primary} disabled={!enabled} onChange={(event) => onChangeStrategy('primary', event.target.value)} />
        </label>
        <label className="field">
          <span>Secondary rules</span>
          <textarea value={strategy.secondary} disabled={!enabled} onChange={(event) => onChangeStrategy('secondary', event.target.value)} />
        </label>
        <label className="field">
          <span>Ethos / personality</span>
          <textarea value={strategy.ethos} disabled={!enabled} onChange={(event) => onChangeStrategy('ethos', event.target.value)} />
        </label>
        <button className="pixel-button" disabled={!enabled}>Update Elder Doctrine</button>
      </section>

      <section className="panel">
        <div className="panel__header">
          <div>
            <div className="eyebrow">God → AXL</div>
            <h2>Divine whisper</h2>
          </div>
          <div className="status-pill">Live</div>
        </div>
        <label className="field">
          <span>Whisper to your elder</span>
          <textarea value={whisperDraft} disabled={!enabled} onChange={(event) => onChangeWhisper(event.target.value)} placeholder="Winter is coming. Stop monument work and hoard wood." />
        </label>
        <button className="pixel-button pixel-button--bright" disabled={!enabled || !whisperDraft.trim()} onClick={onSendWhisper}>Send Divine Whisper</button>
      </section>
    </div>
  );
}
