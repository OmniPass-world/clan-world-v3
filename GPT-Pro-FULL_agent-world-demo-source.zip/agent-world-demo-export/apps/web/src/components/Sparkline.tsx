interface Props {
  values: number[];
  label: string;
}

export function Sparkline({ values, label }: Props) {
  const width = 200;
  const height = 68;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const path = values
    .map((value, index) => {
      const x = (index / (values.length - 1)) * (width - 16) + 8;
      const y = height - 8 - ((value - min) / Math.max(0.0001, max - min)) * (height - 20);
      return `${index === 0 ? 'M' : 'L'} ${x} ${y}`;
    })
    .join(' ');

  return (
    <div className="spark-card">
      <div className="spark-card__title">{label}</div>
      <svg viewBox={`0 0 ${width} ${height}`} className="spark-card__svg" aria-label={`${label} chart`}>
        <rect x="0" y="0" width={width} height={height} rx="6" fill="#162030" />
        {[0.25, 0.5, 0.75].map((line) => (
          <line key={line} x1="8" x2={width - 8} y1={height * line} y2={height * line} stroke="#29384f" strokeWidth="1" />
        ))}
        <path d={path} fill="none" stroke="#f6d77a" strokeWidth="3" strokeLinecap="round" />
      </svg>
      <div className="spark-card__meta">
        <span>{values[0].toFixed(2)}</span>
        <span>{values[values.length - 1].toFixed(2)}</span>
      </div>
    </div>
  );
}
