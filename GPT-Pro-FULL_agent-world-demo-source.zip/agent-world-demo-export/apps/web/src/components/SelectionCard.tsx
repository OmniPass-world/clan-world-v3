import type { ClanSummary, RegionId, WorkerState } from '@agent-world/game-core';

type Selection =
  | { type: 'region'; id: RegionId }
  | { type: 'worker'; id: string; worker: WorkerState }
  | { type: 'clan'; id: string; clan: ClanSummary }
  | null;

interface Props {
  selection: Selection;
}

export function SelectionCard({ selection }: Props) {
  if (!selection) {
    return (
      <section className="panel selection-card">
        <div className="eyebrow">Inspector</div>
        <h2>No selection</h2>
        <p className="muted">Tap a region, worker, or base on the world map to inspect it.</p>
      </section>
    );
  }

  if (selection.type === 'region') {
    return (
      <section className="panel selection-card">
        <div className="eyebrow">Region</div>
        <h2>{selection.id}</h2>
        <p className="muted">Zoom target selected. Drag to pan while zoomed, and tap again to reset.</p>
      </section>
    );
  }

  if (selection.type === 'clan') {
    const { clan } = selection;
    return (
      <section className="panel selection-card">
        <div className="eyebrow">Clan</div>
        <h2>{clan.name}</h2>
        <p className="muted">Monument {clan.monumentLevel} · Wall {clan.wallLevel} · Winter risk {clan.winterRisk}</p>
        <div className="kv-grid">
          <span>Gold</span><strong>{clan.resources.gold.toFixed(1)}</strong>
          <span>Wood</span><strong>{clan.resources.wood.toFixed(1)}</strong>
          <span>Blueprint</span><strong>{clan.resources.blueprint.toFixed(1)}</strong>
        </div>
      </section>
    );
  }

  const { worker } = selection;
  return (
    <section className="panel selection-card">
      <div className="eyebrow">Worker</div>
      <h2>{worker.label} · {worker.role}</h2>
      <p className="muted">Mission: {worker.mission}</p>
      <div className="kv-grid">
        <span>Region</span><strong>{worker.regionId}</strong>
        <span>Cooldown</span><strong>{worker.cooldownSeconds}s</strong>
        <span>Carry</span><strong>{Object.entries(worker.carry).map(([key, value]) => `${key}:${value}`).join(', ') || 'empty'}</strong>
      </div>
    </section>
  );
}
