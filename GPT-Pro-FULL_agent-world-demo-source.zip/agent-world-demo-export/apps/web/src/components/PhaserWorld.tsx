import { useEffect, useRef } from 'react';
import Phaser from 'phaser';
import type { ClanSummary, RegionId, WorkerState, WorldState } from '@agent-world/game-core';
import { WORLD_HEIGHT, WORLD_WIDTH } from '@agent-world/game-core';
import { DemoWorldScene } from '../phaser/WorldScene';

type SelectionPayload =
  | { type: 'region'; id: RegionId }
  | { type: 'worker'; id: string; worker: WorkerState }
  | { type: 'clan'; id: string; clan: ClanSummary };

interface Props {
  state: WorldState;
  onSelect: (payload: SelectionPayload) => void;
}

export function PhaserWorld({ state, onSelect }: Props) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const gameRef = useRef<Phaser.Game | null>(null);
  const sceneRef = useRef<DemoWorldScene | null>(null);

  useEffect(() => {
    if (!containerRef.current || gameRef.current) return;

    const scene = new DemoWorldScene();
    sceneRef.current = scene;
    const game = new Phaser.Game({
      type: Phaser.CANVAS,
      width: WORLD_WIDTH,
      height: WORLD_HEIGHT,
      parent: containerRef.current,
      backgroundColor: '#111827',
      pixelArt: true,
      antialias: false,
      scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH,
        width: WORLD_WIDTH,
        height: WORLD_HEIGHT
      },
      scene: [scene],
      callbacks: {
        postBoot: () => {
          scene.scene.start('demo-world', { selectionCallback: onSelect });
        }
      }
    });
    gameRef.current = game;

    return () => {
      game.destroy(true);
      gameRef.current = null;
      sceneRef.current = null;
    };
  }, [onSelect]);

  useEffect(() => {
    if (!sceneRef.current) return;
    sceneRef.current.setWorldState(state);
  }, [state]);

  return <div ref={containerRef} className="phaser-shell" aria-label="World map demo" />;
}
