import { expect, test } from '@playwright/test';
import { routeUrl } from './_helpers';

test('full demo loads and elder whisper flow works', async ({ page }) => {
  await page.goto(routeUrl('/'));
  await expect(page.getByRole('heading', { name: '8-bit autonomous clan UI' })).toBeVisible();
  await expect(page.getByText('Panoramic world map')).toBeVisible();
  await page.getByRole('button', { name: 'elder' }).click();
  await expect(page.getByRole('heading', { name: 'Divine whisper' })).toBeVisible();
  await page.locator('label.field').filter({ hasText: 'Whisper to your elder' }).locator('textarea').fill('Prioritize wood over monument until winter passes.');
  await page.getByRole('button', { name: 'Send Divine Whisper' }).click();
  await page.getByRole('button', { name: 'logs' }).click();
  await expect(page.getByText('Acknowledged. I will rebalance wood, defense, and market posture.')).toBeVisible();
});
