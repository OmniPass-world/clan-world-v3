import { expect, test } from '@playwright/test';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { routeUrl } from './_helpers';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const outDir = path.resolve(__dirname, '../artifacts');

test.beforeAll(() => {
  fs.mkdirSync(outDir, { recursive: true });
});

const routes = [
  { path: '/phase-1', name: 'phase-1-world', tab: 'world' },
  { path: '/phase-2', name: 'phase-2-market', tab: 'world' },
  { path: '/phase-3', name: 'phase-3-elder', tab: 'elder' },
  { path: '/phase-4', name: 'phase-4-logs', tab: 'logs' },
  { path: '/', name: 'full-demo-world', tab: 'world' },
  { path: '/', name: 'full-demo-elder', tab: 'elder' },
  { path: '/', name: 'full-demo-logs', tab: 'logs' }
] as const;

for (const route of routes) {
  test(`capture ${route.name}`, async ({ page }) => {
    await page.goto(routeUrl(route.path));
    await expect(page.getByRole('heading', { name: '8-bit autonomous clan UI' })).toBeVisible();
    if (route.tab !== 'world') {
      await page.getByRole('button', { name: route.tab }).click();
    }
    await page.waitForTimeout(1200);
    await page.screenshot({ path: path.join(outDir, `${route.name}.png`), fullPage: true });
  });
}
