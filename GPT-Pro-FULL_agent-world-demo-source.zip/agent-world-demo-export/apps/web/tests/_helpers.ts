export const routeUrl = (hashPath: string) => `/#${hashPath}`;
