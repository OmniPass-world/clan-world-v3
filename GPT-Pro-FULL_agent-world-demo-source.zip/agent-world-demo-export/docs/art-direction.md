# Art direction and sprite sheet notes

## Visual direction
- true pixel-art feel
- readable on phone screens first
- warm parchment HUD framing around a cool dusk-blue world
- strong color coding for four clans: red, yellow, blue, green
- slight top-down fantasy strategy composition

## Included placeholder sheet sizes
### terrain_tiles.png
- frame size: `64x64`
- 6 tiles in one row
- intended logical tile size in-world: `32x32` display
- current tiles: forest, mountains, town, farm, dock, sea

### workers_sheet.png
- frame size: `64x64`
- grid: 4 clan rows × 6 action columns
- row themes: red, yellow, blue, green
- action columns: idle, walk, chop, mine, fish, defend/build

### structures_sheet.png
- frame size: `128x128`
- simple demo buildings / props
- current cells include hut, tower, monument, wall, market, docks, camp, shrine

### ui_icons.png
- frame size: `32x32`
- small HUD markers and badges

## Future expansion targets
### worker frames to add later
- push wheelbarrow empty / half / full in all needed directions
- chop wood, mine, fish, cut wheat, hammer, pray, defend, freeze, frostbite, dead
- winter variants for all main worker types

### structure frames to add later
- clan bases by tier
- walls by tier
- monument tiers 1–5
- docks, market stalls, shrines, storage, watch towers, campfires

### terrain expansion targets
- edge transitions
- more forest density states
- cliffs and corners
- snow variants
- roads and overlays
- decorative props
