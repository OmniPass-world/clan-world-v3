# Demo phases and cut lines

## Phase 1 — world shell
Goal: prove the mobile game shell and main map interaction.

Includes:
- panoramic pixel world map
- touch-friendly HUD and resources
- region tap / zoom / drag pan
- worker and clan inspection
- mock world timeline steps

Cut line:
- no chain dependence
- no elder editing required
- no real contract calls

## Phase 2 — simulated onchain / market layer
Goal: prove dashboard surfaces and game-state storytelling without deployment risk.

Includes:
- market preview charts
- simulated event log
- simulated trade moments
- resource state changes over time

Cut line:
- adapter state remains mock / simulated
- deployment is optional

## Phase 3 — player control surfaces
Goal: prove player command UX.

Includes:
- elder doctrine editor
- divine whisper composer
- local simulated elder acknowledgment

Cut line:
- persistence can remain local for demo purposes

## Phase 4 — full playable demo loop
Goal: stitch all core surfaces into one coherent end-to-end demo.

Includes:
- autoplay demo timeline
- bandit threat escalation
- defense beat
- blueprint reward
- winter state shift
- monument progress beat
