# Agent World Demo

A mobile-first Phaser + React demo for an 8-bit autonomous-clan strategy world.

This monorepo is set up so every phase has a clean testing point:
- **Phase 1** works by itself with mock data and a navigable world map.
- **Phase 2** adds simulated market / contract-state surfaces without requiring deployed contracts.
- **Phase 3** adds the player-facing elder control page and divine whisper flow.
- **Phase 4** ties the demo together into a full winter / raid / monument loop.

## Stack
- pnpm workspace monorepo
- React + Vite
- Phaser 3 embedded inside React
- TypeScript
- Playwright for a minimal happy-path check plus screenshot capture

## Quick start
```bash
pnpm install
pnpm build
pnpm --filter @agent-world/web dev
```

Open:
- `/#/` full demo
- `/#/phase-1`
- `/#/phase-2`
- `/#/phase-3`
- `/#/phase-4`

## Test and screenshot commands
```bash
pnpm --filter @agent-world/web test
pnpm --filter @agent-world/web screenshots
```

Captured screenshots are written to:
- `apps/web/artifacts/`

## Workspace layout
```text
apps/
  web/                React + Phaser demo app
packages/
  game-core/          typed demo world data + simulation states
  assets/             generated pixel-art placeholder / starter sprite sheets
  config/             shared TS config package
  ui/                 placeholder package for future shared UI components

docs/
  phases.md
  art-direction.md
```

## What is implemented
### Phase 1
- panoramic world map with tappable regions
- zoom / pan interaction
- worker and clan inspection cards
- mock-safe standalone demo

### Phase 2
- simulated market overview
- resource charts
- event / audit log surface
- still works without contracts deployed

### Phase 3
- elder strategy editor
- God → AXL whisper panel
- local simulated response loop

### Phase 4
- autoplaying full demo loop
- bandit raid state
- winter transition
- monument progression / blueprint reward moment

## Generated art assets
The project already includes self-generated placeholder sprite sheets in:
- `packages/assets/generated/terrain_tiles.png`
- `packages/assets/generated/workers_sheet.png`
- `packages/assets/generated/structures_sheet.png`
- `packages/assets/generated/ui_icons.png`

These are meant to be immediately usable for a demo, while also serving as a spec scaffold for future final art passes.

## Screenshots
### Phase 1
![Phase 1](apps/web/artifacts/phase-1-world.png)

### Phase 2
![Phase 2](apps/web/artifacts/phase-2-market.png)

### Phase 3
![Phase 3](apps/web/artifacts/phase-3-elder.png)

### Phase 4
![Phase 4](apps/web/artifacts/phase-4-logs.png)

## Notes
- The market / chain layer is simulated on purpose so the front-end can be demoed before contracts exist.
- The Playwright suite is intentionally small and happy-path only.
- Phaser is configured in a way that stays touch-friendly and mobile-sized.
