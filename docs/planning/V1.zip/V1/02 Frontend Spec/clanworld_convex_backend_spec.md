# ClanWorld Convex Backend — Spec

**Status:** Draft v1, hackathon-scoped
**Owner:** Backend agent team
**Depends on:** `IClanWorld.sol` (seam interface, locked), `clanworld_frontend_spec.md` (query contract, §7)
**Audience:** Anyone implementing the Convex deployment

---

## 0. Purpose

The Convex deployment is the **bridge between the chain and the UI**. It holds no game truth — the contract is canonical — but it caches enough chain-derived state to power a snappy reactive UI without hammering the RPC.

Three jobs, in priority order:

1. **Indexing.** Subscribe to `IClanWorld` events and view getters; mirror state into Convex tables.
2. **Reactive query surface.** Implement the 8 queries the frontend declared in `clanworld_frontend_spec.md` §7.
3. **Heartbeat orchestration.** Call `heartbeat()` on the cadence we configure (15–20s for demo).

Every other backend concern is out of scope for the hackathon. No auth, no rate limiting, no admin UI, no analytics, no replay, no pagination. We're building a 6-hour demo, not a service.

---

## 1. Architecture Overview

```
┌─────────────────────────────────┐
│  ClanWorld contract (Base/World)│
│  - emits events                 │
│  - exposes view getters         │
└──────────────┬──────────────────┘
               │ via Alchemy WS RPC
        ┌──────┴───────┐
        │              │
   events poll    state poll
        │              │
        ▼              ▼
┌──────────────────────────────────┐
│  Convex deployment               │
│                                  │
│  Actions:                        │
│   - heartbeatCaller (cron 20s)   │
│   - tickIndexer (every tick)     │
│   - eventIndexer (every 5s)      │
│                                  │
│  Tables:                         │
│   - tickEpoch                    │
│   - worldSnapshot                │
│   - clanFullViews                │
│   - activeBandit                 │
│   - marketState                  │
│   - priceHistory                 │
│   - eventLog                     │
│   - agentLogs                    │
│   - whispers                     │
│                                  │
│  Queries:                        │
│   - api.world.getSnapshot        │
│   - api.world.getAllClanViews    │
│   - api.world.getActiveBandit    │
│   - api.market.getState          │
│   - api.market.getPriceHistory   │
│   - api.events.getRecent         │
│   - api.agents.getRecentLogs     │
│   - api.whispers.getRecent       │
│                                  │
│  Mutations (internal):           │
│   - upsertSnapshot, etc.         │
│                                  │
│  Mutations (public):             │
│   - postAgentLog                 │
│   - postWhisper                  │
└──────────────┬───────────────────┘
               │ reactive subscriptions
               ▼
        Frontend client
        Agent runner
```

Two write paths feed Convex:

- **Indexer write path** — chain → Convex. Owned by Convex actions running on cron + event-driven invocations.
- **Agent write path** — agents post their reasoning and whispers to Convex via public mutations. Their *game actions* still go onchain via viem; Convex catches those via the indexer.

---

## 2. Tech Stack

```jsonc
{
  "dependencies": {
    "convex": "^1.x",
    "viem": "^2.x",
    "abitype": "^1.x"
  }
}
```

Everything runs in Convex's TypeScript runtime. Viem reads the chain. The compiled `IClanWorld` ABI is the source of truth for types — both raw events and structured view returns are derived from it via abitype.

No additional services. No Redis, no Postgres, no external queue. Convex tables are durable and reactive; that's all we need.

---

## 3. Configuration

Single config module, all values environment-overridable:

```typescript
// convex/config.ts
export const config = {
  // Chain — primary + fallback Alchemy RPCs for redundancy and load balancing
  rpcUrl: process.env.ALCHEMY_RPC_URL!,             // wss://base-mainnet.g.alchemy.com/v2/...
  rpcUrlFallback: process.env.ALCHEMY_RPC_URL_FALLBACK,  // optional second RPC, same chain
  chainId: Number(process.env.CHAIN_ID ?? 8453),
  contractAddress: process.env.CLANWORLD_ADDRESS! as `0x${string}`,

  // World
  worldId: 'demo',                              // single world for v1
  tickDurationMs: Number(process.env.TICK_DURATION_MS ?? 20000),

  // Indexer cadence
  eventPollIntervalMs: 5000,                    // how often we poll for new logs
  statePollOnTick: true,                        // refresh state-poll caches on every tick advance

  // Heartbeat caller
  heartbeatCallerEnabled: process.env.HEARTBEAT_CALLER_ENABLED === 'true',
  heartbeatCallerPrivateKey: process.env.HEARTBEAT_CALLER_PK as `0x${string}` | undefined,

  // Retention
  priceHistoryTicks: 360,                       // one season
  agentLogPerClanLimit: 50,
  eventLogLimit: 500,
  whisperLogLimit: 200,
};
```

The heartbeat caller is feature-flagged. In production the heartbeat is permissionless and anyone can call it; for the demo, we run our own caller because we control timing. If `HEARTBEAT_CALLER_ENABLED` is false, we passively index whatever heartbeats happen.

---

## 4. Schema (Convex Tables)

### 4.1 Design philosophy

Two table flavors live in Convex:

- **Snapshot tables** — hold the *latest* state. One row per logical entity, overwritten on every refresh. Used for things the UI shows live: world state, clan views, bandit, market.
- **Log tables** — append-only event histories. Used for things the UI scrolls through: events, agent logs, whispers, price history.

The split lets us avoid Convex's natural temptation to keep "history of every snapshot" tables, which we don't need for a 6-minute demo.

### 4.2 Tables

```typescript
// convex/schema.ts
import { defineSchema, defineTable } from 'convex/server';
import { v } from 'convex/values';

export default defineSchema({
  // ─────────────────────────────────────────────
  // SNAPSHOT TABLES — overwritten each refresh
  // ─────────────────────────────────────────────

  tickEpoch: defineTable({
    worldId: v.string(),
    currentTick: v.number(),
    tickAdvancedAt: v.number(),         // unix ms when we observed the advance
    configuredTickDurationMs: v.number(),
  }).index('by_world', ['worldId']),

  worldSnapshot: defineTable({
    worldId: v.string(),
    raw: v.any(),                       // shape: WorldSnapshot from contract
    updatedAt: v.number(),
  }).index('by_world', ['worldId']),

  clanFullViews: defineTable({
    worldId: v.string(),
    clanId: v.number(),
    raw: v.any(),                       // shape: ClanFullView from contract
    updatedAt: v.number(),
  })
    .index('by_world', ['worldId'])
    .index('by_world_clan', ['worldId', 'clanId']),

  activeBandit: defineTable({
    worldId: v.string(),
    raw: v.any(),                       // shape: ActiveBanditView from contract
    updatedAt: v.number(),
  }).index('by_world', ['worldId']),

  marketState: defineTable({
    worldId: v.string(),
    raw: v.any(),                       // shape: MarketState from contract
    updatedAt: v.number(),
  }).index('by_world', ['worldId']),

  // ─────────────────────────────────────────────
  // LOG TABLES — append-only with TTL pruning
  // ─────────────────────────────────────────────

  priceHistory: defineTable({
    worldId: v.string(),
    resource: v.union(v.literal('wood'), v.literal('iron'), v.literal('wheat'), v.literal('fish')),
    tick: v.number(),
    spotPrice: v.number(),              // gold per resource at human-readable scale (see note below)
    createdAt: v.number(),
  })
    .index('by_world_resource_tick', ['worldId', 'resource', 'tick']),

  eventLog: defineTable({
    worldId: v.string(),
    tick: v.number(),
    kind: v.string(),                   // discriminator for EventLogEntry union
    payload: v.any(),                   // shape varies by kind, matches frontend EventLogEntry
    txHash: v.optional(v.string()),
    blockNumber: v.optional(v.number()),
    createdAt: v.number(),
  })
    .index('by_world_created', ['worldId', 'createdAt'])
    .index('by_world_tick', ['worldId', 'tick']),

  agentLogs: defineTable({
    worldId: v.string(),
    clanId: v.number(),
    tick: v.number(),
    reasoning: v.string(),              // up to 240 chars, validated in postLog mutation
    triggeringClansmanId: v.optional(v.number()), // for speech bubble attachment
    createdAt: v.number(),
  })
    .index('by_world_clan_created', ['worldId', 'clanId', 'createdAt'])
    .index('by_world_created', ['worldId', 'createdAt']),

  whispers: defineTable({
    worldId: v.string(),
    fromClanId: v.number(),
    toClanId: v.optional(v.number()),   // undefined == broadcast
    tick: v.number(),
    body: v.string(),
    createdAt: v.number(),
  })
    .index('by_world_created', ['worldId', 'createdAt']),

  // ─────────────────────────────────────────────
  // INDEXER BOOKKEEPING
  // ─────────────────────────────────────────────

  indexerCheckpoint: defineTable({
    worldId: v.string(),
    name: v.string(),                   // 'event' or 'state'
    lastBlockNumber: v.number(),
    lastLogIndex: v.number(),
    updatedAt: v.number(),
  }).index('by_world_name', ['worldId', 'name']),
});
```

### 4.3 Why `v.any()` for the snapshot rows

The frontend's `IClanWorld`-derived TypeScript types are the source of truth for the shapes inside `raw`. We could mirror them in the Convex schema, but that's duplication that breaks the moment the contract adds a field. Storing as `v.any()` and casting on read is the hackathon-correct trade — we trust the indexer to write the right shape, and the frontend reads via typed wrappers.

In production this would be tightened. For the demo, don't.

### 4.4 `spotPrice` unit conversion

The contract returns `spotPriceGoldPerResource` as 18-decimal fixed-point (`uint256`). JavaScript `number` loses precision above 2^53, so we cannot store the raw bigint in `v.number()`.

Convert at write time:

```typescript
// In tickIndexer, when sampling spot price per resource:
const spotPriceFloat = Number(spotPrice18 / 10n**14n) / 10000;
// → human-readable gold-per-resource, 4 decimal places of precision
```

This stores e.g. `0.7234` for "0.7234 gold per wood" and is plenty precise for sparkline rendering. For exact arithmetic (e.g., agent reasoning about prices), use the contract's raw `MarketState` values — don't round-trip through the priceHistory table.

### 4.5 Indexes

Every index above is intentional. Convex requires explicit indexes for any query predicate; if you're tempted to add an unindexed filter, add the index instead.

---

## 5. Indexer Architecture

The indexer has two loops, intentionally split because they have different cadences and different failure characteristics.

### 5.1 The state-poll loop (`tickIndexer`)

**Cadence:** Once per tick (~20s), triggered by the `TickAdvanced` event being indexed.

**What it does:**
1. Calls the four UI aggregator getters in parallel:
   - `getWorldSnapshot()`
   - `getActiveBanditView()`
   - `getMarketState()`
   - For each `clanId` in the snapshot's leaderboard: `getClanFullView(clanId)`
2. Upserts each result into the corresponding snapshot table.
3. Writes one `priceHistory` row per resource using `marketState.{wood,iron,wheat,fish}.spotPriceGoldPerResource`.
4. Updates `tickEpoch` with the new `currentTick` and `tickAdvancedAt = now()`.

**Total RPC calls per tick:** 3 + N where N = clan count. At v1 realm size of 8 clans, that's 11 calls per 20s tick = ~50k calls/day from the indexer alone.

Adding it all up:
- Indexer state-poll: ~50k/day
- Event polling at 5s intervals: ~17k/day
- Heartbeat caller transactions: ~4k/day
- Agent transaction submissions (4 agents × ~1 tx/tick): ~17k/day
- **Total: ~90k/day**

We have **two Alchemy RPCs at 1M/day each = 2M/day total capacity**, with the agent runner load-balancing or rotating between them. We're at ~5% of available quota with comfortable redundancy. No quota concerns.

**Why state-poll instead of event-driven for these:** the aggregator getters return *settled* state, which is computed from raw state plus pending changes since last settlement. Event-driven indexing would force us to re-implement settlement logic in TypeScript. State-polling delegates that to the contract for free.

### 5.2 The event-poll loop (`eventIndexer`)

**Cadence:** Every 5 seconds.

**What it does:**
1. Reads `indexerCheckpoint` for the last processed block + log index.
2. Calls `eth_getLogs` for the contract address from `lastBlock` to `latestBlock`.
3. For each new log:
   - Decodes it via the ABI.
   - Translates it into one or more `eventLog` rows with the corresponding `kind` and `payload`.
   - For specific events, also performs side effects:
     - `TickAdvanced` → triggers `tickIndexer` (via `ctx.scheduler.runAfter(0, ...)`)
     - `MissionAssigned` / `MissionCompleted` → eventLog only
     - `BanditAttackResolved` → eventLog + invalidates `activeBandit` (re-fetch immediately)
     - `WallLevelChanged` / `BaseLevelChanged` / `MonumentLevelChanged` → eventLog + invalidates the affected `clanFullViews` row
     - `ClanSpawned` → eventLog + triggers a one-shot `getClanFullView` for the new clan
4. Updates `indexerCheckpoint`.

**Why decoupled from state-poll:** events are cheap, frequent, and used for the ticker and side-effect-driven re-indexing. State-poll is expensive and slow. Mixing them couples failure modes — a slow state read shouldn't delay event ingestion.

### 5.3 Mapping contract events to `eventLog.kind`

| Contract event | `kind` | Notes |
|---|---|---|
| `MissionAssigned` | `mission_assigned` | extract action, toRegion |
| `MissionCompleted` | `mission_completed` | |
| `MissionInterrupted` | (omit) | not surfaced in UI ticker |
| `OrderRejected` | `order_rejected` | dramatic: shows agents fumbling |
| `WorkerArrived` | (omit) | derivable from mission_assigned |
| `ResourcesGathered` | (omit) | too noisy; aggregated visually via wheelbarrow |
| `ResourcesDeposited` | `resources_deposited` | |
| `WallLevelChanged` | `building_upgraded` | building='wall' |
| `BaseLevelChanged` | `building_upgraded` | building='base' |
| `MonumentLevelChanged` | `building_upgraded` | building='monument' |
| `ImmediateMarketActionExecuted` | `market_trade` | direction inferred from token directions |
| `ScheduledMarketActionExecuted` | `market_trade` | |
| `ScheduledMarketActionCommitted` | (omit) | not surfaced; market panel polls scheduled queues |
| `MarketActionFailed` | `market_trade` | with `failed: true` flag in payload |
| `BanditSpawned` | `bandit_spawned` | |
| `BanditAttackResolved` | `bandit_attack` | |
| `BanditDefeated` | (folded into bandit_attack) | |
| `BanditEscaped` | (omit) | rare and undramatic |
| `BlueprintAwarded` | `blueprint_awarded` | new kind, useful in ticker |
| `LootDistributedToDefender` | (omit) | aggregated via bandit_attack |
| `ColdDamageApplied` | (omit, unless we add winter UI) | |
| `ClansmanDiedFromCold` | (omit, unless we add winter UI) | |
| `ClanSpawned` | `clan_spawned` | |
| `ClanEliminated` | `clan_eliminated` | |
| `ClanStarvationChanged` | (omit) | shown via inspector, not ticker |
| `WinterStarted` / `WinterEnded` | (omit) | shown via top HUD chip |
| `SeasonFinalized` | `season_finalized` | dramatic ticker item |
| `GoldTransferred` / `VaultResourceTransferred` / `BlueprintTransferred` | `otc_transfer` | dramatic; surfaces betrayal |
| `PoolsSeeded` | (omit) | bootstrap |

This mapping is a hackathon judgment call. If a kind feels missing once we see the UI live, add it then.

### 5.4 Reorg handling

**Out of scope.** Base/World mainnet reorgs are rare and our demo is 6 minutes. If a reorg eats an event during the recording, we re-record. Don't write reorg logic.

If cleanliness matters: `eth_getLogs` with `confirmations: 1` is the hackathon answer. Convex doesn't have a clean way to roll back appended rows anyway.

### 5.5 Failure handling

Indexer actions retry automatically in Convex with exponential backoff. For demo-day, add a simple alert: if `indexerCheckpoint.updatedAt` falls more than 60 seconds behind `now()`, log a warning. We watch the logs during the demo. That's the alerting tier.

---

## 6. Heartbeat Caller

### 6.1 Why we run our own

The contract's `heartbeat()` is permissionless. In production, anyone can call it on any cadence ≥ `HEARTBEAT_INTERVAL_SECONDS`. For a demo, we don't want to depend on someone else calling it, and we want demo-friendly tick durations (15–20s, not 60s).

### 6.2 Implementation

```typescript
// convex/actions/heartbeatCaller.ts
import { internalAction } from '../_generated/server';
import { createWalletClient, http } from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { config } from '../config';
import { CLANWORLD_ABI } from '../abi';

export const callHeartbeat = internalAction({
  args: {},
  handler: async (ctx) => {
    if (!config.heartbeatCallerEnabled) return;
    if (!config.heartbeatCallerPrivateKey) return;

    const account = privateKeyToAccount(config.heartbeatCallerPrivateKey);
    const wallet = createWalletClient({
      account,
      chain: { id: config.chainId } as any,    // simplified
      transport: http(config.rpcUrl.replace('wss://', 'https://')),
    });

    try {
      const hash = await wallet.writeContract({
        address: config.contractAddress,
        abi: CLANWORLD_ABI,
        functionName: 'heartbeat',
        args: [],
      });
      console.log(`heartbeat tx ${hash}`);
    } catch (err) {
      console.warn(`heartbeat call failed (likely rate-limited by contract):`, err);
    }
  },
});
```

### 6.3 Cron registration

```typescript
// convex/crons.ts
import { cronJobs } from 'convex/server';
import { internal } from './_generated/api';

const crons = cronJobs();

crons.interval(
  'heartbeat',
  { seconds: 20 },                              // matches config.tickDurationMs
  internal.actions.heartbeatCaller.callHeartbeat,
);

crons.interval(
  'eventPoll',
  { seconds: 5 },
  internal.actions.eventIndexer.poll,
);

export default crons;
```

The state-poll is not a cron — it's invoked by the event-indexer on `TickAdvanced`. This means if the contract doesn't accept our heartbeat (rate limited), the state-poll doesn't fire either, and the UI shows stale data with the same `currentTick`. That's correct behavior.

### 6.4 Caller funding

The caller wallet is a standard derivation from the team mnemonic (the Makefile handles funding). Each successful heartbeat costs gas. On Base, this is fractions of a cent per call. Pre-fund with $1 of ETH and forget.

---

## 7. Query Implementations

These are the eight queries declared in `clanworld_frontend_spec.md` §7. Each is a thin shim over a snapshot or log table.

```typescript
// convex/world.ts
import { query } from './_generated/server';
import { v } from 'convex/values';
import { config } from './config';

export const getSnapshot = query({
  args: {},
  handler: async (ctx) => {
    const [snapshot, tickEpochRow] = await Promise.all([
      ctx.db.query('worldSnapshot').withIndex('by_world', q => q.eq('worldId', config.worldId)).first(),
      ctx.db.query('tickEpoch').withIndex('by_world', q => q.eq('worldId', config.worldId)).first(),
    ]);
    if (!snapshot || !tickEpochRow) return null;
    // Rename internal fields to the API shape the frontend consumes.
    // Frontend spec §5.3 expects { tick, atMs, durationMs }.
    return {
      ...snapshot.raw,
      tickEpoch: {
        tick: tickEpochRow.currentTick,
        atMs: tickEpochRow.tickAdvancedAt,
        durationMs: tickEpochRow.configuredTickDurationMs,
      },
    };
  },
});

export const getAllClanViews = query({
  args: {},
  handler: async (ctx) => {
    const rows = await ctx.db.query('clanFullViews')
      .withIndex('by_world', q => q.eq('worldId', config.worldId))
      .collect();
    return rows.map(r => r.raw);
  },
});

export const getActiveBandit = query({
  args: {},
  handler: async (ctx) => {
    const row = await ctx.db.query('activeBandit')
      .withIndex('by_world', q => q.eq('worldId', config.worldId))
      .first();
    return row?.raw ?? { exists: false };
  },
});
```

```typescript
// convex/market.ts
import { query } from './_generated/server';
import { v } from 'convex/values';
import { config } from './config';

export const getState = query({
  args: {},
  handler: async (ctx) => {
    const row = await ctx.db.query('marketState')
      .withIndex('by_world', q => q.eq('worldId', config.worldId))
      .first();
    return row?.raw ?? null;
  },
});

export const getPriceHistory = query({
  args: {
    resource: v.union(v.literal('wood'), v.literal('iron'), v.literal('wheat'), v.literal('fish')),
    ticks: v.number(),
  },
  handler: async (ctx, { resource, ticks }) => {
    const all = await ctx.db.query('priceHistory')
      .withIndex('by_world_resource_tick', q =>
        q.eq('worldId', config.worldId).eq('resource', resource))
      .order('desc')
      .take(ticks);
    return all.reverse();   // chronological order for sparkline
  },
});
```

```typescript
// convex/events.ts
export const getRecent = query({
  args: { limit: v.number() },
  handler: async (ctx, { limit }) => {
    return await ctx.db.query('eventLog')
      .withIndex('by_world_created', q => q.eq('worldId', config.worldId))
      .order('desc')
      .take(Math.min(limit, 100));
  },
});
```

```typescript
// convex/agents.ts
export const getRecentLogs = query({
  args: { clanId: v.optional(v.number()), limit: v.number() },
  handler: async (ctx, { clanId, limit }) => {
    const cap = Math.min(limit, 100);
    if (clanId !== undefined) {
      return await ctx.db.query('agentLogs')
        .withIndex('by_world_clan_created', q =>
          q.eq('worldId', config.worldId).eq('clanId', clanId))
        .order('desc')
        .take(cap);
    }
    return await ctx.db.query('agentLogs')
      .withIndex('by_world_created', q => q.eq('worldId', config.worldId))
      .order('desc')
      .take(cap);
  },
});
```

```typescript
// convex/whispers.ts
export const getRecent = query({
  args: { limit: v.number() },
  handler: async (ctx, { limit }) => {
    return await ctx.db.query('whispers')
      .withIndex('by_world_created', q => q.eq('worldId', config.worldId))
      .order('desc')
      .take(Math.min(limit, 100));
  },
});
```

Convex's reactivity makes all these auto-subscribe to changes — the frontend wraps each in `useQuery` and gets push updates whenever the underlying tables change.

---

## 8. Public Mutations (Agent Write Path)

Agents are external actors. They need to post their reasoning and whispers somewhere the UI can subscribe to. Convex public mutations are how.

```typescript
// convex/agents.ts (continued)
import { mutation } from './_generated/server';
import { v } from 'convex/values';

export const postLog = mutation({
  args: {
    clanId: v.number(),
    tick: v.number(),
    reasoning: v.string(),
    triggeringClansmanId: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    if (args.reasoning.length > 240) {
      throw new Error('reasoning exceeds 240 char cap');
    }
    await ctx.db.insert('agentLogs', {
      worldId: config.worldId,
      clanId: args.clanId,
      tick: args.tick,
      reasoning: args.reasoning,
      triggeringClansmanId: args.triggeringClansmanId,
      createdAt: Date.now(),
    });
  },
});
```

```typescript
// convex/whispers.ts (continued)
export const post = mutation({
  args: {
    fromClanId: v.number(),
    toClanId: v.optional(v.number()),
    tick: v.number(),
    body: v.string(),
  },
  handler: async (ctx, args) => {
    if (args.body.length > 500) {
      throw new Error('whisper exceeds 500 char cap');
    }
    await ctx.db.insert('whispers', {
      worldId: config.worldId,
      ...args,
      createdAt: Date.now(),
    });
  },
});
```

**Auth:** None. Agents are trusted in v1. If hostile actors try to spam our Convex deployment, we add a signed-message check post-hackathon. For the demo, the agent runner has the deployment URL and we trust it.

**Rate limiting:** Length caps are the only defense. With 4–6 agents at one log per tick, throughput is trivially low.

---

## 9. Pruning

Append-only tables grow forever. We prune lazily on every insert, since the demo is short enough that drift is negligible.

```typescript
// example, applied to all log tables similarly
export const prunePriceHistoryIfNeeded = internalMutation({
  args: {},
  handler: async (ctx) => {
    const rows = await ctx.db.query('priceHistory')
      .withIndex('by_world_resource_tick', q => q.eq('worldId', config.worldId))
      .order('asc')
      .collect();
    const excess = rows.length - (config.priceHistoryTicks * 4);  // 4 resources
    if (excess <= 0) return;
    for (let i = 0; i < excess; i++) {
      await ctx.db.delete(rows[i]._id);
    }
  },
});
```

Schedule pruning on a low-frequency cron (every 5 minutes is fine):

```typescript
crons.interval('prune', { minutes: 5 }, internal.maintenance.pruneAll);
```

For the demo, even no pruning is fine — Convex storage is cheap and we'll never hit limits in 6 hours.

---

## 10. Mock Mode

The frontend is built against mocks first; the backend should support a "mock mode" so the frontend can develop against a real Convex deployment that isn't yet connected to the chain.

### 10.1 What mock mode replaces

When `MOCK_MODE=true`:
- Heartbeat caller does NOT run (no chain calls)
- Event indexer does NOT run (no chain calls)
- State indexer does NOT run (no chain calls)
- A single `advanceMockTick` cron runs every `tickDurationMs` (e.g., 20s)

Snapshot and log tables are populated by mock mutations instead of by contract reads. The frontend's queries are unchanged — Convex still serves `getSnapshot`, `getAllClanViews`, etc., from the same tables.

### 10.2 `seedMockState` — initial state

Called once via `convex run mock:seedMockState`. Inserts:

- One `tickEpoch` row with `currentTick = 30`, `tickAdvancedAt = now()`, `configuredTickDurationMs = 20000`
- One `worldSnapshot` row with believable mid-game data:
  - `seasonStartTick = 0`, `seasonEndTick = 360`
  - `winterActive = false`, `winterStartsAtTick = 110`
  - `activeBanditId = 1`
  - 4 leaderboard entries (one per mock clan), monumentLevels `[2, 1, 0, 0]`, varied loot values
- 4 `clanFullViews` rows, one per mock clan:
  - 5 clansmen each, distributed across regions
  - At least one clansman per clan in TRAVELING state (for visible motion)
  - At least one clansman per clan in ACTING state with a gathering action
  - Each clan has one base in a different valid region (Forest, Mountains, West Farms, East Farms)
- One `activeBandit` row: bandit camping in Forest, tier 2, projected target = clan 1
- One `marketState` row with 4 pool reserves at the seeded ratios from v4 §5.11
- 32 `priceHistory` rows (8 ticks × 4 resources) showing slight price walks
- 20 `eventLog` rows mixing mission_assigned, resources_deposited, market_trade, bandit_spawned
- 8 `agentLogs` rows (2 per clan) with believable LLM-style reasoning text
- 4 `whispers` (mix of broadcast and 1-to-1) for chat panel content

### 10.3 `advanceMockTick` — per-tick mock advancement

Called by cron every `tickDurationMs`. Performs:

1. **Increment tick:**
   - Update `tickEpoch.currentTick += 1`, `tickAdvancedAt = now()`
   - Update `worldSnapshot.currentTick += 1`

2. **Advance traveling clansmen:**
   - For each clansman with active mission and `state == TRAVELING`:
     - If `currentTick >= mission.arrivalTick`: transition state to `ACTING`, set `currentRegion = targetRegion`, write a `WorkerArrived`-style `eventLog` entry
     - Else: leave alone (their `effectiveRegion` derives from elapsed ticks)

3. **Resolve completed action missions:**
   - For each clansman with `state == ACTING`:
     - With ~10% probability per tick: complete the mission. Transition to `WAITING`, increment vault resources for gathering missions, write `mission_completed` and `resources_gathered`/`resources_deposited` events
     - This produces the visible "wheelbarrow fills, returns home, deposits" demo loop without implementing real gathering math

4. **Generate new mock missions:**
   - For each `WAITING` clansman with cooldown clear:
     - With ~30% probability: assign a random valid mission (random region + random valid action)
     - Write `mission_assigned` event
     - Set `state = TRAVELING` if traveling needed, else `ACTING`
     - This keeps the world visibly active

5. **Tick the bandit FSM:**
   - Camping → Camping → Camping → Attacking (resolved as defended/not by a coin flip) → Resting → Resting → Move clockwise → repeat
   - Write appropriate events for each state transition
   - Every ~50 ticks of inactivity, spawn a fresh bandit

6. **Perturb market prices:**
   - For each resource pool, apply a small random walk (~±2%)
   - Append a `priceHistory` row per resource

7. **Occasionally trigger a building upgrade:**
   - With ~5% probability per tick, pick a random clan and upgrade a random building one level
   - Write `building_upgraded` event
   - Update leaderboard ordering

8. **Generate occasional agent reasoning:**
   - With ~50% probability, pick a random clan and post a plausible-looking `agentLogs` entry
   - Triggers speech bubbles in the UI without needing real agents running

### 10.4 Mock mode runtime

```typescript
// convex/crons.ts
if (config.mockMode) {
  crons.interval('mockTick', { seconds: 20 }, internal.mock.advanceMockTick);
} else {
  crons.interval('heartbeat', { seconds: 20 }, internal.actions.heartbeatCaller.callHeartbeat);
  crons.interval('eventPoll', { seconds: 5 }, internal.actions.eventIndexer.poll);
}
```

A single `MOCK_MODE` env var swaps the entire backend personality. Frontend never knows the difference.

### 10.5 Why this is worth building

Mock mode is the **single highest-leverage milestone for unblocking the team**. Frontend, agent runner, and even art workstreams can all see "what does a working ClanWorld look like" without contracts being deployed. Build M1 + M2 (Convex schema + mock mode) within the first 3 hours of backend work and the rest of the team is unblocked indefinitely.

---

## 11. Build Milestones

### M1: Schema and queries (1.5 hours)
- `package.json` with Convex, viem, abitype
- `convex/schema.ts` complete per §4
- All 8 queries in §7 implemented as no-op shims that return empty results
- `convex dev` running locally, queries deploy successfully
- Frontend can connect and call all 8 queries (returns nothing, but no errors)

### M2: Mock mode (1.5 hours)
- `seedMockState` populates believable rows in every snapshot table
- `advanceMockTick` cron flips state every 20s
- Frontend renders a working scene against mock Convex data
- **Frontend stream is now unblocked from waiting on the contract.**

### M3: Event indexer (2 hours)
- viem WebSocket client wired
- ABI imported from compiled IClanWorld
- `eventIndexer.poll` action processing logs since checkpoint
- Event → `eventLog.kind` mapping per §5.3 implemented
- Tick advance triggers state-poll via scheduler
- Verified end-to-end: emit a `MissionAssigned` on local fork, see it in `eventLog`

### M4: State indexer (2 hours)
- `tickIndexer` calls all four UI aggregator getters
- Snapshot tables populated from raw struct decoding
- Price history sampled per resource per tick
- Verified: deploy contract, run heartbeat, see Convex tables update

### M5: Heartbeat caller (1 hour)
- Wallet derivation from mnemonic via Makefile script (passes private key as env to Convex)
- Cron firing at configured cadence
- Failure logging clean

### M6: Agent write path (0.5 hours)
- `postLog` and `postWhisper` mutations implemented
- Agent runner can POST and frontend sees results via subscription

**Total: ~8.5 hours of focused backend work.** Compresses to one calendar day with one builder, half a day with two builders splitting indexer and heartbeat caller.

### M1 and M2 unblock the frontend stream. Prioritize them. Ship M2 within the first 3 hours of backend work and the frontend never has to wait again.

---

## 12. Open Questions

These need answers before implementation lands. Each is small enough to be resolved by the time the relevant milestone starts.

**To contract team:**
- Confirm whether the contract emits a `TickAdvanced` event from `heartbeat()` synchronously, before any other tick-end events. The indexer relies on `TickAdvanced` to trigger state-poll *after* all tick-end side effects have been written. If `TickAdvanced` fires *first* (before bandit attacks etc. for that tick), we either need to delay state-poll by a few ms or use a different trigger.
- Confirm `heartbeat()` reverts cleanly if called too early (vs. silently no-op). Affects how the heartbeat caller logs failures.
- Provide the deployed contract address as soon as it's live so the indexer has a target.

**To frontend team:**
- Do you actually need `getRecentLogs` per-clan, or only the global feed? The per-clan filter adds an index; if unused, drop it.
- Confirm the `tickEpoch` shape. Frontend spec §5.3 expects it nested in `TickEpoch`; this doc returns it merged at the top level of `getSnapshot`. Pick one and align.

**To agent runner team:**
- Provide the agent-side wrapper for `postLog` and `postWhisper`. This is on you, but coordinate the caller signature so it matches the Convex mutation args exactly.
- Confirm 240-char cap on reasoning is enough. If not, tell the frontend to increase the speech bubble truncation limit too.

---

## 13. Out of Scope

Not for v1, will tempt you, don't:

- Authentication / authorization on agent mutations
- Per-tick state diffs in tables (we overwrite)
- Multi-world support (we run one)
- Backfill / historical replay
- Pagination on any query
- WebSocket connection pooling beyond what viem does by default
- Webhook integrations
- Discord/Twitter bridge
- Any analytics / metrics export
- Custom error pages, custom 500 handling

If a backend agent suggests adding any of these, decline and point them at this section.

---

## 14. Definition of Done

The Convex backend is demo-ready when:

1. `convex dev` deploys cleanly with no schema errors
2. All 8 queries return live data when subscribed
3. A new `MissionAssigned` onchain event appears in the `eventLog` table within 10 seconds
4. `tickIndexer` refreshes all snapshot tables on every observed `TickAdvanced`
5. Price history accumulates one row per resource per tick
6. Heartbeat caller successfully advances ticks at the configured cadence
7. Agent runner can post logs and whispers and frontend sees them
8. Total RPC call rate stays under quota for at least 30 minutes of continuous demo

If those eight things are true on a Tuesday afternoon dry run, the backend has done its job.
