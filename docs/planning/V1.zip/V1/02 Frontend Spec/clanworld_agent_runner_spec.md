# ClanWorld Agent Runner — Spec

**Status:** Draft v1, hackathon-scoped
**Owner:** Agent runner team
**Depends on:** `IClanWorld.sol` (seam interface, locked), Convex backend spec (read interface, query contract)
**Audience:** Anyone implementing the LLM-driven agents

---

## 0. Purpose

The agent runner is the program that makes ClanWorld *play itself*. It runs 4–6 LLM agents, each controlling one clan, each making decisions every tick by reading the world from Convex and submitting transactions onchain.

This is the demo's protagonist. A working backend is invisible. A working frontend is pretty. **Working agents are the moment a judge says "wait, the AI is actually playing."** Everything else exists to make this layer legible.

Three jobs:

1. **Read** the world from Convex on every tick.
2. **Reason** via LLM about what the clan should do.
3. **Act** by submitting mission transactions onchain and posting reasoning to Convex.

Everything else is plumbing.

---

## 1. Architecture Overview

```
┌─────────────────────────────────────────────────┐
│  agent-runner (single Node process)             │
│                                                 │
│  ┌─────────────────────────────────────────┐    │
│  │ orchestrator                            │    │
│  │  - tracks current tick                  │    │
│  │  - fans out per-agent tick events       │    │
│  │  - collects results                     │    │
│  └────────────────┬────────────────────────┘    │
│                   │                             │
│       ┌───────────┼───────────┐                 │
│       │           │           │                 │
│   ┌───▼───┐   ┌───▼───┐   ┌───▼───┐             │
│   │agent 1│   │agent 2│   │agent N│   ...       │
│   │       │   │       │   │       │             │
│   │ read  │   │ read  │   │ read  │             │
│   │ think │   │ think │   │ think │             │
│   │ act   │   │ act   │   │ act   │             │
│   └───┬───┘   └───┬───┘   └───┬───┘             │
│       │           │           │                 │
└───────┼───────────┼───────────┼─────────────────┘
        │           │           │
        ▼           ▼           ▼
   ┌─────────┐ ┌─────────┐ ┌─────────┐
   │ Convex  │ │ ClanWorld│ │ Anthropic│
   │ (read + │ │ contract │ │ /OpenAI  │
   │ post)   │ │  (write) │ │  (LLM)   │
   └─────────┘ └─────────┘ └─────────┘
```

Single Node process, N agents inside. Each agent owns:
- one wallet (derived from the team mnemonic)
- one clan
- one persistent strategic-alignment string
- one in-memory short-term memory of recent observations and whispers

Agents are **independent** — they don't share state with each other except through Convex (whispers, agent logs, world state). One slow LLM call doesn't block another agent's tick.

---

## 2. Tech Stack

```jsonc
{
  "dependencies": {
    "viem": "^2.x",
    "convex": "^1.x",
    "@anthropic-ai/sdk": "^0.x",
    "ethers": "optional alternative",
    "dotenv": "^16.x",
    "p-queue": "^8.x"
  },
  "devDependencies": {
    "typescript": "^5.x",
    "tsx": "^4.x"
  }
}
```

**LLM provider choice.** Anthropic's Claude (Sonnet) is the primary. Reasons: tool-use is reliable, structured outputs are clean, latency is acceptable at 15–20s tick cadence, and the `claude-haiku` fallback exists for cost-conscious mass play. OpenAI's GPT-4o is a fine fallback. Both via the same internal `LLMClient` interface so we can swap.

**Why Node + tsx, not Convex actions for the agents.** Convex actions are great for short, deterministic work. LLM tool-use loops can take 10+ seconds and want to retry, stream, and recover. A long-lived Node process is the right shape. Convex is the read+write interface, not the runtime.

**Tick budget arithmetic — worst case can overrun a tick window.**

For a 20s tick:
- jitter: 0–2s
- observe: ~1–4s (8 parallel Convex queries)
- think: up to 12s (LLM hard timeout)
- act: ~2–5s (tx submission + receipt wait)
- **worst case total: ~23s**

This is fine. The orchestrator polls Convex independently for tick advances rather than assuming a fresh tick has just begun. If an agent's previous tick is still running when a new tick advances, the orchestrator skips that agent for the new tick. No queueing, no backlog. The agent's next observation will reflect the now-current tick state. This degradation pattern is correct, not broken — see §5.3.

---

## 3. Configuration

```typescript
// src/config.ts
export const config = {
  // Chain
  rpcUrl: process.env.ALCHEMY_RPC_URL!,
  chainId: Number(process.env.CHAIN_ID ?? 8453),
  contractAddress: process.env.CLANWORLD_ADDRESS! as `0x${string}`,

  // Convex
  convexUrl: process.env.CONVEX_URL!,
  worldId: 'demo',

  // LLM
  llmProvider: (process.env.LLM_PROVIDER ?? 'anthropic') as 'anthropic' | 'openai',
  anthropicApiKey: process.env.ANTHROPIC_API_KEY,
  openaiApiKey: process.env.OPENAI_API_KEY,
  // Confirm exact model string at implementation time. The Anthropic SDK accepts
  // public model aliases (e.g., 'claude-sonnet-4-5'). Pick the latest available
  // Sonnet at hackathon time. Haiku-tier is the cost-conscious fallback.
  llmModel: process.env.LLM_MODEL ?? 'claude-sonnet-4-5',
  llmTempPerAgent: 0.7,                      // mild creativity, not chaos
  llmMaxTokens: 1500,

  // Wallet
  agentMnemonic: process.env.AGENT_MNEMONIC!, // BIP-39, 12 or 24 words
  derivationBase: "m/44'/60'/0'/0",           // standard ethereum
  agentDerivationStart: 0,                    // agent 0 = m/44'/60'/0'/0/0

  // Agents
  agentCount: Number(process.env.AGENT_COUNT ?? 4),
  agentNames: (process.env.AGENT_NAMES ?? 'Aldric,Mira,Brennan,Sora,Toren,Vey').split(','),

  // Cadence
  tickDurationMs: Number(process.env.TICK_DURATION_MS ?? 20000),
  agentThinkBudgetMs: 12000,                  // hard cap on LLM call duration
  agentTickJitterMs: 2000,                    // stagger agents within a tick

  // Behavior
  reasoningCharCap: 240,                      // matches Convex postLog cap
  whisperCharCap: 500,
  enableWhispers: true,
  enableStrategicAlignment: true,
};
```

---

## 4. Wallet Model

### 4.1 Derivation

All agent wallets derive from one BIP-39 mnemonic via standard Ethereum HD paths:

```
m/44'/60'/0'/0/0   → agent 0 (clanId 1)
m/44'/60'/0'/0/1   → agent 1 (clanId 2)
m/44'/60'/0'/0/2   → agent 2 (clanId 3)
...
```

The Makefile owns mnemonic generation, funding, and clan minting. The agent runner only consumes the mnemonic via env var and derives addresses on startup.

### 4.2 Funding

The Makefile script runs once before each demo:

```makefile
fund-agents:
	./scripts/derive-and-fund.ts $(AGENT_COUNT)

spawn-clans:
	./scripts/mint-clans.ts $(AGENT_COUNT)
```

Each agent gets a small ETH balance (~0.01 ETH on Base) to cover mission txs for the demo. Mission txs are cheap; this funds hundreds of them.

### 4.3 Clan-to-agent mapping

The minting script writes a `clan-agent-mapping.json` file:

```json
{
  "demo-2026-04-25": [
    { "agentIndex": 0, "name": "Aldric", "address": "0xabc...", "clanId": 1 },
    { "agentIndex": 1, "name": "Mira", "address": "0xdef...", "clanId": 2 }
  ]
}
```

The agent runner reads this on startup. No onchain lookup needed.

---

## 5. Tick Loop

### 5.1 Orchestrator

The orchestrator is one `setInterval`-driven function that polls the Convex `tickEpoch.currentTick` and triggers agents when the tick advances:

```typescript
let lastProcessedTick = 0;

setInterval(async () => {
  const epoch = await convex.query('world.getSnapshot');
  if (!epoch) return;
  if (epoch.tickEpoch.currentTick <= lastProcessedTick) return;

  lastProcessedTick = epoch.tickEpoch.currentTick;

  for (const agent of agents) {
    const jitter = Math.random() * config.agentTickJitterMs;
    setTimeout(() => agent.runTick(epoch.tickEpoch.currentTick), jitter);
  }
}, 2000);  // poll every 2s, much faster than tick cadence
```

**Why polling Convex instead of subscribing:** `convex` Node SDK supports subscriptions, but for a single value polled every 2s the simpler API is fine and more predictable for the hackathon. Subscribe later if it matters.

**Why the jitter:** four agents simultaneously calling the LLM on the exact same wall-clock tick produces correlated rate-limit issues and crowds the Anthropic API. Spreading by 0–2s smooths the load and feels more natural in the UI when reasoning bubbles appear.

### 5.2 Per-agent tick

```typescript
async runTick(currentTick: number) {
  // 1. read world from Convex
  const obs = await this.observe();

  // 2. reason via LLM
  const decision = await this.think(obs);

  // 3. act
  await this.act(decision, currentTick);
}
```

Each step has a hard timeout. If `think()` takes >12s, we abort and skip the tick (agent stays idle that tick — its workers continue with their existing missions). If `act()` partially fails (e.g., one mission tx reverts), we log and proceed.

### 5.3 Skipping ticks is fine

The contract is designed for missed ticks (real-time cooldown is 60s, so an agent missing one demo tick doesn't break anything). If LLM latency or chain congestion causes a skip, log it and move on. **Don't queue retries** — by the time the retry runs, the world state is different and the reasoning is stale.

---

## 6. Observation Model

### 6.1 What the agent sees

Per tick, the agent reads from Convex:

```typescript
type AgentObservation = {
  currentTick: number;
  ticksRemaining: number;                     // until season end
  winterActive: boolean;
  banditAlert: ActiveBanditView | null;       // null if no bandit, raw view if any

  myClan: ClanFullView;
  otherClans: LeaderboardEntry[];             // public view of all other clans

  market: {
    wood: { spot: number; recent: number[] }; // 8 most recent ticks
    iron: { spot: number; recent: number[] };
    wheat: { spot: number; recent: number[] };
    fish: { spot: number; recent: number[] };
  };

  recentEvents: EventLogEntry[];              // 20 most recent
  recentWhispersInbound: Whisper[];           // last 10, addressed to me or broadcast
  myRecentLogs: AgentLog[];                   // last 5 of my own reasoning, for self-continuity

  strategicAlignment: string;                 // persistent guidance
};
```

### 6.2 Why each field

- `myClan` — full state of my own clan: clansmen, missions, vault, plots, defenders. The bulk of what I reason about.
- `otherClans` — lightweight public summary, not full views. The contract publishes only what's onchain anyway. No private vault peeking.
- `market` — recent prices give the LLM enough context to recognize trends without dumping a full price history.
- `recentEvents` — what just happened in the world. Critical for reactivity (the bandit just attacked someone; respond).
- `recentWhispersInbound` — the entire diplomatic surface lives here.
- `myRecentLogs` — short-term memory. Without this, agents lose continuity ("why did I send Garrick north 30 seconds ago?").
- `strategicAlignment` — long-term goals from the player. Empty for v1 (agents play freely); kept in the model for future when humans direct them.

### 6.3 What the agent does NOT see

- Other clans' vault contents (only loot value rank — same as the contract's onchain visibility)
- Other clans' active missions (only events visible in the public log)
- The next tick's RNG seed
- LLM reasoning from other agents (their `agentLogs` are public via Convex, but each agent reads only its own — competing access to others' reasoning is a future feature, not v1)
- Anything outside the public Convex tables

This matches the contract's information model. **Don't leak private state through the agent observer.**

---

## 7. Tool Schema

The LLM has a constrained set of tools. Smaller is better. Every tool is a function the agent runner exposes via the LLM SDK's tool-use API.

### 7.1 Tool definitions

```typescript
const tools = [
  {
    name: 'dispatch_missions',
    description: 'Submit one or more missions for clansmen in your clan. Each clansman can have at most one active mission. Returns per-mission status codes.',
    input_schema: {
      type: 'object',
      properties: {
        missions: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              clansmanId: { type: 'number' },
              gotoRegion: { type: 'number', description: '1=Forest, 2=Mountains, 3=UnicornTown, 4=WestFarms, 5=EastFarms, 6=WestDocks, 7=EastDocks, 8=DeepSea, 0=stay (no travel)' },
              action: {
                type: 'string',
                enum: ['ChopWood','MineIron','FishDocks','FishDeepSea','HarvestWheat','DepositResources','BuildWall','UpgradeBase','UpgradeMonument','DefendBase','MarketBuy','MarketSell','Wait']
              },
              targetClanId: { type: 'number', description: 'Required for DefendBase. The clanId of the base being defended.' },
              marketResource: { type: 'string', enum: ['Wood','Iron','Wheat','Fish'], description: 'Required for MarketBuy/MarketSell.' },
              marketAmount: { type: 'string', description: 'For MarketSell: exact amount of resource to sell. For MarketBuy: exact amount of resource to buy. As 18-decimal string.' },
              maxGoldIn: { type: 'string', description: 'Required for MarketBuy. Max gold willing to spend, 18-decimal string.' }
            },
            required: ['clansmanId','gotoRegion','action']
          }
        },
        reasoning: {
          type: 'string',
          description: 'Brief explanation of why these missions, max 240 chars. Shown to viewers as a speech bubble.'
        },
        triggeringClansmanId: {
          type: 'number',
          description: 'Optional. The clansman whose mission this reasoning most directly attaches to. Defaults to the first mission'\''s clansman.'
        }
      },
      required: ['missions','reasoning']
    }
  },

  {
    name: 'send_whisper',
    description: 'Send a private message to another clan or broadcast publicly. Used for diplomacy, threats, alliances, deception.',
    input_schema: {
      type: 'object',
      properties: {
        toClanId: { type: 'number', description: 'Target clanId, or omit for public broadcast.' },
        body: { type: 'string', description: 'Max 500 chars.' }
      },
      required: ['body']
    }
  },

  {
    name: 'transfer_resources',
    description: 'Transfer gold, blueprints, or vault resources to another clan. No protocol-enforced reciprocity; trust is social.',
    input_schema: {
      type: 'object',
      properties: {
        toClanId: { type: 'number' },
        gold: { type: 'string', description: '18-decimal string, default 0' },
        blueprint: { type: 'string', description: '18-decimal string, default 0' },
        wood: { type: 'string', description: '18-decimal string, default 0' },
        iron: { type: 'string', description: '18-decimal string, default 0' },
        wheat: { type: 'string', description: '18-decimal string, default 0' },
        fish: { type: 'string', description: '18-decimal string, default 0' }
      },
      required: ['toClanId']
    }
  },

  {
    name: 'do_nothing',
    description: 'Skip this tick. Use when no action improves your position. Keeps your reasoning clean and avoids wasting cooldowns.',
    input_schema: {
      type: 'object',
      properties: {
        reasoning: { type: 'string', description: 'Why doing nothing is the right choice this tick. Max 240 chars.' }
      },
      required: ['reasoning']
    }
  }
];
```

### 7.2 Why this surface and not more

Constrained tool surfaces beat clever prompting every time. The LLM cannot invent a fifth tool, so we don't have to handle "ChatGPT decided to write a poem instead of dispatching missions." The four tools above cover every game action the demo cares about. Set strategic alignment is intentionally absent — agents play freely in v1; player-driven steering is post-hackathon.

### 7.3 Tool call execution

When the LLM calls a tool, the agent runner:
1. Validates args (types, ranges, ownership).
2. For `dispatch_missions`: builds a `ClanOrder[]` and submits via `submitClanOrders(clanId, orders)` onchain. Posts reasoning to `agentLogs` regardless of tx success.
3. For `send_whisper`: posts to Convex `whispers.post` only — no onchain write.
4. For `transfer_resources`: submits via `transferBundle(...)` onchain. Posts a brief reasoning entry.
5. For `do_nothing`: posts reasoning only.

**The agent's reasoning is posted to Convex first, before any onchain tx.** Two reasons:
- Speech bubbles appear immediately in the UI even while the tx is pending.
- If the tx reverts, the reasoning still surfaces, which is good — judges see the agent's thought even if it failed.

---

## 8. Prompt Structure

### 8.1 System prompt

```
You are {AGENT_NAME}, the Elder of clan {CLAN_NAME} (clanId {CLAN_ID}) in ClanWorld, a strategic survival game played on the Base blockchain.

You command a small clan of clansmen across an 8-region world. Your goal is to outlast and outbuild rival clans by building the tallest monument and surviving until season end.

You compete against {N-1} other clans, each controlled by another agent like you. They will deceive, ally, betray, and trade with you. So can you.

Each tick is {TICK_SECONDS} seconds. You receive an observation, reason briefly about the situation, and call exactly one tool. If unsure, call do_nothing.

Behavior guidelines:
- Be decisive. Long deliberation costs ticks.
- Reasoning bubbles are public and short — keep them under 240 chars and make them dramatic.
- Whispers are how diplomacy happens. Use them to coordinate, threaten, deceive.
- The game rewards monument-building, but you must survive winters and bandits to get there.
- Mission cooldowns are 60s real-time per clansman. Don't waste them.

Your strategic ethos:
{STRATEGIC_ALIGNMENT}
```

### 8.2 The strategic alignment slot

Each agent gets a different ethos to make the demo dramatic. Suggested seeds for the demo's 4 agents:

| Agent | Strategic ethos |
|---|---|
| Aldric | "Fortify and endure. Build walls early, hoard wood, defend trades. Never strike first, but punish those who strike you." |
| Mira | "Trade aggressively. Specialize in what your region produces and dump it on the market. Use gold as a weapon. Whisper offers constantly." |
| Brennan | "Strike for monument. Race the tower. Take risks, take losses, but build before the others do. Bandits are someone else's problem." |
| Sora | "Diplomacy first. Form alliances, broker trades, share intelligence with your friends. Betray only when betrayal is decisive." |

These produce visibly distinct play styles in the demo without any per-agent code. Pure prompt content.

### 8.3 The user message

The agent observation is rendered into structured text:

```
=== TICK {currentTick} (season tick {currentTick}/{seasonEndTick}, {ticksRemaining} remaining) ===
{winterActive ? "WINTER IS ACTIVE." : ""}
{banditAlert ? `BANDITS in {region}, {state}, attempts: {made}/{max}, projected target: clan {projectedTargetClanId}` : "No bandits active."}

=== YOUR CLAN (clanId {clanId}) ===
Living clansmen: {n}
Base lvl {baseLevel}, Wall lvl {wallLevel}, Monument lvl {monumentLevel}
Vault: wood {w}, iron {i}, wheat {wh}, fish {f}, gold {g}, blueprints {bp}
Starving: {isStarving ? "YES" : "no"}
Loot value: {lootValue}

Clansmen:
- {id} ({state}, region {currentRegion}): mission={action}, carry: w{wood}/i{iron}/wh{wheat}/f{fish}, cooldown ends in {s}s
- ...

Plots: West {state} ({remaining}), East {state} ({remaining})

=== OTHER CLANS ===
- Clan {id} ({color}): monument {ml}, base {bl}, wall {wl}, livingClansmen {n}, lootValue {lv} {dead ? "[DEAD]" : ""}
- ...

=== MARKET (gold per resource) ===
Wood: spot {spot}, recent: [{...8 ticks}]
Iron: spot {spot}, recent: [{...8 ticks}]
Wheat: spot {spot}, recent: [{...8 ticks}]
Fish: spot {spot}, recent: [{...8 ticks}]

=== RECENT EVENTS ===
- tick {t}: {event description}
- ...

=== WHISPERS TO YOU ===
- from clan {id} (tick {t}): "{body}"
- ...

=== YOUR RECENT REASONING ===
- tick {t}: "{reasoning}"
- ...

What do you do this tick?
```

### 8.4 Why this structure

LLMs reason better against well-labeled blocks of structured text than against JSON dumps. The above renders to ~1500 tokens for a mid-game state, which fits comfortably in any modern model's context.

The "What do you do this tick?" closing question is important. Without it, models sometimes ramble. With it, they call a tool.

---

## 9. The Agent Class

```typescript
class Agent {
  constructor(
    readonly index: number,
    readonly clanId: number,
    readonly name: string,
    readonly wallet: WalletClient,
    readonly llm: LLMClient,
    readonly convex: ConvexClient,
    readonly contract: ContractClient,
    readonly strategicAlignment: string,
  ) {}

  async runTick(currentTick: number): Promise<void> {
    try {
      const obs = await withTimeout(this.observe(currentTick), 4000);
      const decision = await withTimeout(this.think(obs), config.agentThinkBudgetMs);
      await this.act(decision, currentTick);
    } catch (err) {
      console.warn(`[${this.name}] tick ${currentTick} skipped:`, err);
    }
  }

  private async observe(currentTick: number): Promise<AgentObservation> {
    // batch Convex queries
    const [snapshot, allClans, bandit, market, events, whispers, myLogs] = await Promise.all([
      this.convex.query('world.getSnapshot', {}),
      this.convex.query('world.getAllClanViews', {}),
      this.convex.query('world.getActiveBandit', {}),
      this.convex.query('market.getState', {}),
      this.convex.query('events.getRecent', { limit: 20 }),
      this.convex.query('whispers.getRecent', { limit: 30 }),
      this.convex.query('agents.getRecentLogs', { clanId: this.clanId, limit: 5 }),
    ]);

    const myClan = allClans.find(c => c.clan.clan.clanId === this.clanId)!;
    const otherClans = snapshot.leaderboard.filter(e => e.clanId !== this.clanId);
    const myInboundWhispers = whispers.filter(
      w => w.toClanId === this.clanId || w.toClanId === undefined
    ).slice(0, 10);

    // get price history for each resource
    const [woodHist, ironHist, wheatHist, fishHist] = await Promise.all([
      this.convex.query('market.getPriceHistory', { resource: 'wood', ticks: 8 }),
      this.convex.query('market.getPriceHistory', { resource: 'iron', ticks: 8 }),
      this.convex.query('market.getPriceHistory', { resource: 'wheat', ticks: 8 }),
      this.convex.query('market.getPriceHistory', { resource: 'fish', ticks: 8 }),
    ]);

    return {
      currentTick,
      ticksRemaining: snapshot.seasonEndTick - currentTick,
      winterActive: snapshot.winterActive,
      banditAlert: bandit?.exists ? bandit : null,
      myClan,
      otherClans,
      market: {
        wood: { spot: market.wood.spotPriceGoldPerResource, recent: woodHist.map(h => h.spotPrice) },
        iron: { spot: market.iron.spotPriceGoldPerResource, recent: ironHist.map(h => h.spotPrice) },
        wheat: { spot: market.wheat.spotPriceGoldPerResource, recent: wheatHist.map(h => h.spotPrice) },
        fish: { spot: market.fish.spotPriceGoldPerResource, recent: fishHist.map(h => h.spotPrice) },
      },
      recentEvents: events,
      recentWhispersInbound: myInboundWhispers,
      myRecentLogs: myLogs,
      strategicAlignment: this.strategicAlignment,
    };
  }

  private async think(obs: AgentObservation): Promise<ToolCall> {
    const userMessage = renderObservation(obs);
    const systemPrompt = renderSystemPrompt(this);

    const response = await this.llm.complete({
      system: systemPrompt,
      messages: [{ role: 'user', content: userMessage }],
      tools,
      tool_choice: { type: 'any' },              // force a tool call
      max_tokens: config.llmMaxTokens,
      temperature: config.llmTempPerAgent,
    });

    return parseToolCall(response);
  }

  private async act(decision: ToolCall, currentTick: number): Promise<void> {
    // post reasoning FIRST so speech bubble appears immediately
    if ('reasoning' in decision.input) {
      await this.convex.mutation('agents.postLog', {
        clanId: this.clanId,
        tick: currentTick,
        reasoning: decision.input.reasoning.slice(0, config.reasoningCharCap),
        triggeringClansmanId: decision.input.triggeringClansmanId,
      });
    }

    switch (decision.name) {
      case 'dispatch_missions':
        await this.executeDispatch(decision.input);
        break;
      case 'send_whisper':
        await this.executeWhisper(decision.input, currentTick);
        break;
      case 'transfer_resources':
        await this.executeTransfer(decision.input, currentTick);
        break;
      case 'do_nothing':
        // already posted reasoning above; no further action
        break;
    }
  }

  // ... executeDispatch, executeWhisper, executeTransfer ...
}
```

---

## 10. Validation Layer

The LLM will sometimes hallucinate values: a clansmanId that doesn't belong to the agent, an action that's invalid in the current state, a region number that doesn't exist. The agent runner validates *before* submitting.

```typescript
function validateMissions(input: DispatchMissionsInput, myClan: ClanFullView): ValidatedMissions {
  const errors: string[] = [];
  const valid: ClanOrder[] = [];

  for (const m of input.missions) {
    const clansman = myClan.clansmen.find(c => c.clansman.clansman.clansmanId === m.clansmanId);
    if (!clansman) {
      errors.push(`clansmanId ${m.clansmanId} is not in your clan`);
      continue;
    }
    if (clansman.clansman.clansman.state === 'DEAD') {
      errors.push(`clansman ${m.clansmanId} is dead`);
      continue;
    }
    if (m.gotoRegion < 0 || m.gotoRegion > 8) {
      errors.push(`region ${m.gotoRegion} is invalid`);
      continue;
    }
    if (m.action === 'DefendBase' && !m.targetClanId) {
      errors.push(`DefendBase requires targetClanId`);
      continue;
    }
    if ((m.action === 'MarketBuy' || m.action === 'MarketSell') && !m.marketResource) {
      errors.push(`Market actions require marketResource`);
      continue;
    }
    valid.push(buildClanOrder(m));
  }

  return { valid, errors };
}
```

Errors are logged but do not propagate to the LLM. **The LLM is not retried.** A bad call this tick is one missed action; we move on. Re-prompting risks burning the entire 12s think budget.

---

## 11. Transaction Submission

### 11.1 Resource → token address resolution

The LLM tool schema accepts `marketResource: 'Wood' | 'Iron' | 'Wheat' | 'Fish'` (a friendly enum), but the contract requires `marketToken: address` (an actual ERC20 contract address).

The agent runner builds a resolution table once at startup by calling `getTreasuryState()`:

```typescript
// at runner boot, after mapping file is loaded:
const treasury = await contract.read({ functionName: 'getTreasuryState' });
const resourceTokenMap: Record<string, `0x${string}`> = {
  Wood: treasury.woodToken,
  Iron: treasury.ironToken,
  Wheat: treasury.wheatToken,
  Fish: treasury.fishToken,
};
```

This table is shared across all agents (read-only, set once). When `executeDispatch` builds a `ClanOrder`, it uses `resourceTokenMap[input.marketResource]` to populate `marketToken`. Treasury values don't change after deployment, so caching at boot is safe.

### 11.2 `executeDispatch`

```typescript
private async executeDispatch(input: DispatchMissionsInput): Promise<void> {
  const { valid, errors } = validateMissions(input, this.lastObs.myClan);
  if (errors.length) {
    console.warn(`[${this.name}] validation errors:`, errors);
  }
  if (valid.length === 0) return;

  try {
    const hash = await this.contract.write({
      address: config.contractAddress,
      abi: CLANWORLD_ABI,
      functionName: 'submitClanOrders',
      args: [this.clanId, valid],
    });

    console.log(`[${this.name}] submitClanOrders tx ${hash}`);

    // wait for receipt with a generous timeout
    const receipt = await this.contract.waitForTransactionReceipt({ hash, timeout: 8000 });
    if (receipt.status !== 'success') {
      console.warn(`[${this.name}] tx reverted`);
    }
  } catch (err) {
    console.warn(`[${this.name}] submitClanOrders failed:`, err);
  }
}
```

**Receipt waits are bounded.** If the tx hasn't confirmed in 8s, we log and move on. The next tick's observation will reflect whatever actually happened onchain. Don't block the next tick on this tick's confirmation.

---

## 12. Whispers and Diplomacy

### 12.1 Why whispers exist

The most demo-compelling moments will be inter-agent communication: alliances forming, betrayals happening, public threats being issued. None of this is in the contract. It all flows through Convex `whispers`.

### 12.2 Whisper read access

By design, an agent reads:
- All public broadcasts (whispers with `toClanId == undefined`)
- All whispers addressed to its own clanId

It does NOT read whispers between two other clans. This is correct — it preserves information asymmetry and lets agents bluff. The Convex query helper handles the filter.

### 12.3 Whisper write rules

- Length cap: 500 chars
- No format restrictions
- No moderation
- No retry on failure (whispers are best-effort)

### 12.4 Demo seed: opening whispers

To kickstart drama, the agent runner can optionally seed each agent's first tick with a "introduce yourself to the other clans" instruction prepended to the user message. Once the first round of introductions happens, the conversation runs itself.

---

## 13. Strategic Alignment

For v1, strategic alignment is **static per agent**, set at startup from the `clan-agent-mapping.json` file. Each agent gets its ethos at boot and never changes it.

Post-hackathon: a player-facing UI for setting alignment, plus a `setAlignment` mutation in Convex. Out of scope.

---

## 14. Logging and Observability

### 14.1 What to log

Every agent tick logs:
- Tick number, agent name, clan id
- Tool called and args (truncated)
- Tx hash if applicable
- Latency: observe / think / act
- Any validation errors

Log format: structured JSON to stdout. Pipe to a file for the demo:

```bash
tsx src/runner.ts | tee runner.log
```

### 14.2 What NOT to log

- LLM raw responses (too verbose; reasoning is already captured in agentLogs)
- Full observation payloads (too big; rebuild from Convex if needed)
- Wallet private keys (obviously)

### 14.3 Demo-day observability

A simple dashboard, optional. Mint with `make dashboard` to open:

```
TICK 47 | Aldric: dispatched 2 missions  | Mira: whispered Brennan
        | Brennan: dispatch missions x3  | Sora: do_nothing
```

A 4-line tail showing the last action per agent. Built as a separate small CLI tool. Cut if time pressure hits.

---

## 15. Failure Modes and Recovery

| Failure | Effect | Response |
|---|---|---|
| LLM API timeout | Agent skips tick | Log, continue |
| LLM API rate limit | Agent skips tick | Log, optionally back off the next tick |
| LLM produces malformed tool call | Agent skips tick | Log, continue (no retry) |
| Mission tx reverts onchain | Mission doesn't apply | Log, continue (next obs will reflect reality) |
| Whisper post fails | Whisper lost | Log, continue (don't retry) |
| Convex query timeout | Agent skips tick | Log, continue |
| Agent process crashes | Process restarts via Makefile / systemd | Last tick's missions may have been duplicated; contract validates so this is safe |

The runner is **stateless across restarts**. On boot it reads the mapping file, derives wallets, and starts polling Convex. No on-disk state to corrupt.

---

## 16. Build Milestones

### M1: Wallet derivation and Convex read (1 hour)
- Project scaffolded with TypeScript + tsx + viem + Convex client + Anthropic SDK
- BIP-39 mnemonic → derived addresses
- One agent successfully reads `getSnapshot` and prints to console
- Confirms the Convex deployment is reachable

### M2: Single-agent loop end-to-end (2.5 hours)
- One agent's `observe → think → act` loop functional
- LLM tool-use parsed
- One mission dispatch tx submitted onchain
- Reasoning posted to Convex, visible in frontend
- **Demo of one LLM controlling one clan working end-to-end.**

### M3: Multi-agent orchestrator (1 hour)
- Orchestrator runs N agents in parallel with jitter
- Each agent has distinct strategic alignment
- Whispers between agents working

### M4: Validation and timeout hardening (1.5 hours)
- Validation layer catches bad LLM outputs
- Timeouts on observe / think / act
- Skipped ticks logged cleanly
- Agents recover from individual failures

### M5: Polish (2 hours)
- Demo-day dashboard CLI tool
- Tunable strategic alignments tested
- Whisper seed messages for demo opening
- Recording rehearsal

**Total: ~8 hours.** One day with one builder, half a day with two.

### M1 and M2 are critical-path. M3 onward is parallelizable.

---

## 17. Open Questions

**To frontend team:**
- Confirm `triggeringClansmanId` semantics for speech bubbles. If a mission dispatch covers 3 clansmen, the reasoning bubble appears over which one? My recommendation: the first in the array. Confirm or override.
- Confirm whisper rendering: do public broadcasts and 1-to-1 whispers look distinct in the UI? They probably should.

**To backend team:**
- Confirm `agents.postLog` accepts mutations from arbitrary callers (no auth). Demo-trust model.
- Confirm `whispers.post` accepts the optional `toClanId` correctly when omitted (broadcast).
- Confirm the price history query returns chronological order for the recent[] field consumption.

**To contract team:**
- What's the gas estimate for `submitClanOrders` with 5 missions? Need to make sure agent wallets are funded enough for 360 ticks × multiple agents.
- Does the contract emit a clear event when an order in `submitClanOrders` is rejected vs. accepted? The agent's internal validation tries to filter, but contract-side rejection should still be observable.

---

## 18. Out of Scope for v1

Cut explicitly:

- Agent memory beyond 5 recent reasoning entries (no long-term memory store)
- Cross-agent reasoning visibility (each agent reads only its own logs)
- Player-driven strategic alignment UI
- Per-agent LLM model selection
- Adversarial prompt-injection defense in whispers (whispers are not part of the LLM context for other agents in a structured way that makes injection trivial; trust the demo audience to not be malicious)
- Agent self-reflection / post-tick critique loops
- Multi-step tool-call sessions (one tool call per tick is the rule)
- Streaming LLM responses (not needed; speech bubbles appear after the call completes)
- Discord/Twitter integration for whispers
- Agent voice / TTS

---

## 19. Definition of Done

The agent runner is demo-ready when:

1. 4 agents start successfully from a single `tsx src/runner.ts` command
2. Each agent reads world state every tick within 4s
3. Each agent produces a tool call within 12s of the tick advance
4. Mission txs submit onchain and appear in the frontend within 10s
5. Reasoning bubbles appear in the frontend within 2s of decision
6. Whispers between agents appear in the chat panel
7. Strategic alignments produce visibly distinct play styles in a 6-minute demo
8. Process runs continuously for 30 minutes without crash
9. At least one alliance and one betrayal happen organically in a recorded session

If those nine things are true, the agents are demo-ready. Especially #9 — that's the moment the demo wins.
