# ClanWorld Frontend — Visual & Architecture Spec

**Status:** Draft v1, hackathon-scoped
**Owner:** Frontend agent team
**Depends on:** `IClanWorld.sol` (seam interface), Convex backend spec (TBD)
**Audience:** Anyone implementing the visual demo client

---

## 0. Purpose

This document is the source of truth for the ClanWorld demo client. It specifies what the user sees, how the codebase is organized, and exactly what data the client subscribes to from Convex.

If a question is not answered here, the answer is: do whatever produces the most legible, dramatic, mobile-first demo. When in doubt, optimize for the 8 demo moments listed in §10.

This is a hackathon spec. It is opinionated, not exhaustive. Cut anything that doesn't make the demo better.

---

## 1. Visual Style Guide

### 1.1 Aesthetic direction

**Reference frame:** illuminated manuscript meets 16-bit JRPG overworld. Final Fantasy 6 / Chrono Trigger / HoMM 3 / Civilization 2.

The world is a beautifully-rendered miniature **chessboard**. Agents are the players; clansmen are pieces; the world is a hand-drawn map you watch from above. The game does not feel like a wargame — it feels like an *unfolding strategic tableau* with whimsy at its center.

Three principles override anything else in this doc:

1. **Legibility first.** Sprites must read at a glance, including at the strategic zoom level. If a detail can't be seen, it doesn't exist.
2. **Drama over fidelity.** A cheap pulse-and-flash on a bandit-threatened base beats a perfectly-rendered combat animation. Make the moments unmissable.
3. **Restraint in motion.** 4–8 fps sprite animation is *correct*, not a compromise. Choppy frames are the style.

### 1.2 Color palette

All colors are committed pixel-art-friendly hex values. No CSS variables, no theme switcher.

**Chrome / HUD**

| Token | Hex | Use |
|---|---|---|
| `parchment` | `#E8D8B5` | HUD panel backgrounds |
| `parchment-dark` | `#C9B58A` | HUD panel inset shading |
| `ink` | `#3D2817` | Primary text, borders |
| `ink-soft` | `#6B4F3A` | Secondary text |
| `gold-trim` | `#9C7C3C` | Ornamental border accents |
| `gold-bright` | `#D4A24C` | Highlights, leaderboard winner |
| `red-alert` | `#B23A48` | Bandit warnings, defense fail |
| `green-good` | `#3F704D` | Confirmation, deposit success |

**Regions**

| Region | Hex | Notes |
|---|---|---|
| Forest | `#4A6B3F` | Mossy green |
| Mountains | `#6B7280` | Slate gray with snow caps `#E5E7EB` |
| Unicorn Town | `#D8B4D8` | Pastel lavender — only bright spot |
| West Farms | `#D4B260` | Golden wheat |
| East Farms | `#C9A55B` | Slightly different wheat tone |
| West Docks | `#5A8B8B` | Faded teal |
| East Docks | `#4F7E7E` | Slightly different teal |
| Deep Sea | `#2C3E5D` | Twilight navy |

**Clan heraldic colors** (assigned by `colors[clanId - 1]`, treating the array as 0-indexed; 8 clans max for v1)

| clanId | Hex | Name |
|---|---|---|
| 1 | `#B23A48` | Crimson |
| 2 | `#2C5F8D` | Cobalt |
| 3 | `#D4A24C` | Gold |
| 4 | `#3F704D` | Forest |
| 5 | `#7B3F8C` | Amethyst |
| 6 | `#A85A2C` | Copper |
| 7 | `#E8D8B5` | Ivory |
| 8 | `#475569` | Slate |

If clanId exceeds 8 (shouldn't happen in v1; max realm size is 8 per master coordination decision), fall back to `colors[((clanId - 1) % 8)]`.

Clan color appears on: clansman caps, base flags, leaderboard rows, mission log entries, speech bubble borders.

### 1.3 Typography

| Use | Font | Notes |
|---|---|---|
| HUD labels, panel titles | `"Press Start 2P"`, monospace | Pixel display font |
| HUD body text | `"VT323"`, monospace | Pixel terminal font (more readable at small sizes) |
| LLM speech bubble content | `"VT323"` | Same family, italicized |
| Numbers / counters | `"VT323"`, tabular figures | Avoid `Press Start 2P` for numbers; too wide |

Both fonts are Google Fonts, free, hackathon-safe.

### 1.4 Sprite dimensions

**Strategic atlas** (`atlas_world.png`)
- Clansman: 8×8
- Building (base/wall/monument): 16×16
- Region terrain accent (tree, mountain peak, wheat tuft): 8×8
- Bandit troop: 12×12
- All sprites: 1 frame, no animation

**Detail atlas** (`atlas_detail.png`)
- Clansman: 24×24, 4-frame walk cycle, 4-frame action cycle per action type
- Buildings: 48×48 base, 32×64 monument tower (taller as level rises), 32×16 wall segment
- Bandit troop: 32×32, 4-frame idle, 4-frame attack
- Environmental motion sprites (smoke, wave, wheat sway, campfire): 16×16, 4 frames each
- Animation rate: **6 fps** for character actions, **4 fps** for ambient motion

Both atlases are PNG, nearest-neighbor scaling enforced via CSS `image-rendering: pixelated` and Pixi `SCALE_MODES.NEAREST`.

### 1.5 Animation rate philosophy

Sprite frames advance at the rates above (4–8 fps). The render loop runs at display rate (typically 60 fps) for smooth camera/pan, but sprite frame index advances on its own slow clock. This is what produces the chunky-frame charm without making the world feel laggy.

---

## 2. Information Architecture

Every pixel on screen serves one of the 8 demo moments. If a panel doesn't, cut it.

### 2.1 Screen regions (portrait phone, 390×844 reference)

```
┌──────────────────────────────────┐
│  TOP HUD: tick clock | season    │  56 px tall
│  bar | winter | bandit warning    │
├──────────────────────────────────┤
│                                  │
│                                  │
│       WORLD CANVAS               │  fills middle
│       (single PixiJS canvas)     │
│                                  │
│                                  │
├──────────────────────────────────┤
│  EVENT TICKER (1 line, scrolls)  │  32 px
├──────────────────────────────────┤
│  TAB BAR: Leaderboard | Market | │  56 px tall
│  Chat | Inspector                │
└──────────────────────────────────┘
```

Bottom tabs swap a single drawer (slides up from below tab bar, ~40% of screen height when open). Only one tab can be open at a time. World canvas is always visible.

### 2.2 Panel inventory

**Top HUD bar (always visible)**
- Current tick number + season progress fraction (`tick 47 / 360`)
- Winter indicator (snowflake icon if `winterActive`)
- Bandit warning chip if `activeBandit.exists` (red, pulsing if `state == CAMPING` or `ATTACKING`)
- Settings/menu button (right edge, opens an overlay; not in scope for v1 — leave a placeholder)

**World canvas (always visible)**
- 8 region polygons with terrain art
- Clansman sprites in their derived regions
- Building sprites (base, wall, monument) at each homebase
- Bandit troop sprite if active
- Speech bubbles over clansmen who recently received an LLM-driven mission (auto-fade after 8 seconds)
- Region tap zones for the detail-view tooltip

**Event ticker (always visible)**
- Single-line marquee of recent world events
- Examples: `Crimson clan dispatched Garrick → Mountains • Bandits camp in East Farms • Cobalt sold 12 wood for 4.8 gold`
- Most recent 20 events; scrolls right-to-left at ~40 px/sec
- Tappable: opens the Mission Log drawer at the tapped event

**Drawer tabs** (one open at a time, slides up from bottom)

*Tab 1: Leaderboard*
- One row per clan
- Columns: rank, clan banner color + name, monument level (visual stack of stones), wallLevel/baseLevel chips, lootValue, alive/dead state
- Sorted by monument level desc, then earliest-tick-reached, then lootValue (matches v4 §9.1)

*Tab 2: Market*
- 4 resources: wood, iron, wheat, fish
- For each: current spot price (gold per resource), 32-tick sparkline, scheduled-trade indicator if any pending
- Recent trade list: most recent 10 trades across all clans

*Tab 3: Chat (whispers + LLM reasoning)*
- Two sub-tabs: "Public Whispers" (broadcast) and "Inter-clan" (1-to-1)
- Each message shows clan banner, agent name, message body, timestamp
- LLM reasoning excerpts from `agentLogs` table also surface here (different visual treatment — italicized, dimmer)

*Tab 4: Inspector*
- Shows whatever the user last tapped on the world canvas
- Tapped a clansman: shows mission, status, carry, cooldown
- Tapped a base: shows clan stats, vault contents, walls, monument, defenders
- Tapped a region: shows occupants list, terrain info, plot states (if applicable)
- Tapped bandit: shows tier, attack power, projected target, attempts remaining

### 2.3 The 8 demo moments → panel surfaces

| Moment | Surfaces |
|---|---|
| Clan spawn | World: new sprite walks onto map. HUD: leaderboard adds row. Ticker: `Cobalt clan has founded their homebase at East Farms` |
| Worker sent to gather | Speech bubble with LLM reasoning. World: travel animation. Ticker: mission entry |
| Resources become useful | World: wheelbarrow fill animation, deposit animation at base. Inspector: vault counter ticks up |
| Unicorn Town trade | World: trade swirl effect over Unicorn Town sprite. Market panel: price moves, sparkline updates. Ticker: trade entry |
| Bandits threaten | World: bandit camp sprite, red pulse on projected target base, attack countdown chip in HUD |
| Defense success/fail | World: combat flash, defender list overlay, loot drop pixels. Ticker: combat entry |
| Meaningful upgrade | World: building sprite animates one tier up. Leaderboard: re-sorts |
| Scoreboard pressure | Always-on: top HUD season/tick, leaderboard panel |

---

## 3. Two-Resolution View System

### 3.1 Why two atlases

Pixel art does not downscale gracefully. A 24×24 sprite at 0.33× scale becomes 8×8 of mush. Authoring a separate strategic atlas means the zoomed-out view stays legible.

### 3.2 View definitions

**World view (default)**
- Camera zoom range: 0.5× to 1.5× of base scale
- Atlas: `atlas_world.png` (8×8 clansmen, 16×16 buildings)
- Animation: none (or barely-perceptible 1-fps pulse for state hints — green pulse for gathering, red pulse for bandit-threatened)
- Pan: enabled but limited to map bounds
- Used for: 90% of the time, including the default video frame

**Detail view**
- Camera zoom range: 1.5× to 4×
- Atlas: `atlas_detail.png` (24×24 clansmen with full animations)
- Animation: full sprite cycles, environmental motion
- Pan: enabled
- Used for: tap-to-zoom, demo moments where motion matters

### 3.3 Transition

Camera state is `{x, y, zoom}`. When `zoom < 1.5` the world atlas renders; when `zoom >= 1.5` the detail atlas renders. At the transition, cross-fade both atlases over 200 ms.

Tap on world view → camera tweens to `{tappedX, tappedY, zoom: 2.0}` over 400 ms with `easeInOutQuad`. Pinch-out from detail view back below 1.5× → snaps back to world view.

The two atlases are loaded eagerly at startup. They're a few hundred KB each — small enough that lazy loading isn't worth the complexity.

---

## 4. Layout & Camera Model

### 4.1 World coordinate system

The map is laid out in **world units**, not pixels. World units are tick-agnostic and zoom-agnostic. A region polygon is defined once, in world units, and rendered at whatever pixel scale the camera dictates.

Map bounds: `0..1000` on X, `0..1600` on Y (portrait, taller than wide).

### 4.2 Region anchor positions (world units)

Reference layout from `clanworld_v4_spec.md` §1.3:

```
  Forest (1)              Mountains (2)
       \                       /
            Unicorn Town (3)
       /                       \
  W. Farms (4)            E. Farms (5)
       |                       |
  W. Docks (6)            E. Docks (7)
       \                       /
            Deep Sea (8)
```

**Region anchor coordinates** (center of each region, in world units):

| ID | Name | x | y |
|---|---|---|---|
| 1 | Forest | 250 | 200 |
| 2 | Mountains | 750 | 200 |
| 3 | Unicorn Town | 500 | 500 |
| 4 | West Farms | 250 | 800 |
| 5 | East Farms | 750 | 800 |
| 6 | West Docks | 250 | 1100 |
| 7 | East Docks | 750 | 1100 |
| 8 | Deep Sea | 500 | 1400 |

**Region polygons** (irregular, hand-drawn feel — not square tiles):

Each region is a 6–8 vertex polygon roughly centered on the anchor. Polygons should:
- Visually overlap slightly with adjacent regions for organic borders
- Have varied silhouettes (no two identical)
- Fit within ~250×250 world units bounding box around the anchor

The exact polygon vertices are an art decision; commit them to `src/world/regionPolygons.ts` once finalized.

### 4.3 Camera

```typescript
type Camera = {
  x: number;       // world coords of camera center
  y: number;       // world coords of camera center
  zoom: number;    // 0.5 .. 4.0
};

function worldToScreen(p: WorldPoint, camera: Camera, viewportSize: Size): ScreenPoint;
function screenToWorld(p: ScreenPoint, camera: Camera, viewportSize: Size): WorldPoint;
```

Both transforms are pure functions of camera + viewport. Use `@use-gesture/react` for pinch-zoom and two-finger pan; tap is a single-pointer gesture with no-drag detection.

### 4.4 Initial camera state

On app load: `{x: 500, y: 800, zoom: 0.7}` — fits the entire map in portrait viewport with margin for the HUD.

---

## 5. State Derivation Contract

This is the most important section in the document. Get it right and everything else is plumbing.

### 5.1 Principle

**Position is a function of state, never stored.**

Given a `WorldSnapshot` from Convex plus a `now` timestamp, a pure function returns a `ClansmanView` for every clansman, with screen-renderable position, animation key, and visual state.

The Pixi scene reads `ClansmanView[]` every frame and updates sprite positions, frames, and bubbles. It owns no game state of its own.

### 5.2 The view type

```typescript
type ClansmanView = {
  // identity
  clansmanId: number;
  clanId: number;
  clanColor: string;            // resolved hex from heraldic palette

  // status (derived from raw clansman state + active mission)
  status: 'WAITING' | 'TRAVELING' | 'GATHERING' | 'BUILDING' | 'DEPOSITING' | 'TRADING' | 'DEFENDING' | 'DEAD';

  // current world location
  region: number;               // 1..8
  worldPos: { x: number; y: number };  // in world units

  // travel-specific (only if status == 'TRAVELING')
  fromRegion?: number;
  toRegion?: number;
  pathRegions?: number[];       // canonical route, e.g. [6, 4, 3, 2]
  travelProgress?: number;      // 0..1 along entire path
  currentLegIndex?: number;     // which segment of the path
  currentLegProgress?: number;  // 0..1 within current leg

  // gathering / acting
  action?: ActionType;          // matches contract enum
  carry: ResourceCarry;
  carryCaps: ResourceCarry;
  wheelbarrowFillRatio: number; // 0..1, max across all carried types

  // defending
  defendingBaseId?: number;
  defendingClanId?: number;

  // visual / animation
  spriteKey: string;            // e.g. 'clansman_walk', 'clansman_mine'
  animationFrame: number;       // 0..N-1, derived from now and spriteKey
  facingDirection: 'left' | 'right';

  // speech bubble (most recent reasoning, fades after 8s)
  speechBubble?: { text: string; createdAt: number };
};

type ResourceCarry = { wood: number; iron: number; wheat: number; fish: number };
```

### 5.3 The derivation function signature

```typescript
function deriveClansmanView(args: {
  clansmanFullView: ClansmanFullView;     // from getClanFullView via Convex
  clan: ClanFullView;                     // parent clan's full view
  routeTable: RouteTable;                 // static, loaded at startup
  regionAnchors: Map<number, WorldPoint>; // static, from §4.2
  worldSnapshot: WorldSnapshot;           // for currentTick
  now: number;                            // performance.now() in ms
  tickEpoch: { tick: number; atMs: number; durationMs: number };
  recentReasoning?: { text: string; createdAt: number };
}): ClansmanView;
```

`tickEpoch` answers "what wall-clock time was the most recent tick advance?" It comes from the Convex `worldSnapshot.currentTick` field plus a `tickAdvancedAt` timestamp Convex records. The duration is the configured tick duration (15–20 seconds for the demo).

### 5.4 Position derivation rules

#### 5.4.1 Mapping contract `ClansmanState` → UI `status`

The contract has only 4 states: `WAITING | TRAVELING | ACTING | DEAD`. The UI splits `ACTING` into 5 visual statuses based on the active mission's action. The derivation function applies this mapping first, then computes position.

| Contract state | Mission action | UI `status` |
|---|---|---|
| `TRAVELING` | (any) | `'TRAVELING'` |
| `ACTING` | `ChopWood`, `MineIron`, `FishDocks`, `FishDeepSea`, `HarvestWheat` | `'GATHERING'` |
| `ACTING` | `BuildWall`, `UpgradeBase`, `UpgradeMonument` | `'BUILDING'` |
| `ACTING` | `DepositResources` | `'DEPOSITING'` |
| `ACTING` | `MarketBuy`, `MarketSell` | `'TRADING'` |
| `ACTING` | `DefendBase` | `'DEFENDING'` |
| `WAITING` | (any or none) | `'WAITING'` |
| `DEAD` | (any) | `'DEAD'` |

The `effectiveRegion` field on `DerivedClansmanState` tells you the worker's current region for the TRAVELING case (the contract derives this onchain from the route + elapsed ticks). For all other states, just use `clansman.currentRegion`.

#### 5.4.2 Position rules per UI status

**WAITING**
- Worker is at `clansman.currentRegion`. Position is a deterministic wander inside that region:
  ```
  seed = hash(clansmanId, floor(now / 5000))
  offset = seededOffset(seed) within region polygon
  worldPos = regionAnchor + offset
  ```
- Same input → same output → no jitter on re-render. Wander shifts every 5 seconds.

**TRAVELING**
- Compute global travel progress:
  ```
  ticksElapsed = currentTick - mission.startTick + (now - tickEpoch.atMs) / tickEpoch.durationMs
  totalTravelTicks = mission.arrivalTick - mission.startTick
  travelProgress = clamp(ticksElapsed / totalTravelTicks, 0, 1)
  ```
- Map progress to the canonical path. Each leg is 1 tick:
  ```
  legCount = pathRegions.length - 1
  rawLeg = travelProgress * legCount
  currentLegIndex = floor(rawLeg)
  currentLegProgress = rawLeg - currentLegIndex
  ```
- Interpolate position:
  ```
  fromAnchor = regionAnchors.get(pathRegions[currentLegIndex])
  toAnchor = regionAnchors.get(pathRegions[currentLegIndex + 1])
  worldPos = lerp(fromAnchor, toAnchor, easeInOutSine(currentLegProgress))
  ```

**GATHERING / BUILDING / DEPOSITING / TRADING / DEFENDING**
- Worker is in `clansman.currentRegion`. Use the same wander as WAITING but with a slower offset shift (20 sec instead of 5) so they look anchored.
- For DEFENDING, anchor near the defended base position with a small jitter offset.

**DEAD**
- Sprite hidden. View is still emitted so subscribers can show a tombstone if desired.

### 5.5 Animation key derivation

```typescript
function deriveSpriteKey(view: ClansmanView): string {
  switch (view.status) {
    case 'TRAVELING':  return 'clansman_walk';
    case 'GATHERING':
      switch (view.action) {
        case 'ChopWood':     return 'clansman_chop';
        case 'MineIron':     return 'clansman_mine';
        case 'FishDocks':
        case 'FishDeepSea':  return 'clansman_fish';
        case 'HarvestWheat': return 'clansman_harvest';
      }
    case 'BUILDING':   return 'clansman_build';
    case 'DEPOSITING': return 'clansman_deposit';
    case 'TRADING':    return 'clansman_trade';
    case 'DEFENDING':  return 'clansman_defend';
    case 'WAITING':    return 'clansman_idle';
    case 'DEAD':       return 'clansman_dead';
  }
}
```

Animation frame index advances on its own clock independent of mission timing:
```typescript
animationFrame = floor(now / 1000 * spriteKeyFps[spriteKey]) % spriteKeyFrameCount[spriteKey]
```

### 5.6 Wheelbarrow fill ratio

```typescript
wheelbarrowFillRatio = max(
  carry.wood / carryCaps.wood,
  carry.iron / carryCaps.iron,
  carry.wheat / carryCaps.wheat,
  carry.fish / carryCaps.fish,
)
```

Used to drive a small visual indicator above the sprite (a thin bar or a wheelbarrow icon that fills).

### 5.7 Determinism guarantees

The derivation function is **pure**. Same inputs → same outputs. This matters because:

- Hot reload doesn't lose state
- Tests are trivial (snapshot input → snapshot output)
- Multiple subscribers can re-derive without coordination
- Refresh in the middle of a session shows the same scene

`now` is the only "moving" input, and only affects animation frame index and intra-region wander. Game-truth fields (region, status, action) are stable across calls within a single tick.

---

## 6. Sprite & Animation System

### 6.1 Atlas structure

Both atlases are organized as JSON-described sprite sheets exported from Aseprite.

```
atlas_world.json    — frame index, all single-frame
atlas_world.png     — 256×256 max
atlas_detail.json   — frame index with animation tags
atlas_detail.png    — 1024×1024 max
```

Aseprite export config: PNG + JSON-Hash, 1× scale (Pixi handles upscaling), trim enabled, padding 1 px.

### 6.2 Sprite categories

**`atlas_world.png`** (strategic, 8×8 / 16×16):
- `world_clansman_<color>` — one per clan color (8 variants)
- `world_base_lvl1..5` — base building strategic icon
- `world_wall_lvl1..5` — wall decoration around base
- `world_monument_lvl0..10` — monument tower at strategic scale
- `world_bandit` — single sprite
- `world_terrain_<region>_accent` — small terrain decoration per region

**`atlas_detail.png`** (24×24 / 32×32 / 48×48 / variable):
- `clansman_idle_<color>` — 4 frames
- `clansman_walk_<color>` — 4 frames, has left/right facing
- `clansman_chop_<color>` — 4 frames
- `clansman_mine_<color>` — 4 frames
- `clansman_fish_<color>` — 4 frames
- `clansman_harvest_<color>` — 4 frames
- `clansman_build_<color>` — 4 frames
- `clansman_deposit_<color>` — 4 frames
- `clansman_trade_<color>` — 4 frames
- `clansman_defend_<color>` — 4 frames (shield raise)
- `clansman_dead_<color>` — 1 frame
- `base_lvl1..5_<color>` — building, color reflects clan banner
- `wall_lvl1..5_<color>` — wall segments
- `monument_lvl0..10` — monument tower
- `bandit_idle` — 4 frames
- `bandit_attack` — 4 frames
- `bandit_camp` — 4 frames with flickering campfire
- `terrain_<region>_<feature>` — environmental motion (smoke, wave, wheat sway, mill turn)
- `effect_combat_flash` — 6 frames
- `effect_pixel_burst` — 4 frames (used for trades, deposits, blueprint awards)
- `effect_red_pulse` — 4 frames (bandit threat ring)

### 6.3 Speech bubbles

Speech bubbles are rendered as Pixi containers above clansman sprites. Each bubble has:
- 1–3 line text capacity, ~80 char total
- Pixel-art outline matching `ink` color
- Tail pointing down to the sprite
- Auto-fade after 8 seconds (alpha tween from 1.0 to 0)
- Source text comes from `agentLogs` Convex query. The agent runner sets `triggeringClansmanId` on each log; if set, the bubble appears over that clansman. If unset (e.g., for `do_nothing` or `send_whisper` decisions), the bubble appears over the clan flag at the homebase. See agent runner spec §7.1 for the attribution rules.

### 6.4 Performance budget

For the v1 realm size (~8 clans × 5 clansmen = 40 sprites):
- World view: 40 strategic sprites + 8 buildings + 8 region accents + maybe 1 bandit ≈ 60 sprites, all static
- Detail view: ~40 animated sprites + buildings + ambient motion ≈ 80 sprites with animation

Pixi v8 batches all this trivially. Target 60 fps on iPhone 12-era hardware, 30 fps minimum on 2020-era Android.

**Plan B if profiling shows perf issues on demo hardware:**
- Set `pixiApp.ticker.maxFPS = 30` in `pixiApp.ts`
- Confirm `cullable: true` on all `Container` instances containing offscreen sprites (Pixi v8 default, but verify)
- Reduce sprite animation rates from 6 fps to 4 fps
- Disable detail-view ambient motion sprites (smoke, waves, wheat sway)
- Last resort: reduce strategic atlas usage (always render detail atlas, just smaller — known to look worse, but unblocks)

---

## 7. Convex Query Contract

This section is **the seam between frontend and backend**. The frontend declares what queries it needs and what shape they return. The backend implements them.

### 7.1 Tick metadata

Convex maintains a single document keyed by `worldId` recording:
```typescript
type TickEpoch = {
  worldId: string;
  currentTick: number;
  tickAdvancedAt: number;       // unix ms, set when heartbeat tx confirms
  configuredTickDurationMs: number; // demo: 20000
};
```

### 7.2 Required queries

```typescript
// Top-level world snapshot for HUD chrome.
api.world.getSnapshot(): WorldSnapshot & { tickEpoch: TickEpoch };

// All clans, fully derived. Drives the entire sprite layer.
api.world.getAllClanViews(): ClanFullView[];

// Active bandit including projected target. Drives bandit drama.
api.world.getActiveBandit(): ActiveBanditView;

// Market panel data: 4 pool reserves + scheduled queues + spot prices.
api.market.getState(): MarketState;

// Per-resource price history for sparklines. Most recent N tick samples.
api.market.getPriceHistory(args: { resource: 'wood' | 'iron' | 'wheat' | 'fish'; ticks: number }):
  Array<{ tick: number; spotPrice: number }>;

// Recent world events for the ticker. Ordered most recent first.
api.events.getRecent(args: { limit: number }): EventLogEntry[];

// LLM reasoning excerpts. Used for speech bubbles + chat panel.
api.agents.getRecentLogs(args: { clanId?: number; limit: number }):
  Array<{ clanId: number; tick: number; reasoning: string; createdAt: number }>;

// Inter-agent whispers. Public broadcast and 1-to-1.
api.whispers.getRecent(args: { limit: number }):
  Array<{ fromClanId: number; toClanId: number | null; tick: number; body: string; createdAt: number }>;
```

### 7.3 Subscription patterns

| Component | Subscribes to | Re-render trigger |
|---|---|---|
| Top HUD bar | `getSnapshot` | tick advance, winter, bandit |
| World canvas (sprite layer) | `getAllClanViews`, `getActiveBandit`, `getRecentLogs` | any clan state change |
| Event ticker | `getRecent({limit: 20})` | any new event |
| Leaderboard tab | `getSnapshot` | tick advance, building events |
| Market tab | `getState`, `getPriceHistory` x4 | any market trade, tick advance |
| Chat tab | `getRecent`, `getRecentLogs` | new whisper or log |
| Inspector tab | one of the above scoped to selection | depends on selection |

Convex's reactive query system handles invalidation automatically — components just re-render when the underlying tables change. We don't manage that.

### 7.4 EventLogEntry shape

```typescript
type EventLogEntry =
  | { kind: 'mission_assigned'; tick: number; clanId: number; clansmanId: number; action: ActionType; toRegion: number; createdAt: number }
  | { kind: 'mission_completed'; tick: number; clanId: number; clansmanId: number; action: ActionType; createdAt: number }
  | { kind: 'order_rejected'; tick: number; clanId: number; clansmanId: number; action: ActionType; reason: string; createdAt: number }
  | { kind: 'resources_deposited'; tick: number; clanId: number; resources: ResourceCarry; createdAt: number }
  | { kind: 'market_trade'; tick: number; clanId: number; resource: string; amountIn: number; amountOut: number; direction: 'buy' | 'sell'; createdAt: number }
  | { kind: 'building_upgraded'; tick: number; clanId: number; building: 'wall' | 'base' | 'monument'; newLevel: number; createdAt: number }
  | { kind: 'bandit_spawned'; tick: number; region: number; tier: number; createdAt: number }
  | { kind: 'bandit_attack'; tick: number; targetClanId: number; defended: boolean; createdAt: number }
  | { kind: 'blueprint_awarded'; tick: number; clanId: number; amount: number; createdAt: number }
  | { kind: 'clan_spawned'; tick: number; clanId: number; createdAt: number }
  | { kind: 'clan_eliminated'; tick: number; clanId: number; createdAt: number }
  | { kind: 'otc_transfer'; tick: number; fromClanId: number; toClanId: number; gold?: number; blueprint?: number; resources?: ResourceCarry; createdAt: number }
  | { kind: 'season_finalized'; tick: number; rankedClanIds: number[]; createdAt: number };
```

The frontend formats each event kind into a ticker line with appropriate color and clan banner.

**Note:** Whispers are NOT events — they have their own table and their own query (`api.whispers.getRecent`). Earlier drafts mistakenly included them here. The Chat tab subscribes to whispers separately.

---

## 8. Tech Stack & Dependencies

```jsonc
{
  "dependencies": {
    "react": "^19.x",
    "react-dom": "^19.x",
    "convex": "^1.x",
    "pixi.js": "^8.x",
    "@pixi/assets": "^8.x",
    "@use-gesture/react": "^10.x",
    "zustand": "^5.x",
    "viem": "^2.x",
    "abitype": "^1.x",
    "tailwindcss": "^3.x"
  },
  "devDependencies": {
    "vite": "^6.x",
    "@vitejs/plugin-react": "^4.x",
    "typescript": "^5.x"
  }
}
```

**Conventions:**
- TypeScript strict mode on
- No CSS modules; Tailwind classes for chrome, no styles for the canvas
- No state management library beyond Zustand and Convex's reactive queries
- No animation library — Pixi handles all motion

---

## 9. File Structure

```
src/
  main.tsx                      ← Vite entry, mounts <App />
  App.tsx                       ← top-level layout, routes nothing (single screen)
  
  contracts/
    abi/
      IClanWorld.json           ← compiled ABI, source of truth for types
    types.ts                    ← re-exports viem-derived types
  
  convex/                       ← Convex generated client (managed by Convex)
    _generated/
    api.ts
  
  hooks/
    useWorldSnapshot.ts         ← wraps Convex query
    useAllClanViews.ts
    useActiveBandit.ts
    useMarketState.ts
    usePriceHistory.ts
    useEvents.ts
    useAgentLogs.ts
    useWhispers.ts
    useClansmanViews.ts         ← composes derivation function over getAllClanViews
  
  store/
    cameraStore.ts              ← Zustand: camera position, zoom
    selectionStore.ts           ← Zustand: tapped entity for inspector
    uiStore.ts                  ← Zustand: which drawer is open, modals
  
  world/
    regionPolygons.ts           ← static polygon data
    regionAnchors.ts            ← static anchor coordinates
    routeTable.ts               ← canonical paths, mirrors contract
    deriveClansmanView.ts       ← THE PURE FUNCTION
    palette.ts                  ← all color tokens
  
  pixi/
    PixiStage.tsx               ← React component that mounts the canvas
    pixiApp.ts                  ← Pixi.Application instance, lifecycle
    layers/
      worldLayer.ts             ← strategic atlas renderer
      detailLayer.ts            ← detailed atlas renderer
      hudOverlayLayer.ts        ← speech bubbles, region tap zones
    sprites/
      atlasLoader.ts
      clansmanSprite.ts
      buildingSprite.ts
      banditSprite.ts
      effectSprite.ts
    camera/
      Camera.ts
      worldToScreen.ts
      gestureBindings.ts        ← @use-gesture/react integration
    bridge.ts                   ← subscribes to Zustand + Convex, drives Pixi
  
  hud/
    TopBar.tsx
    EventTicker.tsx
    TabBar.tsx
    drawers/
      LeaderboardDrawer.tsx
      MarketDrawer.tsx
      ChatDrawer.tsx
      InspectorDrawer.tsx
    components/
      ClanBanner.tsx
      ResourceCounter.tsx
      Sparkline.tsx
      MonumentStack.tsx
      CountdownChip.tsx
  
  mocks/
    mockSnapshot.ts             ← believable hard-coded WorldSnapshot
    mockClanViews.ts
    mockEvents.ts
    mockAgentLogs.ts
  
  index.css                     ← Tailwind imports, font imports, body resets

public/
  atlas_world.png
  atlas_world.json
  atlas_detail.png
  atlas_detail.json
```

**Frontend mocks vs backend mock mode.** `src/mocks/` is for M1 local development before backend mock mode is up — purely in-memory test data. Once backend M2 is live (`MOCK_MODE=true` Convex deployment), the frontend connects to Convex like normal and the local mocks become reference fixtures only (used by unit tests of `deriveClansmanView`). They are not redundant — they serve different milestones.

The `bridge.ts` is the single point where React/Convex/Zustand state is pushed into the Pixi scene. It subscribes once at mount, calls `deriveClansmanView` for each clansman every animation frame, and updates Pixi sprite positions. **No React component should ever import from `pixi/`.**

---

## 10. Build Milestones

The frontend stream targets these milestones. Hour estimates assume one focused builder.

### M1: Static world (2 hours)
- Vite scaffold with React, TS, Tailwind, Pixi, Zustand, @use-gesture/react
- `regionPolygons.ts` and `regionAnchors.ts` populated from §4.2
- Pixi canvas mounted, draws all 8 region polygons with placeholder fills
- Camera with pinch-to-zoom and pan working
- Two-resolution transition working with placeholder sprite (just colored squares)

### M2: Mock snapshot, sprites moving (3 hours)
- `mockSnapshot.ts` returns a believable mid-game `WorldSnapshot` + `ClanFullView[]` matching the contract types
- `deriveClansmanView` implemented per §5
- Pixi bridge subscribes to mock store, renders 60 placeholder sprites moving correctly
- Travel interpolation visibly works (sprite walks between two regions over the configured tick duration)
- Wander works (idle sprites drift slightly)

### M3: HUD chrome and one drawer (2 hours)
- TopBar with tick clock, season bar, winter and bandit chips
- EventTicker scrolling with mocked events
- TabBar with all four tabs present
- Leaderboard drawer fully functional reading from mock

### M4: Real sprites, real atlases (4 hours)
- Aseprite atlases imported (placeholder art if no artist yet — colored shapes are fine for MVP)
- Sprite key derivation per §5.5 working
- Animation frame advance per §1.5 working
- Speech bubbles rendering and fading

### M5: Convex wiring (2 hours)
- Replace mock store with Convex queries
- Verify all subscriptions trigger correct re-renders
- End-to-end test: change a Convex doc → see UI react

### M6: Demo polish (4+ hours)
- All four drawers functional
- All 8 demo moments verified to surface clearly
- Color/contrast pass on phone hardware
- Recording rehearsal

**Total: ~17 hours of focused frontend work.** Compresses to 2 calendar days with one builder, 1 day with two builders working different milestones.

### M1 starts immediately. M5 unblocks once Convex backend exposes the queries from §7. Everything else is pre-Convex-able.

---

## 11. Open Questions Routed to Other Streams

These need answers from other workstreams before final implementation:

**To contract team:**
- Confirm `getMarketState().spotPriceGoldPerResource` is computed onchain. If not, frontend computes from reserves (cheap, fine).
- Confirm event ordering — if two events fire in the same block, what's the deterministic order? Affects ticker display.

**To Convex backend team:**
- Tick advance timestamp handling: when does Convex consider a tick to have advanced? On the `TickAdvanced` event being indexed, or on a wall-clock heuristic?
- Price history retention: keep how many ticks? Recommend 360 (full season) since each sample is tiny.
- Agent log retention: keep how many per clan? Recommend 50 per clan.

**To agent runner team:**
- What's the maximum length of an LLM reasoning excerpt that gets surfaced as a speech bubble? **Locked at 240 chars** (matches `agents.postLog` mutation cap and agent runner config `reasoningCharCap`).
- When does an agent's reasoning get attributed to a specific clansman vs. the clan as a whole? Clan-level reasoning still shows as a speech bubble — over which clansman? **Locked: the first clansman in the missions array.** If `do_nothing` or `send_whisper` is called (no missions array), the bubble appears over the clan flag at the homebase.

**To art workstream:**
- Atlas delivery format: Aseprite source files in `art/`, exported PNGs and JSONs in `public/`.
- Color palette adherence: clan and region colors are committed in §1.2. Artists must use exactly these hex values for clan-specific assets.

---

## 12. Out of Scope for v1

Cut explicitly. Do not implement:

- Sound effects and music
- Sound options menu
- Settings overlay
- Onboarding tutorial
- Account auth / wallet connection (demo runs with hardcoded agents)
- OTC asset transfer UI (whispers chat is sufficient)
- Winter visual treatment (snow overlay, etc.) — leave HUD indicator only
- Custom region polygon editor
- Replay scrubbing
- Achievements / quests
- Mobile haptics
- Accessibility audit (will be sad about this; do it post-hackathon)

When time pressure hits, also defer in this order:

1. Sparklines (replace with current-price-only)
2. Inspector tab (use a simple modal instead)
3. Speech bubble auto-fade (just leave them up)
4. Two-resolution sprite atlas (use one detail atlas, scale it down — known to look worse, but unblocks)
5. Pixel-art chrome ornaments (use solid color borders)

---

## 13. Definition of Done

The frontend is demo-ready when, on a real phone:

1. App loads in under 5 seconds on 4G
2. World canvas renders all 8 regions with terrain and clan homebases
3. Clansmen visibly move between regions in real time as missions resolve
4. Speech bubbles appear over clansmen with LLM reasoning text
5. Bandit warning surfaces when a bandit is camping, with visible target indication
6. Trade events update market spot prices and event ticker
7. Leaderboard reorders when monuments level up
8. All 8 demo moments from §2.3 are clearly recognizable to a first-time viewer

If those eight things are visible in a 3-minute screen recording, the frontend has done its job.
