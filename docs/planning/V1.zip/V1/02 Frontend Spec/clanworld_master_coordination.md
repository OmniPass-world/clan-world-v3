# ClanWorld — Master Coordination Doc

**Status:** Living doc, hackathon-scoped
**Purpose:** Single source for cross-team open questions, dependencies, and seam decisions.
**Audience:** All workstream leads.
**Update policy:** Cross items off as they're resolved. Add new items inline.

---

## 0. How to use this doc

This is the doc you check before pinging another team. Every cross-stream question that's blocking work goes here. Every dependency between streams goes here. If you're about to make a decision that affects another stream, write it here first and confirm.

Three sections:

- **§1 — Stream contracts.** What each stream owes the others, in artifact form.
- **§2 — Open questions.** Resolvable in one call. Each tagged with who needs to answer.
- **§3 — Dependency graph.** What blocks what.

---

## 1. Stream Contracts

The seam between streams is the artifact, not the conversation. Each stream owes specific deliverables to others. Once delivered, the receiver builds against the artifact and the producer doesn't get pulled back into discussion.

### 1.1 Contracts stream owes

| Owes to | Artifact | Status |
|---|---|---|
| All | `IClanWorld.sol` | ✅ delivered (`/IClanWorld.sol`, includes `OrderRejected` event per §6 decisions log) |
| All | Compiled ABI JSON | ⏳ on first compile |
| Backend | Deployed contract address (Base/World) | ⏳ on first deploy |
| Backend | Deployed token + pool addresses (4 resource/gold pools) | ⏳ on first deploy |
| Backend | RPC endpoint URLs (primary + fallback Alchemy, both at 1M/day) | ⏳ before backend M3 |
| All | Confirmation that no field names, struct layouts, or enum orderings have drifted from `IClanWorld.sol` | ⏳ on first compile |

### 1.2 Backend (Convex) stream owes

| Owes to | Artifact | Status |
|---|---|---|
| Frontend | Convex deployment URL | ⏳ on M1 deploy |
| Frontend | All 8 queries returning shapes that match frontend spec §7 | ⏳ on M1 |
| Frontend | `MOCK_MODE=true` deployment with `seedMockState` working | ⏳ on M2 — **unblocks frontend** |
| Frontend | `tickEpoch` shape decision (top-level vs nested in `getSnapshot`) | 🔴 blocking — see §2.1 |
| Agents | Convex client config (URL + any auth tokens) | ⏳ on M1 |
| Agents | `agents.postLog` and `whispers.post` mutations callable | ⏳ on M6 |

### 1.3 Frontend stream owes

| Owes to | Artifact | Status |
|---|---|---|
| Backend | Confirmed query signatures match Convex implementation | ⏳ end of M5 |
| Backend | Final list of which `eventLog.kind` values surface in the ticker | ⏳ end of M3 |
| Agents | Speech bubble char limit confirmation (current: 240) | ✅ aligned |
| Art workstream | Final region polygon vertices | ⏳ end of M1 |
| All | Demo recording rehearsal | ⏳ end of M6 |

### 1.4 Agent runner stream owes

| Owes to | Artifact | Status |
|---|---|---|
| Frontend | `triggeringClansmanId` semantics confirmation | ✅ locked: first clansman in the missions array; clan flag at homebase if no missions |
| Backend | Agent count (current: 4) | ✅ aligned |
| All | Demo-ready strategic alignments tested | ⏳ end of M5 |
| Ops | List of required env vars | ⏳ end of M1 |

### 1.5 Ops / Makefile stream owes

| Owes to | Artifact | Status |
|---|---|---|
| Contracts | Mnemonic generation script | ⏳ on first dry run |
| Contracts | Treasury wallet funded for deploy | ⏳ on first dry run |
| Agents | Per-agent funding script (~0.01 ETH each on Base) | ⏳ on first dry run |
| Agents | `clan-agent-mapping.json` generated and committed | ⏳ on `make spawn-clans` |
| Backend | Heartbeat caller wallet funded (~$1 of ETH) | ⏳ on first dry run |
| All | `make demo-reset` working end-to-end | ⏳ end of dry run #1 |

---

## 2. Open Questions

These are resolvable in one call. Each is tagged with [WHO ANSWERS] and [PRIORITY: 🔴 blocking / 🟡 soon / 🟢 nice-to-have].

### 2.1 ✅ [BACKEND + FRONTEND] `tickEpoch` shape — RESOLVED

Frontend spec §5.3 expects:
```ts
type TickEpoch = { tick: number; atMs: number; durationMs: number };
```
nested as `worldSnapshot.tickEpoch`.

Backend spec §4.2 stores a separate `tickEpoch` table with shape:
```ts
{ worldId, currentTick, tickAdvancedAt, configuredTickDurationMs }
```
and §7 returns it merged at the top level of `getSnapshot`.

**Resolution (2026-04-25):**
- Backend's `getSnapshot()` query returns `WorldSnapshot & { tickEpoch: { tick, atMs, durationMs } }`
- Backend's internal table keeps its own field names for clarity; the query handler renames them at read time:
  ```typescript
  return {
    ...snapshot.raw,
    tickEpoch: {
      tick: tickEpochRow.currentTick,
      atMs: tickEpochRow.tickAdvancedAt,
      durationMs: tickEpochRow.configuredTickDurationMs,
    },
  };
  ```
- This isolates external API surface from internal storage details.

### 2.2 🔴 [CONTRACTS] `TickAdvanced` event ordering

Backend spec §12 asks: when `heartbeat()` runs, does `TickAdvanced` fire **before** or **after** other tick-end side effects (bandit attacks, scheduled markets, winter transitions)?

This matters because the indexer uses `TickAdvanced` as the trigger to refetch all snapshot tables. If it fires first, snapshots will be re-fetched while side effects are still being written, and we'll see stale data for one tick.

**Decision needed:** confirm `TickAdvanced` is the **last** event emitted in `heartbeat()`. If not, the indexer adds a 200ms delay before state-poll.

### 2.3 🔴 [CONTRACTS] `heartbeat()` revert behavior

Agent runner spec §15 and backend spec §6 both depend on this:
- Does `heartbeat()` revert if called too early (before `nextHeartbeatAtTs`)?
- Or does it silently no-op?

**Decision needed:** confirm revert. The heartbeat caller catches reverts; silent no-op would mean we falsely log success.

### 2.4 🔴 [CONTRACTS] Deployed addresses

The backend can't index without the deployed contract address. Agents can't transact without it. The frontend doesn't need it directly but the seam mock relies on it to disambiguate test runs.

**Decision needed:** as soon as contracts are deployed to Base/World, post:
- ClanWorld contract address
- 6 token addresses (wood, iron, wheat, fish, gold, blueprint)
- 4 pool addresses (wood/gold, iron/gold, wheat/gold, fish/gold)
- Block number of deployment

### 2.5 🟡 [BACKEND + FRONTEND] Per-clan filter on `getRecentLogs`

Backend spec §11 questions whether the per-clan filter on `agents.getRecentLogs` is actually used. Adding it requires an index, which adds storage cost.

**Decision needed:** does the frontend use the per-clan filter for any panel?
- Frontend spec §2.2 (Inspector tab) suggests yes (filter to selected clan when inspecting)
- Frontend spec §2.2 (Chat tab) suggests no (global feed)

If yes → keep the index. If no → drop and simplify.

**Recommended:** keep the index. Inspector tab benefits, cost is trivial.

### 2.6 🟡 [BACKEND] Price history ordering

Agent runner observation rendering (spec §8.3) consumes `recent` as chronologically ordered (oldest → newest, so trend direction is "left to right increasing").

Backend spec §7 implementation queries `.order('desc').take(N)` then `.reverse()`. Confirms chronological order.

**Confirmation needed:** verified in implementation that the array order is correct.

### 2.7 🟡 [BACKEND] Mutation auth model

Backend spec §8 says no auth on `agents.postLog` and `whispers.post`. Agents are trusted in v1.

**Confirmation needed:** is this acceptable? The risk is anyone with the Convex deployment URL can spam the logs. For a 6-hour demo window, low risk.

**Recommended:** ship without auth. If demo prep window is longer than 24h, add a shared secret env var and reject unsigned mutations.

### 2.8 🟡 [CONTRACTS] Gas estimate for `submitClanOrders`

Agent runner spec §17 asks: what's the gas estimate for `submitClanOrders` with 5 missions? Need to fund agent wallets accordingly.

**Decision needed:** rough numbers. Based on Base's typical gas costs:
- 5-mission `submitClanOrders` likely ~150–300k gas
- At Base mainnet ~$0.001 per 100k gas = ~$0.003 per call
- 360 ticks × 1 call/tick × 4 agents = 1440 calls × $0.003 = ~$4.30 for full season
- Funding 0.005 ETH (~$15) per agent is comfortable margin

**Confirmation needed:** contract dev validates these estimates after compile.

### 2.9 ✅ [CONTRACTS] Order rejection observability — RESOLVED

Agent runner spec §17 asks: when an individual order in `submitClanOrders` is rejected (not the whole tx), is it observable from logs/events?

`submitClanOrders` returns `OrderResult[]` per the spec. Per-order rejections come back in the return value but transactions don't return values to event-listeners.

**Resolution (2026-04-25):** Added `OrderRejected(clanId, clansmanId, action, reason, atTick)` event to `IClanWorldEvents` in `IClanWorld.sol`. Contract emits per rejected order. Backend indexer maps to a new `eventLog.kind = 'order_rejected'` (also added to frontend EventLogEntry). UI surfaces these in the ticker as drama: "Mira tried to send Garrick to Mountains but cooldown was active."

### 2.10 🟡 [FRONTEND + AGENTS] Whisper visual treatment

Agent runner spec §17 asks whether public broadcasts and 1-to-1 whispers look distinct in the UI. Frontend spec §2.2 says yes (two sub-tabs: "Public Whispers" and "Inter-clan").

**Confirmation needed:** confirm visually distinct treatment. Recommended:
- Public broadcasts: full-width, megaphone icon, all-clan banner
- Inter-clan: indented, sender + recipient banner pair, lock icon
- LLM reasoning logs: italicized, dimmer, no banner pair

### 2.11 🟢 [FRONTEND] Region polygon authoring

Frontend spec §4.2 commits region anchor coordinates but flags polygon vertices as a follow-up art decision. They need to be locked before art workstream finalizes terrain.

**Decision needed:** who authors the polygons? Options:
- Frontend lead sketches in a vector tool, exports JS array
- Art lead authors in Aseprite map mode with explicit vertices
- Generate procedurally from anchors with seeded jitter

**Recommended:** frontend lead authors in 30 minutes in `regionPolygons.ts` using simple 6-vertex shapes. Art adapts terrain to fit. Faster than waiting on art.

### 2.12 🟢 [AGENTS] LLM provider primary choice

Agent runner spec §2 picks Anthropic Claude as primary, OpenAI as fallback. Both via the same `LLMClient` interface.

**Decision needed:** confirm Anthropic API key is available and the team has credits. Otherwise pivot to OpenAI from start.

**Recommended:** spend 5 min confirming both keys work before M1. The interface abstraction means switching takes minutes.

### 2.13 🟢 [ALL] Tick duration final value

Frontend spec, backend spec, and agent runner spec all reference `tickDurationMs` as configurable, defaulting to 20000 (20s).

**Decision needed:** lock the demo tick duration. Tradeoffs:
- 15s: tighter pacing, but agents may bump LLM latency ceiling
- 20s: comfortable agent budget, slower demo (but still sub-2-min for 5 ticks)
- 30s: too slow for video pacing

**Recommended:** 20s for development, drop to 15s on demo day if LLM proves fast enough. Make this a single env var (`TICK_DURATION_MS`).

### 2.14 🟢 [ALL] Demo length and recording strategy

Implicit assumption across all specs: 3-minute demo video, recorded from a 6-minute live session, accelerated through boring stretches.

**Decision needed:** confirm with hackathon judging criteria. Some hackathons require live demos. If live, the world tick must produce a watchable cadence in real time and we can't speed up.

**Recommended:** confirm format with hackathon organizers ASAP. If live demo, tighten tick to 15s and pre-script (via initial mission seeding) the first 30s of action so it's lively from frame one.

### 2.15 🟢 [ART] Atlas delivery format

Frontend spec §6.1 specifies Aseprite source files in `art/`, exported PNG + JSON in `public/`.

**Decision needed:** does the art workstream have Aseprite, and is everyone on board with this pipeline? Aseprite is paid software (~$20). Free alternatives (Piskel, GIMP) work but lack animation export.

**Recommended:** confirm tooling at art workstream kickoff. Cost is trivial; what matters is everyone exporting compatible JSON sprite sheets.

---

## 3. Dependency Graph

The critical-path graph for the hackathon. Each node is a milestone; arrows are blocking dependencies.

```
                  ┌──────────────────────────┐
                  │ S0: Seam (IClanWorld.sol)│  ◄── DONE
                  └──────────┬───────────────┘
                             │
        ┌────────────────────┼────────────────────┐
        ▼                    ▼                    ▼
┌───────────────┐    ┌──────────────┐    ┌──────────────┐
│ Contracts M1  │    │ Backend M1+2 │    │ Frontend M1+2│
│ (deploy stub) │    │ (mock mode)  │    │ (mock world) │
└──────┬────────┘    └──────┬───────┘    └──────┬───────┘
       │                    │                   │
       │                    └─────► unblocks ──►│
       │                                        │
       ▼                                        ▼
┌───────────────┐                     ┌──────────────────┐
│ Contracts M2  │                     │ Frontend M3+4    │
│ (full impl)   │                     │ (HUD, sprites)   │
└──────┬────────┘                     └──────┬───────────┘
       │                                     │
       └────────► unblocks ────►              │
                                              │
                  ┌─────────────────┐         │
                  │ Backend M3+4+5  │  ◄──────┘
                  │ (real indexer)  │
                  └────────┬────────┘
                           │
                  ┌────────▼─────────┐
                  │ Backend M6       │
                  │ (mutations live) │
                  └────────┬─────────┘
                           │
                  ┌────────▼─────────┐
                  │ Frontend M5      │
                  │ (Convex wired)   │
                  └────────┬─────────┘
                           │
                  ┌────────▼─────────┐    ┌──────────────┐
                  │ Agents M1+2      │ ◄──│ Backend M1+2 │
                  │ (single agent)   │    │ (any mock)   │
                  └────────┬─────────┘    └──────────────┘
                           │
                  ┌────────▼─────────┐
                  │ Agents M3-5      │
                  │ (multi + polish) │
                  └────────┬─────────┘
                           │
                  ┌────────▼─────────┐
                  │ Frontend M6      │
                  │ (demo polish)    │
                  └────────┬─────────┘
                           │
                  ┌────────▼─────────┐
                  │ Dry run + record │
                  └──────────────────┘
```

### Critical observations

**Backend M1+M2 is the most important early milestone.** It unblocks both the frontend (mock world) and the agents (mock world to test against). Until backend mock mode works, frontend and agents can build against in-memory mocks but can't integrate.

**Frontend M1+M2 can run fully parallel.** Vite scaffold, Pixi canvas, region polygons, mock data — all of this is independent of every other stream. Frontend lead should sprint on this immediately while waiting on Backend M2.

**Contracts M2 (full implementation) doesn't block backend or frontend.** Backend can mock; frontend reads from backend. Only the agent runner's *real* transactions are blocked by M2. Agent stream M1+M2 (single agent end-to-end against mock chain) doesn't need it either.

**The convergence point is Frontend M5 + Agents M2.** That's when the real chain, real backend, real UI, and real agents all light up together. Everything before is parallel; everything after is integration polish.

---

## 4. Suggested kickoff call agenda (30 min)

If you want to resolve remaining §2 questions in one call. Pre-resolved items are noted in §6.

1. **§2.2, §2.3** — contracts confirms `TickAdvanced` ordering and `heartbeat()` revert behavior (5 min)
2. **§2.4** — contracts deploy plan and address sharing (5 min)
3. **§2.5, §2.6, §2.7** — backend confirmations (5 min)
4. **§2.8** — contracts gas estimates (3 min)
5. **§2.10** — frontend visual treatment for whispers (3 min)
6. **§2.11** — frontend lead claims polygon authoring (2 min)
7. **§2.12, §2.13, §2.14, §2.15** — environment + format confirmations (5 min)
8. **§3 dependency graph review** — confirm everyone agrees the critical path is right (2 min)

After this call, every stream should be unblocked through their first three milestones.

---

## 5. Daily standup template

For the duration of the hackathon, each stream lead posts in a shared channel:

```
[STREAM] Day N standup
Yesterday: <what got done>
Today:     <what I'm working on>
Blocked:   <link to question in §2 of this doc, or new question>
Risk:      <anything unexpected>
```

Updates take 30 seconds to write, save hours of "where are we at?" pings.

---

## 6. Decisions log

Append-only. When a §2 question is resolved, move the resolution here with a date.

| Date | Question | Resolution |
|---|---|---|
| 2026-04-25 | (initial doc) | Coordination doc created |
| 2026-04-25 | §2.1 `tickEpoch` shape | Backend renames internal fields at query-time to match frontend's `{ tick, atMs, durationMs }` |
| 2026-04-25 | §2.9 Order rejection observability | Added `OrderRejected` event to seam; backend maps to `order_rejected` event kind; frontend renders in ticker |
| 2026-04-25 | §1 Spec review pass | EventLogEntry kinds aligned across frontend and backend; speech bubble cap locked at 240; clan color indexing fixed; contract→UI status mapping added; resource→token address resolution documented; mock mode expanded; RPC quota concerns dropped (2× Alchemy 1M/day); frontend mock vs backend mock mode relationship clarified |

---

## 7. Risk register

Top hackathon risks and mitigations.

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| Contract bug discovered late | Medium | High | Mock mode keeps frontend/agents independent; switch to mock for demo if needed |
| LLM rate limits during demo | Medium | High | Tested fallback to OpenAI; agent runs at 20s tick gives 12s budget per think |
| Alchemy quota exhausted | Very Low | Low | Two RPCs at 1M/day each = 2M total capacity; expected usage ~90k/day = 5% of quota. Rotate between RPCs for redundancy |
| Sprite art not done by demo | Medium | Medium | Placeholder colored shapes are acceptable; commit to "OK to ship ugly" by M4 |
| Live demo unsupported recording | Low | High | §2.14 — confirm format ASAP |
| Agent runner process crash | Low | Medium | `make start-agents` restarts; agents are stateless. **All agents share one process — blast radius is total**. Acceptable for hackathon. Post-hackathon: split into N processes for isolation |
| Onchain tx reverts cascading | Medium | Medium | Validation layer in agent runner catches most; revert is logged not fatal |
| Demo day env vars wrong | Medium | High | `make demo-reset` is the single command to set everything correctly |

---

## 8. Useful links

- Hackathon submission portal: TBD
- Shared chat channel: TBD
- Contracts repo: TBD
- Backend repo: TBD
- Frontend repo: TBD
- Agents repo: TBD
- Art repo: TBD
- Convex deployment dashboard: TBD
- Alchemy RPC dashboard: TBD
- Anthropic API dashboard: TBD
- Recording workspace: TBD

Fill in as repos go up. Pin this doc in the team chat.
