# ClanMemory — TypeScript API Spec

**Status:** Draft v0.4
**Scope:** The TypeScript library that wraps 0G Storage KV for the Elder toolbelt. KV only — the iNFT encrypted blob is `ClanIdentity`'s job.
**Companion docs:** `clanworld_0g_battleplan_and_spec.md`, `clanworld_clan_identity_spec.md`, `clanworld_inft_deployment_notes.md`
**Audience:** Whoever implements the toolbelt CLI and the orchestrator's KV plumbing.

---

## 1. Purpose

`ClanMemory` is the single TypeScript module that wraps all reads and writes against 0G Storage KV for Clanworld. Every other piece of the system (the `elder mem` CLI, `elder act`'s attestation writes, `elder say bulletin`, the AXL bridge sidecar, the orchestrator's situation-pump) goes through it.

It exists to:

- centralize 0G Storage KV SDK usage in one place
- enforce namespace boundaries at the library layer (defense-in-depth alongside CLI-layer enforcement)
- handle signing, retries, and error normalization
- make the access-control TBD (battle plan §11 #9) swappable behind a stable interface

It is **not**:

- a cache or persistence layer beyond what 0G KV provides
- a higher-level "memory consolidation" or "summarization" thing — agents do that themselves in their notebooks
- aware of the encrypted iNFT blob — that's `ClanIdentity`'s job (see `clanworld_clan_identity_spec.md`)

---

## 2. Module shape

Single class, instantiated once per process with a config object.

```typescript
import { ClanMemory } from "@clanworld/clan-memory";
import { Wallet } from "ethers";

const signer = new Wallet(process.env.AGENT_WALLET_KEY!);  // construct once, never log

const mem = new ClanMemory({
  clanId: 7,                         // own clanId — drives namespace boundary
  signer,                            // ethers Signer (not raw key)
  zgRpcUrl: process.env.ZG_RPC_URL!,
  zgKvNodeUrl: process.env.ZG_KV_NODE_URL!,
  zgKvStreamId: ZG_KV_CLANWORLD_STREAM_ID,
  authStrategy: new NativeSignedWriteStrategy({ signer, zgKvNodeUrl }),
  // optional
  retryConfig: { maxAttempts: 3, baseDelayMs: 200 },
  logger: console,                   // see Logger interface below
});

await mem.write("clan:7:notebook/strategy", { focus: "wood gathering" });
```

### Config field reference

| Field | Type | Required | Purpose |
|---|---|---|---|
| `clanId` | `number` | yes | Own clanId; drives namespace boundary; locked at construction |
| `signer` | `ethers.Signer` | yes | Agent wallet signer; used by auth strategy for signing writes; library never inspects the underlying key |
| `zgRpcUrl` | `string` | yes | 0G chain RPC for any chain-side validation the auth strategy needs |
| `zgKvNodeUrl` | `string` | yes | 0G Storage KV node endpoint |
| `zgKvStreamId` | `string` (or 0G-specific type) | yes | The "stream" (namespace/topic concept in 0G KV) under which all Clanworld keys live; one stream id shared by the whole realm. TBD: exact format pending 0G SDK docs |
| `authStrategy` | `KvAuthStrategy` | yes | Pluggable write-auth mechanism; see §7 |
| `retryConfig` | `{ maxAttempts: number; baseDelayMs: number }` | no | Defaults to `{ maxAttempts: 3, baseDelayMs: 200 }` |
| `logger` | `Logger` | no | Defaults to a no-op logger |

### Why `Signer` and not raw key

The library never sees raw private key bytes. The caller (CLI script or orchestrator) constructs an `ethers.Signer` (or anything matching the interface) from its env var, then passes the signer object. This:

- Prevents accidental logging of secret material (the library can't `console.log(config)` and leak the key)
- Lets the caller use hardware wallets, KMS, or other signing backends if desired
- Cleanly separates "who can sign" from "what gets signed"

### Logger interface

```typescript
interface Logger {
  info(msg: string, meta?: Record<string, unknown>): void;
  warn(msg: string, meta?: Record<string, unknown>): void;
  error(msg: string, meta?: Record<string, unknown>): void;
}
```

`console` matches this shape (loosely). Production should use `pino` or `winston`. The library never logs the signer or any value content — only key names and operation metadata.

### What `clanId` locks

The `clanId` field locks the instance to one identity. The library refuses writes outside that clan's writable namespaces (see §4 access matrix), even if the caller asks. This is enforced at every method.

The signer is the **agent wallet**, not the owner wallet (per battle plan §9). It's used to sign 0G KV writes via the auth strategy and to authenticate as the agent identity.

---

## 3. Public API

All public methods that touch KV are async. The constructor is sync. Methods that touch KV throw on transport errors and return `null` on logical "key not found" — they never throw NotFound.

### Value serialization contract (applies to all reads/writes)

**Always JSON-encoded on write, always JSON-decoded on read.** No magic format detection.

- Writes: every value is `JSON.stringify`'d before storage
- Reads: every value is `JSON.parse`'d before return
- Strings, numbers, booleans, objects, arrays, and null all round-trip cleanly through this
- Values must be JSON-serializable; non-serializable values (functions, circular refs, BigInt without explicit handling) throw `ClanMemoryValueError`
- A value written as the string `"42"` reads back as the string `"42"` (because `JSON.stringify("42") = '"42"'` and `JSON.parse('"42"') = "42"`). No type confusion.

### 3.1 Reads

```typescript
async read<T = unknown>(key: string): Promise<T | null>
```
Reads a single key. Returns `null` if not present. Decodes via `JSON.parse`. The generic type is a hint, not enforced — caller is responsible for shape validation.

```typescript
async list(prefix: string): Promise<string[]>
```
Lists keys matching the prefix. Returns full key names (not values). Order is unspecified — caller sorts if needed.

```typescript
async multiRead<T = unknown>(keys: string[]): Promise<Array<T | null>>
```
Batch read. Same per-element semantics as `read`. Result order matches input order even if the SDK returns asynchronously (the library re-sorts internally). Used by the orchestrator's situation-pump to fetch many bulletins in one network round-trip.

```typescript
async readAll<T = unknown>(prefix: string): Promise<Map<string, T>>
```
Convenience: `list(prefix)` followed by `multiRead`, returned as a map keyed by full key name. Skips entries that returned `null` between the list and the read (rare race; key was deleted in between). Used by the boot/reset flow to load `clan:{N}:notebook/*` in one call.

**`multiRead` vs `readAll`:** use `multiRead` when you have an explicit list of keys (e.g., the agent knows it wants exactly `notebook/strategy`, `notebook/grudges/3`, `notebook/grudges/5`). Use `readAll` when you have a prefix and want everything under it (e.g., load the whole notebook at boot). Internally `readAll` is `list` + `multiRead`.

```typescript
async exists(key: string): Promise<boolean>
```
Sugar for `(await read(key)) !== null`. Same network cost as `read`. Use only for readability when the value isn't needed.

### 3.2 Writes

```typescript
async write(key: string, value: unknown): Promise<void>
```
Writes a key. Value is JSON-stringified. Throws `ClanMemoryAccessError` if the key is outside the writable namespace for this instance. Throws `ClanMemoryValueError` if the value isn't JSON-serializable. Throws `ClanMemoryTransportError` on network/SDK failures (after retry budget exhausts).

```typescript
async delete(key: string): Promise<boolean>
```
Deletes a key. Same access rules as `write`. Returns `true` if a key was deleted, `false` if it didn't exist (no-op, does not throw).

```typescript
async writeMany(entries: Array<{ key: string; value: unknown }>): Promise<WriteManyResult>
```
Best-effort sequential batch write. **No atomicity guarantee** — 0G KV does not support transactional batches at the protocol level, so partial state is possible if a failure occurs mid-batch.

Result type:

```typescript
interface WriteManyResult {
  successful: string[];                                      // keys that wrote
  failed: Array<{ key: string; error: Error }>;              // keys that didn't
}
```

The library writes entries in input order. On a failure, it stops and returns what succeeded plus what failed. The caller decides whether to retry, ignore, or abort. Use `write` in a loop if you want full control over per-entry retry behavior.

### 3.3 Subscriptions (optional, see §7)

```typescript
async watch(prefix: string, callback: (key: string, value: unknown) => void): Promise<() => void>
```
Subscribe to **new keys appearing under prefix.** Returns an unsubscribe function. Used by the orchestrator's AXL bridge to react when its own AXL bridge writes a new whisper index entry.

**Semantic limitation — read carefully.** This API is for *new keys appearing*, not *value changes on existing keys*. If 0G KV doesn't support push subscriptions in v1, the library falls back to polling at a configurable interval (default 2s), and polling cannot detect rapid value changes — only the current value at poll time is observed.

Concretely:
- ✅ Use for: detecting that `inbox:{N}:whisper_index/{senderId}/{tick}` is now present (new key)
- ❌ Do not use for: detecting that the *value* at `clan:{N}:last_turn_tick` changed from 411 to 412 to 413; polling would only see the latest, missing 412

For value-change watching, poll explicitly on a known cadence and compare prior/current values yourself.

The watch lifecycle has its own retry/reconnect logic separate from `retryConfig` (which applies to one-shot read/write operations). Errors during a watch (transient connection drops, polling failures) are handled internally with backoff and reconnect; they are not surfaced to the user callback. If the watch hits a permanent failure (e.g., auth revoked), the library logs a warning and the callback simply stops being called — caller must monitor watch health out-of-band if it matters.

### 3.4 Lifecycle

```typescript
async close(): Promise<void>
```
Cleans up active watches and any internal connections. Call before process shutdown to avoid leaking subscriptions. Idempotent — calling twice is a no-op. After `close`, all subsequent method calls throw `ClanMemoryAccessError` with a "closed" reason.

For hackathon: not strictly required if processes exit cleanly. Required for long-running orchestrators that may need to recreate ClanMemory instances (e.g., on owner change).

---

## 4. Namespace enforcement

The library is the second line of defense after the CLI argument parser. CLI tools enforce at the syntax level (you can't `elder mem write` to a non-`clan:{ownClanId}` key). The library enforces at the API level (even if a caller bypasses the CLI, it can't write outside its namespace).

### Access matrix

For an instance with `clanId = N`:

| Key prefix | Read | Write | Delete |
|---|---|---|---|
| `clan:{N}:*` | ✅ | ✅ | ✅ |
| `clan:{otherId}:*` | ❌ | ❌ | ❌ |
| `realm:townsquare:bulletin:{N}:*` | ✅ | ✅ | ✅ |
| `realm:townsquare:bulletin:{otherId}:*` | ✅ | ❌ | ❌ |
| `realm:townsquare:index:{N}` | ✅ | ✅ | ✅ |
| `realm:townsquare:index:{otherId}` | ✅ | ❌ | ❌ |
| `realm:*` (any other prefix) | ✅ | ❌ | ❌ |
| `inbox:{N}:*` | ✅ | ✅ | ✅ |
| `inbox:{otherId}:*` | ❌ | ❌ | ❌ |

### Why `inbox:{N}:*` is writable

Per battle plan §7 and §8, the recipient's own orchestrator writes to its inbox after polling AXL. The orchestrator's ClanMemory instance is configured with the recipient's `clanId`, so writes to `inbox:{N}:*` are within-namespace from its perspective. A different clan's orchestrator can never write here because its instance has a different `clanId` lock.

### Why other clans' bulletins are read-only

Bulletins are publicly readable by all (it's a town square) but only the posting clan's instance can write to its own slots. Other clans' instances see them through reads only.

### Reserved keys within own namespace (convention, not enforced)

The access matrix grants the agent's instance write access to all of `clan:{N}:*`. But some keys within that namespace are **convention-reserved for the orchestrator** and the agent should never write to them. ClanMemory does not enforce this — it's a soft convention, not a hard rule.

| Key | Owner |
|---|---|
| `clan:{N}:notebook/*` | Agent — free schema |
| `clan:{N}:mission_attestations/*` | `elder act` toolbelt internals (auto-write) |
| `clan:{N}:last_turn_tick` | Orchestrator only |
| `clan:{N}:parse_failures/*` | Toolbelt internals |
| `clan:{N}:_orchestrator/*` | Orchestrator only (any future bookkeeping) |

The risk: a confused or prompt-injected agent could write garbage to `clan:{N}:last_turn_tick` and confuse the orchestrator. For hackathon scope this is acceptable — the agent has no incentive to corrupt its own bookkeeping, and the consequences are recoverable (orchestrator detects bad value, resets, continues).

If we wanted hard enforcement post-hackathon, the cleanest fix is two `ClanMemory` instances per clan with different access rules:
- Agent's instance: writable scope is `clan:{N}:notebook/*` only
- Orchestrator's instance: writable scope is full `clan:{N}:*`

This is a config-level distinction (the access matrix would be parameterized by an "agent-mode" flag on the constructor). Easy to add later if needed; explicitly out of scope for the hackathon spec.

### Implementation note

Namespace check happens **before** any network call. A rejected write is cheap. The check function is a pure regex/prefix match on the key string — keep it that way for performance and auditability.

```typescript
// pseudocode
function checkAccess(key: string, op: "read" | "write" | "delete", clanId: number): void {
  const rules = ACCESS_RULES;
  if (!rules[op].some(rule => rule.test(key, clanId))) {
    throw new ClanMemoryAccessError(`${op} denied: ${key} (clanId=${clanId})`);
  }
}
```

---

## 5. Key conventions (tied to battle plan §7)

The library does not enforce key shape beyond the namespace prefix — agents have schema freedom inside their namespace. But these are the keys the orchestrator/toolbelt produces and consumes, and the library should treat them as canonical:

### Per-clan private (`clan:{N}:*`)

| Key | Writer | Purpose |
|---|---|---|
| `clan:{N}:notebook/*` | Agent (via `elder mem write`) | Agent's freeform notebook; schema-free |
| `clan:{N}:mission_attestations/{nonce}` | `elder act` | Auto-written on every successful tx submit |
| `clan:{N}:last_turn_tick` | Orchestrator | Bookkeeping for situation-pump cadence |
| `clan:{N}:parse_failures/{tick}` | Toolbelt internals | Tool error history (debugging) |

### Realm-global (`realm:*`)

| Key | Writer | Purpose |
|---|---|---|
| `realm:townsquare:bulletin:{N}:{slot}` | `elder say bulletin` | Public 3-slot ring per clan |
| `realm:townsquare:index:{N}` | `elder say bulletin` | `{latestUpdateTick}` for cheap discovery |

### Inbox (`inbox:{N}:*`)

| Key | Writer | Purpose |
|---|---|---|
| `inbox:{N}:whisper_index/{senderClanId}/{tick}` | Orchestrator AXL bridge | Index entry pointing at the AXL message |

The library exposes thin convenience helpers for these well-known patterns (see §8) but never as a *replacement* for raw `read`/`write`. Conveniences are sugar; the raw API is the contract.

---

## 6. Error model

Three error classes. All extend `Error`. Caller distinguishes via `instanceof`.

### `ClanMemoryAccessError`

Thrown by namespace enforcement. Indicates a programming error or a malicious caller. Should never happen in well-formed code.

```typescript
{
  name: "ClanMemoryAccessError",
  message: "write denied: clan:3:notebook/foo (clanId=7)",
  key: "clan:3:notebook/foo",
  op: "write",
  ownClanId: 7,
}
```

### `ClanMemoryTransportError`

Thrown after retry budget exhausts on network/SDK failures. Wraps the underlying error.

```typescript
{
  name: "ClanMemoryTransportError",
  message: "write failed after 3 attempts: <underlying message>",
  key: "clan:7:notebook/strategy",
  op: "write",
  cause: <original Error>,
  attempts: 3,
}
```

The agent CLI should surface this to the agent as a tool failure with the message; the agent can decide whether to retry, defer, or proceed. This matches the toolbelt's "errors are immediately replied to the agent" pattern from the battle plan.

### `ClanMemoryValueError`

Thrown when a value can't be serialized (e.g., circular references in JSON). Pure caller bug.

```typescript
{
  name: "ClanMemoryValueError",
  message: "value not JSON-serializable: <reason>",
  key: "clan:7:notebook/foo",
}
```

### Not thrown

- "Key not found" on read — returns `null` instead
- "Delete of nonexistent key" — silent no-op

---

## 7. 0G KV access control mechanism — pluggable

Per battle plan §11 #9, the underlying KV access control mechanism is TBD pending Discord answers. The library hides this behind a strategy interface so we can swap implementations without touching callers.

```typescript
interface KvAuthStrategy {
  signWrite(key: string, value: Uint8Array): Promise<KvAuthHeaders>;
  signRead?(key: string): Promise<KvAuthHeaders>;  // if reads need auth
}
```

Two implementations to ship:

### `NativeSignedWriteStrategy`

If 0G KV supports per-namespace authorized-writer gating with a registered signing key, this strategy signs each write with the agent wallet key directly. Cleanest, no orchestrator involvement.

### `OrchestratorMediatedStrategy`

If 0G KV is open-write (or uses a different model that doesn't fit our needs), this strategy routes signed writes through a small orchestrator endpoint that validates iNFT ownership against on-chain state before signing on the agent's behalf. More plumbing but works regardless of native KV semantics.

The agent doesn't see the difference — both implementations satisfy the same `KvAuthStrategy` interface, and `ClanMemory` accepts a strategy in its config:

```typescript
new ClanMemory({
  clanId: 7,
  signer,                                        // ethers Signer
  authStrategy: new NativeSignedWriteStrategy({ signer, zgKvNodeUrl }),
  // ...other config
});
```

For development we can ship a third strategy:

### `MockStrategy`

In-memory map. No network, no signing. Used by unit tests and by the orchestrator in dry-run mode for local agent development without a 0G connection.

---

## 8. Convenience helpers

Built on top of the raw API. Optional sugar for common patterns. None of these add new authority — they're equivalent to inlined `read`/`write` calls.

**Caller passes `currentTick` explicitly to any helper that needs it.** ClanMemory does not have chain access and does not fetch tick state itself. The toolbelt or orchestrator fetches the current tick (via `getWorldSnapshot()` on the game contract) and passes it in. This keeps ClanMemory's responsibility narrow and makes the timing explicit at the call site.

### Shared types

```typescript
interface Bulletin {
  content: string;
  postedAtTick: number;
  postedByClanId: number;
  teeSignature: string | null;       // null for non-GLM-5 elders
}

interface BulletinSlots {
  slot0: Bulletin | null;
  slot1: Bulletin | null;
  slot2: Bulletin | null;
}

interface WhisperIndexEntry {
  senderClanId: number;
  sentAtTick: number;
  axlMessageId: string;              // opaque AXL identifier; orchestrator uses to fetch body
  summary?: string;                   // optional short preview written by AXL bridge
}

interface MissionAttestation {
  reasoning: string;                 // freeform agent rationale
  teeSignature: string | null;       // null for non-GLM-5 elders
  providerAddr: string | null;       // 0G Compute provider address, null otherwise
  missionHash: string;               // hash of the order JSON
  submittedAtTick: number;
  submittedAtTxHash: string;
}
```

### Bulletins

```typescript
async readBulletins(): Promise<Map<number /* clanId */, BulletinSlots>>
```
Reads `realm:townsquare:index:*` to find active posters, then batch-reads their slots. Returns map keyed by clan id. Slots that have never been posted are `null`. Useful for the situation-pump assembly path.

```typescript
async writeOwnBulletin(
  slotIndex: 0 | 1 | 2,
  content: string,
  currentTick: number,
  teeSignature: string | null = null
): Promise<void>
```
Writes a `Bulletin` object to `realm:townsquare:bulletin:{ownClanId}:{slotIndex}` and bumps `realm:townsquare:index:{ownClanId}` to `{ latestUpdateTick: currentTick }`.

**Overwrite behavior:** silently overwrites any existing slot content. ClanMemory does **not** archive the prior content. If the orchestrator wants to maintain a Log-layer archive of evicted bulletins, it should `read` the old slot before calling this helper and write to its own archive path.

### Mission attestations

```typescript
async writeMissionAttestation(nonce: number, attestation: MissionAttestation): Promise<void>
```
Writes the attestation to `clan:{ownClanId}:mission_attestations/{nonce}`.

**Call timing:** invoked by `elder act` *after* the on-chain tx receipt confirms. The caller extracts `nonce` from event logs in the receipt, fills in `submittedAtTick` and `submittedAtTxHash` from the confirmation, then writes. If the tx reverts, no attestation is written.

### Inbox

```typescript
async readNewWhispers(sinceTick: number): Promise<WhisperIndexEntry[]>
```
Lists `inbox:{ownClanId}:whisper_index/*`, filters to entries with `sentAtTick > sinceTick`, returns sorted ascending by `sentAtTick`. Used by the orchestrator's situation-pump.

```typescript
async writeWhisperIndex(entry: WhisperIndexEntry): Promise<void>
```
Used by the orchestrator's AXL bridge after polling AXL and finding a new message. Writes to `inbox:{ownClanId}:whisper_index/{entry.senderClanId}/{entry.sentAtTick}`.

### Notebook (agent-facing, but library doesn't constrain shape)

```typescript
async readNotebook<T = unknown>(subkey: string): Promise<T | null>
async writeNotebook(subkey: string, value: unknown): Promise<void>
async listNotebook(subPrefix?: string): Promise<string[]>
async readAllNotebook<T = unknown>(subPrefix?: string): Promise<Map<string, T>>
```
Thin sugar over `clan:{ownClanId}:notebook/{subkey}`. Agents are free to use raw `read`/`write` if they prefer — these helpers exist only to save typing of the prefix. `readAllNotebook` is especially useful for the boot/reset flow.

---

## 9. Concurrency, ordering, retry

### Multiple processes per clan is expected

Each clan has at least two ClanMemory instances running concurrently:

1. **Agent's instance** — short-lived, spawned per `elder mem` CLI invocation (or held by long-running toolbelt subprocess), writes mostly to `clan:{N}:notebook/*`
2. **Orchestrator's instance** — long-lived, writes bookkeeping (`last_turn_tick`), runs the AXL bridge writing to `inbox:{N}:*`, performs situation-pump reads

This is normal. The system is designed for it.

The constraint is **per-key writer ownership by convention**: different processes write to different keys, so they don't race on the same key. The §4 access matrix and §5 key conventions table together establish who writes what:

- Agent → `notebook/*`
- Toolbelt internals (called from agent's process) → `mission_attestations/*`, `parse_failures/*`, `realm:townsquare:bulletin:{N}:*`
- Orchestrator → `last_turn_tick`, `inbox:{N}:*`

If both processes ever wrote to the same key, last-write-wins applies (no atomicity, no merge). In practice they never do — the conventions prevent it.

### Last-write-wins per key

0G KV is last-write-wins on a single key. The library does not add CAS, version tracking, or locking. If a race somehow occurs (bug in conventions, two orchestrator processes, etc.), the last write silently overwrites the prior value. We accept this; tracking it would require version bookkeeping that adds complexity for marginal hackathon value.

### Retry policy

Exponential backoff on transport errors, configurable via `retryConfig`. Default: 3 attempts, base delay 200ms, exponential factor 2 (so 200ms, 400ms, 800ms).

Retry only on transport errors. Never on `ClanMemoryAccessError` or `ClanMemoryValueError` — those are deterministic and won't change on retry.

### Reads are idempotent and safe to retry freely

Reads have no side effects and can be retried as aggressively as the retry config allows.

### Writes have at-least-once semantics on transport retry

A write that retries after a network error may have actually succeeded on the prior attempt and the success response was lost. The retry then re-writes the same value (which in last-write-wins KV is effectively idempotent — same key, same value, no-op net effect). This is fine for our use cases.

The one edge case: if two processes write to the same key concurrently and one retries, the retry's value may overwrite the *other* process's intervening successful write. Mitigation: don't have two processes write to the same key (covered by §4/§5 conventions).

### Read-after-write consistency

If 0G KV is eventually consistent, the library does **not** add any read-your-own-writes guarantee. The caller must assume a brief window where a freshly written key may not yet be visible to reads, including reads from the same instance.

This is a real concern for the situation-pump path, where the orchestrator might write `last_turn_tick = 412` and then immediately read it back to confirm. We don't handle this in `ClanMemory`. Caller adds its own delay or in-memory cache if needed.

(For hackathon scope: this almost certainly won't bite us. Note in case it does. If it does bite, the cleanest mitigation is a small write-through cache: every successful write also caches `key → value` in process memory for ~5 seconds, and reads check the cache first. Keep this in mind as a future addition if needed.)

### Schema versioning — explicit non-goal

Stored values do not include a schema version field. As `MissionAttestation`, `Bulletin`, and other shapes evolve in future versions, old data may not match new code's expectations. We don't have a migration plan.

For hackathon: shapes are baked in at the current spec version and any post-hackathon evolution will need to handle compatibility manually (read both shapes, normalize). Mentioned here so it's not a surprise later.

This deliberately differs from `ClanIdentity`'s approach, which versions its single blob via a top-level `version: 1` field. The reasons for the difference: `ClanIdentity` has *one* large blob with *one* schema, where a version field is cheap and gives a single migration point; `ClanMemory` has *many* small values across many keys with several different shapes, where adding a version field to each would bloat storage and add cognitive overhead with no practical hackathon-scope benefit. Different choices for different data shapes.

---

## 10. Testing strategy

Three tiers:

### Unit tests

Use `MockStrategy` (in-memory). Test:
- All access matrix permutations (read/write/delete × ownership)
- Error class identities
- JSON round-tripping
- Convenience helpers wire to correct keys
- Retry budget exhaustion

### Integration tests

Use a local 0G KV node (testnet or local devnet). Test:
- Round-trip read/write
- List behavior on populated namespace
- Subscription delivery (or polling fallback)
- Auth strategy switching

### Smoke tests

Hit live 0G mainnet KV with a throwaway agent wallet. Tests:
- End-to-end namespace enforcement on real network
- Retry behavior under real flakiness
- Latency budgets

For hackathon: unit tests are required. Integration tests if local devnet is easy to spin up. Smoke tests are nice-to-have, run manually before demo.

---

## 11. Build order

1. **Skeleton + MockStrategy** (~2-4 hours). Define the class, error types, access matrix, all methods stubbed. Unit tests pass against mock.

2. **Real 0G KV adapter** (~4-8 hours, depends on Discord answers and SDK quirks). Wire `@0glabs/0g-ts-sdk` into a `NativeSignedWriteStrategy` or `OrchestratorMediatedStrategy`. Get a single read/write working against a testnet KV node.

3. **Convenience helpers** (~2-3 hours). Bulletins, attestations, inbox helpers. Mechanical given the raw API works, but each one has its own type and tick-passing details.

4. **Integration tests** (~2-4 hours). Run against a local devnet or testnet.

5. **Wire into toolbelt** (~3-6 hours). `elder mem` becomes a thin CLI wrapper over `ClanMemory`. `elder act` calls `writeMissionAttestation`. `elder say bulletin` calls `writeOwnBulletin`. AXL bridge calls `writeWhisperIndex`.

Total: ~2-3 days of focused work for a single implementer. SDK quirks, auth strategy ambiguity (TBD #9), and 0G testnet flakiness can extend this. Build the skeleton first to unblock other workstreams that depend on the API surface.

---

## 12. What this spec doesn't cover

- **`ClanIdentity`** — the parallel library for the iNFT encrypted blob (CLAUDE.md, skills, personality, optional axlPrivateKey). See `clanworld_clan_identity_spec.md`.
- **The ERC-7857 contract** — see `clanworld_inft_deployment_notes.md`.
- **Orchestrator lifecycle** — how the AXL bridge runs, how situation-pumps are scheduled, how resets work. That's runtime/ops, not library API.
- **Agent prompting** — what the CLAUDE.md says, how skills are structured. Separate concern.
- **The `elder *` CLI command implementations** — they're thin wrappers over this library; their argv parsing and stdout formatting is a separate small spec or just code.

---

## 13. Decision log

Hard:

- ✅ TypeScript module, single class instantiated per process with config
- ✅ `clanId` locked at construction; namespace enforcement at every method
- ✅ Takes ethers `Signer`, never raw private key bytes (security)
- ✅ Three error classes: `ClanMemoryAccessError`, `ClanMemoryTransportError`, `ClanMemoryValueError`
- ✅ "Key not found" returns null, never throws
- ✅ KV-only scope; iNFT blob is `ClanIdentity`'s problem
- ✅ Pluggable auth strategy (Native, Orchestrator-mediated, Mock)
- ✅ Always-JSON serialization on read and write — no magic format detection
- ✅ Last-write-wins; no CAS, no versioning, no locking
- ✅ Multiple processes per clan is the expected model; per-key writer ownership is a convention, not enforced
- ✅ Retry only on transport errors, exponential backoff
- ✅ `writeMany` is best-effort sequential, not atomic; returns success/failure breakdown
- ✅ `watch` is for *new keys appearing under prefix*, not value-change watching; polling fallback only works for the former
- ✅ Caller passes `currentTick` explicitly to helpers that need it; ClanMemory has no chain access
- ✅ Bulletin archival on overwrite is NOT done by ClanMemory; orchestrator-side concern (and cut priority for hackathon)
- ✅ Mission attestation written after tx confirmation, not before
- ✅ `delete` returns `boolean` (true if deleted, false if didn't exist)
- ✅ `close()` lifecycle method for clean shutdown (idempotent)

Soft:

- ⚠️ Watch/subscribe API — ship if 0G KV supports push; otherwise polling fallback at the lib level (with documented semantic limitations)
- ⚠️ Convenience helpers — useful but not strictly required
- ⚠️ Smoke tests against mainnet — only if time
- ⚠️ Reserved sub-namespaces enforced (two ClanMemory instances per clan with different scopes) — convention only for hackathon, hard enforcement post-hackathon if needed

Open:

- ❓ Which auth strategy ships first (depends on Discord answer to TBD #9 in battle plan)
- ❓ Exact 0G KV SDK call shape — will firm up when we read SDK docs
- ❓ Whether reads need auth headers at all (depends on KV's read-access model)
- ❓ Exact format of `zgKvStreamId` (string? bytes32? specific 0G type?) — pending SDK docs
- ❓ Read-after-write consistency window in practice — only matters if it bites us; mitigation noted in §9

Explicit non-goals:

- ❌ Schema versioning of stored values (no `version` field on `MissionAttestation`, `Bulletin`, etc.) — deferred to post-hackathon
- ❌ CAS / optimistic concurrency on writes
- ❌ Built-in caching beyond what 0G KV provides
- ❌ Memory consolidation, summarization, or any "smart" agent-side helpers — agents do that themselves
