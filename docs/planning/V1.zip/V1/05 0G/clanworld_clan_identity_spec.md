# ClanIdentity — TypeScript API Spec

**Status:** Draft v0.3
**Scope:** The TypeScript library that wraps the ERC-7857 iNFT encrypted blob for Clanworld. Sibling to `ClanMemory`. The 0G ERC-7857 contract itself is documented in `clanworld_inft_deployment_notes.md`, which uses the reference implementation.
**Companion docs:** `clanworld_0g_battleplan_and_spec.md`, `clanworld_clan_memory_spec.md`, `clanworld_inft_deployment_notes.md`
**Audience:** Whoever implements the orchestrator boot path, the owner UI, and the `elder strategy` toolbelt command.

---

## 1. Purpose

`ClanIdentity` is the TypeScript module that wraps all reads and writes against the ERC-7857-encrypted Elder identity blob. It loads the blob from 0G Storage given a token id, decrypts it locally with the DEK (data encryption key), and exposes structured access to the fields. It also handles the owner-side write path (re-encrypt + upload + update on-chain hash).

It exists to:

- centralize the encryption / decryption flow in one place
- expose the typed identity fields (CLAUDE.md, skills, personality, axlPrivateKey, persistent strategy tail) to consumers
- gate writes to owner-only by construction (read-only mode for non-owner consumers like the orchestrator)
- integrate with the ERC-7857 contract on 0G chain for metadata updates

It is **not**:

- the ERC-7857 contract itself (see `clanworld_inft_deployment_notes.md` for the contract we deploy)
- the TEE oracle (operated externally by 0G; out of scope, and we use `MockOracle` for hackathon)
- aware of 0G Storage KV (that's `ClanMemory`'s job)
- responsible for ownership transfer logic (the contract's `transfer()` plus the TEE oracle handle that; the library can watch for `MetadataUpdated` events but does not orchestrate transfers, and our deploy uses `MockOracle` so the real TEE re-encryption is not exercised)

---

## 2. Module shape

Two construction modes — read-only and read-write — distinguished by which inputs the caller supplies.

### Read-only mode (used by orchestrator at Elder boot)

```typescript
import { ClanIdentity } from "@clanworld/clan-identity";

const identity = await ClanIdentity.openReadOnly({
  tokenId: 7n,
  inftContractAddress: process.env.INFT_CONTRACT_ADDR!,
  zgRpcUrl: process.env.ZG_RPC_URL!,
  zgStorageNodeUrl: process.env.ZG_STORAGE_NODE_URL!,
  dek: Buffer.from(process.env.CLAN_DEK_HEX!, "hex"),  // pre-supplied DEK
  logger: console,
});

const claudeMd = await identity.readClaudeMd();
```

In read-only mode, the caller supplies the DEK directly (it was generated at mint and is held in a local file — see §6). The library can decrypt and read but cannot write.

### Read-write mode (used by owner UI for editing)

```typescript
import { ClanIdentity } from "@clanworld/clan-identity";
import { Wallet } from "ethers";

const ownerSigner = new Wallet(process.env.OWNER_WALLET_KEY!);

const identity = await ClanIdentity.openReadWrite({
  tokenId: 7n,
  inftContractAddress: process.env.INFT_CONTRACT_ADDR!,
  zgRpcUrl: process.env.ZG_RPC_URL!,
  zgStorageNodeUrl: process.env.ZG_STORAGE_NODE_URL!,
  ownerSigner,                       // ethers Signer matching token owner
  dek: Buffer.from(process.env.CLAN_DEK_HEX!, "hex"),  // raw DEK from owner-local storage
  logger: console,
});

await identity.updatePersistentStrategy("Build coalition; fortify base 0007.");
```

In read-write mode, the caller supplies **both** the DEK and the owner's signer:
- The DEK is used to decrypt the current blob and re-encrypt updates (same as read-only mode)
- The owner's signer is used to authorize on-chain `updateMetadata()` transactions

The owner has the raw DEK locally (it was generated at mint and saved to a local file — see §6 and `clanworld_inft_deployment_notes.md` §4 mint flow). The library never seals or unseals DEKs; sealing is only relevant during ownership transfer, which is handled by the TEE oracle external to this library.

The library refuses write operations in read-only mode (no signer = no way to authorize txs).

### Config field reference

| Field | Type | Required | Mode | Purpose |
|---|---|---|---|---|
| `tokenId` | `bigint` | yes | both | iNFT token id to load |
| `inftContractAddress` | `string` | yes | both | ERC-7857 contract (`AgentNFT`) proxy address on 0G chain |
| `zgRpcUrl` | `string` | yes | both | 0G chain RPC endpoint |
| `zgStorageNodeUrl` | `string` | yes | both | 0G Storage node endpoint |
| `dek` | `Buffer` (32 bytes) | yes | both | Data encryption key, supplied by caller in both modes |
| `ownerSigner` | `ethers.Signer` | yes | read-write | Owner's wallet signer; signs `updateMetadata()` txs; library checks `ownerOf(tokenId)` matches the signer's address at construction |
| `logger` | `Logger` | no | both | Same `Logger` interface as `ClanMemory` |

### Why two modes

Both modes need the DEK; the distinction is whether the caller has the owner's wallet signer:

- **Read-only mode** — the orchestrator runs with the agent wallet (per battle plan §9), which is **not** the iNFT owner. It has no authority to call `updateMetadata()`. It just needs to decrypt and serve up CLAUDE.md, skills, etc. to the Elder session.
- **Read-write mode** — the owner UI runs with the owner wallet. It can both decrypt and submit on-chain updates.

Splitting these into two static constructors makes the asymmetry structural: a read-only instance literally cannot call write methods (they don't exist on the type), so accidental writes from the orchestrator path are impossible by construction.

Both modes get the DEK the same way: read it from the local file the owner UI maintained at mint time. See §6 for the file flow.

---

## 3. The encryption model

ERC-7857's reference implementation uses **envelope encryption with TEE-mediated re-keying on transfer**. For Clanworld's hackathon scope, since we deploy `MockOracle` (which doesn't actually re-key on transfer) and the contrived demo transfer just hands over the same DEK manually, the model simplifies significantly: the owner generates a DEK at mint, keeps it locally, and uses it for all subsequent reads and writes. Sealing/unsealing in the formal ERC-7857 sense only matters during real TEE-mediated transfer, which our deploy doesn't do.

```
                   ┌─────────────────────────────────────┐
                   │  0G Storage (encrypted blob)         │
                   │  ┌───────────────────────────────┐  │
                   │  │ AES-256-GCM(blob, DEK)        │  │
                   │  │ format: [12 IV | 16 tag | ct] │  │
                   │  └───────────────────────────────┘  │
                   └─────────────────┬───────────────────┘
                                     │ pointed to by encryptedURI
                                     │
                   ┌─────────────────▼───────────────────┐
                   │  ERC-7857 contract (on 0G chain)     │
                   │  • _metadataHashes[tokenId]          │
                   │      = keccak256(ciphertext)         │
                   │  • _encryptedURIs[tokenId]           │
                   │      = 0G Storage root hash          │
                   └──────────────────────────────────────┘

           ┌─────────────────────────────────────────────┐
           │  DEK (32 bytes, AES-256 key)                 │
           │  • generated once at mint                    │
           │  • saved to ~/.clanworld/clan-{N}-dek.hex    │
           │  • never enters the contract                 │
           │  • only sealed during transfer flow (TEE)    │
           └─────────────────────────────────────────────┘
```

### Layers

1. **Blob layer** — the JSON identity object (§4) is serialized, then encrypted with AES-256-GCM using the DEK. The output (`[IV | tag | ciphertext]`) is uploaded to 0G Storage. Its root hash is the `encryptedURI`. A `keccak256(ciphertext)` hash commitment is stored on-chain in `_metadataHashes` for integrity verification.

2. **DEK layer** — a 32-byte symmetric key. Generated by `crypto.randomBytes(32)` at mint. The owner UI saves it to a local file. The orchestrator reads it from that file at boot. **Not stored on-chain. Not stored on 0G Storage. Lives only in the local file plus whatever decrypted state the owner UI / orchestrator keep in memory.**

3. **Sealing layer (real TEE flow only, not exercised in our deploy)** — during a real ERC-7857 ownership transfer, the TEE oracle decrypts the blob, generates a new DEK, re-encrypts the blob, and seals the new DEK with the receiver's secp256k1 public key via ECIES. The sealed DEK is published in the transfer event so the receiver can unseal it with their wallet's private key. Our `MockOracle` deploy skips all of this — the contrived demo transfer just hands over the existing DEK out-of-band.

### Why envelope encryption (even though we don't use the envelope)

The ERC-7857 standard mandates this structure for transfer support. Even though our deploy doesn't do real TEE-mediated transfers, we follow the same blob-encryption format so that:
- A future post-hackathon transfer would Just Work without re-encrypting all stored data
- The on-chain hash commitment integrity check works the same way as for any ERC-7857 token
- We're conformant with the standard's design

The ECIES sealing path is dormant code in our deployment but still part of the contract.

### What ClanIdentity actually does

Read path (local, no TEE, no sealing):
1. Caller supplies the DEK (passed to either constructor)
2. Library calls contract: `getEncryptedURI(tokenId)` and `getMetadataHash(tokenId)`
3. Library fetches the encrypted blob from 0G Storage via the URI
4. Library verifies `keccak256(ciphertext) === metadataHash` (throws `ClanIdentityIntegrityError` on mismatch)
5. Library decrypts with AES-256-GCM using the DEK
6. Library parses the JSON, validates schema, caches the blob

Write path (read-write mode only, local + one on-chain tx):
1. Library reads from cache (already decrypted)
2. Library applies the field update in memory
3. Library re-encrypts the new blob with the **same DEK** and a **fresh IV** (never reuse IVs with GCM)
4. Library uploads new ciphertext to 0G Storage; gets new root hash (the new `encryptedURI`)
5. Library computes new commitment: `keccak256(newCiphertext)`
6. Library calls contract: `updateMetadata(tokenId, newEncryptedURI, newMetadataHash)` with owner's signer (see `clanworld_inft_deployment_notes.md` §3 TBD #3 for the function signature; this is the one Clanworld-specific addition to the reference impl)
7. Library awaits transaction confirmation
8. Library updates the internal cache to the new blob
9. Library returns receipt

No re-sealing. The DEK is unchanged across owner edits — only the IV and ciphertext change.

Transfer path (real TEE flow not exercised in our deploy; see below for what does happen with `MockOracle`):
- Old owner triggers transfer flow externally (owner UI calls contract `transfer()` with TEE oracle proof)
- TEE oracle (out-of-process, operated by 0G in production; `MockOracle` in our deploy) handles re-encryption with new DEK + sealing for new owner
- New owner receives sealed DEK via transfer event payload, unseals with their wallet, saves to their own local file
- New owner reconstructs `ClanIdentity` instance with the new DEK

Since we deploy `MockOracle`, the only `transfer()` call in our deploy is the contrived demo transfer, which `MockOracle` accepts without verifying any real proof. No real re-encryption happens; the new owner gets handed the same DEK out-of-band as part of the demo script.

---

## 4. The encrypted blob schema

The decrypted blob is a single JSON object. This is the canonical schema for v1:

```typescript
interface ClanIdentityBlob {
  version: 1;
  claudeMd: string;          // full CLAUDE.md system prompt, including the
                             // "## Persistent Strategy & Notes" tail section
  skills: ClaudeCodeSkill[]; // Claude Code skills to load at session boot
  personality: {
    tone: string;            // e.g., "cautious, transactional, slow to trust"
    values: string;          // e.g., "wealth accumulation > glory"
  };
  axlPrivateKey: string | null;  // hex-encoded AXL keypair private key, or null
                                  // if the clan uses a fresh AXL identity per owner
}

interface ClaudeCodeSkill {
  name: string;              // skill identifier, e.g., "market-analysis"
  content: string;           // the skill's markdown content
}
```

### Field constraints

- `version` — currently `1`. Bump on incompatible schema change. The library checks this at load and throws `ClanIdentityVersionError` if unsupported.
- `claudeMd` — markdown text. Size budget: 50KB. Larger values will work but slow down decrypts. Includes both the static rules/tools/conventions (top of file) and the owner-editable persistent strategy tail (see §5).
- `skills` — array of skills, each with a unique `name`. Total combined size budget: 200KB. The orchestrator writes these to disk at boot for the Claude Code session to consume.
- `personality.tone` and `personality.values` — short strings (~200 chars each).
- `axlPrivateKey` — TBD per battle plan #7. If included, the agent's whisper identity travels with the iNFT. If `null`, the orchestrator generates a fresh AXL keypair per Elder boot (clean slate).

### Total blob size budget

Aim for under 300KB decrypted. AES-256-GCM adds 16 bytes overhead per block plus a 12-byte IV plus a 16-byte tag — negligible at this size. 0G Storage handles much larger blobs but smaller is faster to fetch and decrypt.

---

## 5. Persistent Strategy & Notes — tail section parsing

The `claudeMd` field has two halves:

1. **Static head** — game rules, tool descriptions, conventions. Set at clan mint, rarely or never changed mid-game.
2. **Owner-editable tail** — strategic guidance the owner can update. Replaces what earlier drafts called "doctrine."

The split is delimited by an exact heading on its own line: `## Persistent Strategy & Notes`.

### Parsing rules (must be implemented exactly)

- The delimiter is the literal string `## Persistent Strategy & Notes` (case-sensitive, no leading or trailing whitespace, on its own line)
- **Exactly one** such heading must appear in `claudeMd`. Zero or more than one is an error
- Content above the delimiter (exclusive) = static head
- Content from the delimiter (inclusive) to end of string = tail section
- The tail section starts with the heading line itself; the heading is part of the tail

### Library API for the tail

```typescript
async readPersistentStrategy(): Promise<string>
```
Returns the tail section, including the `## Persistent Strategy & Notes` heading line and all content after.

```typescript
async updatePersistentStrategy(newTailContent: string): Promise<void>  // read-write only
```
Replaces the tail section. Caller can supply content with or without the leading heading; the library normalizes to ensure the heading is present exactly once at the start. Fully re-encrypts the blob and submits the on-chain update.

If the static head doesn't contain the delimiter heading, this method throws `ClanIdentityFormatError`.

### Edge cases

- If the static head is empty (CLAUDE.md is just the persistent strategy section), the library still works — the head is empty string, the tail is the whole content.
- If the tail is empty (just the heading, no content under it), valid. `readPersistentStrategy()` returns `"## Persistent Strategy & Notes\n"` or similar.
- Trailing whitespace / newline normalization: the library preserves the original style; it does not auto-strip or auto-add newlines. Owner UI is responsible for sensible whitespace.

---

## 6. DEK handoff to the orchestrator (hackathon flow)

The orchestrator runs with the agent wallet, but the DEK belongs to the iNFT owner. We need to get the DEK from the owner's machine into the orchestrator's environment without requiring the owner's private key to be present at orchestrator runtime. Three flows are possible; we pick the simplest for hackathon.

### Hackathon flow — local file (DECIDED)

1. **At clan mint**, the owner UI:
   a. Generates a fresh DEK locally: `crypto.randomBytes(32)`
   b. Encrypts the initial `ClanIdentityBlob` with this DEK (AES-256-GCM)
   c. Uploads ciphertext to 0G Storage, captures the root hash
   d. Calls `AgentNFT.mint(ownerAddress, encryptedURI, metadataHash)` and captures the resulting `tokenId`
   e. Writes the raw DEK (64 hex chars, no `0x` prefix) to `~/.clanworld/clan-{tokenId}-dek.hex` with mode `0600`

   See `clanworld_inft_deployment_notes.md` §4 for the full mint flow including upload mechanics.

2. **At orchestrator boot**, the orchestrator:
   a. Reads `tokenId` from the game contract's `Clan.iftTokenId` field
   b. Reads the DEK from `~/.clanworld/clan-{tokenId}-dek.hex`
   c. Loads it into env: `CLAN_DEK_HEX="${...}"` (or passes directly as a Buffer)
   d. Constructs `ClanIdentity.openReadOnly` with the DEK
   e. Reads `claudeMd`, `skills`, `personality`, `axlPrivateKey`
   f. Hands these to the Claude Code session at spawn

3. **On owner update to persistent strategy** (mid-game):
   a. Owner UI reads the same DEK from the same local file
   b. Constructs `ClanIdentity.openReadWrite` with the DEK + owner signer
   c. Calls `identity.updatePersistentStrategy(...)` — library re-encrypts (same DEK, fresh IV), uploads to 0G Storage, calls `updateMetadata()` on contract
   d. Contract emits `MetadataUpdated` event with new URI
   e. Orchestrator's `watch` callback fires → cache refreshes → orchestrator pumps the updated CLAUDE.md into the next Claude Code session boot

The DEK is unchanged across this entire flow. Only the ciphertext on storage and the on-chain hash change.

### What this skips (deliberately, for hackathon scope)

- **`authorizeUsage()` / sealed executor flow** — the proper ERC-7857 way to give a non-owner authority to use the metadata without exposing the DEK. Requires another TEE for the executor. Out of scope. The hackathon shortcut treats the orchestrator as a trusted local process and just gives it the raw DEK.
- **Cross-machine DEK distribution** — if the owner UI runs on one machine and the orchestrator on another, you need a secure channel to ship the DEK file over. For demo, both run locally on the same machine.
- **Transfer support** — when a clan iNFT transfers, the new owner would need to repeat the file flow with their own machine. Real ERC-7857 mechanics: TEE oracle seals the new DEK to their pubkey during transfer, they unseal with their wallet, save to their own local file. Our deploy uses `MockOracle` which doesn't perform the seal/unseal — the contrived demo transfer instead hands over the existing DEK manually between owner UIs as part of the demo script. The library doesn't help with either flow; it just gets reconstructed against whatever DEK file the new owner has.

### Security notes

- The DEK file is sensitive. Mode `0600`, owned by the orchestrator-runtime user, never checked in.
- If the file is leaked, the leaker can decrypt the blob from 0G Storage. Mitigations are out of scope for hackathon — we trust the local environment.
- The owner UI should never display or log the DEK in plaintext beyond writing the file.
- For a proper deployment, replace the local file with a HashiCorp Vault / AWS KMS / similar secrets-management path. The library's interface (just takes a `Buffer`) accommodates any such backing store.

---

## 7. Public API

All methods are async. All methods that touch chain or storage throw on transport errors. Read methods that target missing data return `null` rather than throwing (consistent with `ClanMemory`).

### Construction

```typescript
static async openReadOnly(config: ReadOnlyConfig): Promise<ClanIdentity>
static async openReadWrite(config: ReadWriteConfig): Promise<ClanIdentity>
```

Both constructors:
- Call the contract to fetch `_encryptedURIs[tokenId]` and `_metadataHashes[tokenId]`
- Fetch the encrypted blob from 0G Storage
- Verify the hash commitment matches (otherwise throw `ClanIdentityIntegrityError`)
- Decrypt with the DEK
- Parse and validate the JSON shape (throws `ClanIdentityFormatError` on malformed)
- Cache the decrypted blob in process memory

Return a ready-to-use instance. After construction, reads are served from cache.

### Reads

```typescript
async readClaudeMd(): Promise<string>
async readSkills(): Promise<ClaudeCodeSkill[]>
async readPersonality(): Promise<{ tone: string; values: string }>
async readAxlPrivateKey(): Promise<string | null>
async readPersistentStrategy(): Promise<string>      // tail section only
async readStaticHead(): Promise<string>              // claudeMd minus the tail
async readAll(): Promise<ClanIdentityBlob>           // full blob
```

All synchronous from the cache after construction; the `async` is for interface consistency with the write methods.

### Writes (read-write mode only)

```typescript
async updatePersistentStrategy(newTail: string): Promise<UpdateReceipt>
async updateSkills(newSkills: ClaudeCodeSkill[]): Promise<UpdateReceipt>
async updatePersonality(newPersonality: { tone: string; values: string }): Promise<UpdateReceipt>
async updateStaticHead(newHead: string): Promise<UpdateReceipt>
async updateAll(newBlob: ClanIdentityBlob): Promise<UpdateReceipt>
```

Each write:
1. Validates the change against the schema (throws `ClanIdentityValueError` on bad input)
2. Constructs a new full blob with the change applied
3. Re-encrypts with the current DEK (new IV per write — never reuse IVs)
4. Uploads new ciphertext to 0G Storage
5. Computes new hash commitment
6. Calls contract update function with owner's signer
7. Awaits transaction confirmation
8. Updates the internal cache to the new blob
9. Returns receipt

```typescript
interface UpdateReceipt {
  txHash: string;
  newMetadataHash: string;
  newEncryptedURI: string;
  blockNumber: number;
}
```

In read-only mode, all `update*` methods throw `ClanIdentityAccessError("read-only mode")`.

### Reactive — watching for external updates

```typescript
async watch(callback: (event: IdentityChangeEvent) => void): Promise<() => void>
```

Subscribes to the ERC-7857 contract's `MetadataUpdated` event for this `tokenId`. On each event:
- Library refreshes the cache (re-fetches blob, re-decrypts with current DEK)
- Calls the callback with the change event

Used by the orchestrator to detect mid-session strategy updates from the owner UI:

```typescript
identity.watch(async (event) => {
  // owner edited persistent strategy; reload the agent's CLAUDE.md
  await orchestrator.refreshAgentSystemPrompt();
});
```

The watch lifecycle handles connection drops and reconnects internally. Errors during watch are logged but do not propagate to the callback. Returns an unsubscribe function.

For hackathon scope: `MetadataUpdated` events fire only on owner-driven `updateMetadata()` calls (the DEK is unchanged), so cache refresh always works. The contrived demo transfer doesn't fire `MetadataUpdated` — it fires `Transfer` — and since the DEK doesn't actually rotate (MockOracle skips re-encryption), the new owner's orchestrator just constructs a new ClanIdentity instance with the same DEK and same blob URI. The "DEK changed underneath us" scenario would only happen with a real TEE oracle transfer; if that happens post-hackathon, cache refresh would fail to decrypt with the old DEK and the library logs an error; the caller would have to reconstruct the instance with the new DEK supplied by the new owner.

### Lifecycle

```typescript
async close(): Promise<void>
```

Cleans up watch subscriptions and any internal connections. Idempotent. After close, all method calls throw `ClanIdentityAccessError("closed")`.

---

## 8. Error model

Six error classes. All extend `Error`. Caller distinguishes via `instanceof`.

### `ClanIdentityAccessError`

Thrown when:
- A write is attempted in read-only mode
- A method is called after `close()`
- The caller's signer doesn't match the token owner (write mode)

### `ClanIdentityIntegrityError`

Thrown when:
- The fetched blob's hash doesn't match the on-chain commitment
- Decryption fails (wrong DEK, tampered ciphertext)

This indicates either corruption, a wrong DEK, or a malicious storage node. Library does not retry — the caller has to investigate.

### `ClanIdentityFormatError`

Thrown when:
- The decrypted blob isn't valid JSON
- The JSON doesn't match the `ClanIdentityBlob` schema
- The `claudeMd` is missing the `## Persistent Strategy & Notes` heading (when reading or updating the tail specifically)
- The `claudeMd` has more than one such heading

Caller bug or stale data from an older schema version.

### `ClanIdentityValueError`

Thrown when:
- A write input doesn't satisfy schema constraints (e.g., `personality.tone` is empty, `skills` has duplicate names)

### `ClanIdentityTransportError`

Thrown after retry budget exhausts on RPC, storage, or contract call failures. Wraps the underlying error.

```typescript
{
  name: "ClanIdentityTransportError",
  message: "fetch encrypted blob failed after 3 attempts: <underlying message>",
  layer: "storage" | "chain",
  cause: <original Error>,
  attempts: 3,
}
```

### `ClanIdentityVersionError`

Thrown when the loaded blob's `version` field is not supported by the current library version. Indicates an upgrade is needed.

---

## 9. Caching

The library caches the decrypted blob in process memory. Cache invalidation:

- **Explicit refresh** — caller calls `refresh()` (proposed convenience, see §10) to re-fetch from chain + storage and re-decrypt
- **Watch event** — `watch` callback fires after auto-refreshing cache on `MetadataUpdated`
- **Successful write** — after a write tx confirms, cache is updated to the new blob in-memory (no need to re-fetch)
- **Construction** — initial load populates cache

The cache is per-instance; multiple `ClanIdentity` instances for the same token id maintain independent caches. They will diverge if one instance writes — the other won't see the change until it refreshes or the `MetadataUpdated` event reaches its watch.

For hackathon: we run one orchestrator instance per Elder, so divergence isn't a real risk.

---

## 10. Convenience helpers

```typescript
async refresh(): Promise<void>
```
Re-fetches the blob from chain + storage and updates cache. Useful after external changes when not using `watch`.

```typescript
async getOwnerAddress(): Promise<string>
```
Calls `ownerOf(tokenId)` on the contract. Useful for sanity checks: at orchestrator boot, the orchestrator can compare the returned address against an expected owner (e.g., from the game contract's `Clan.owner` field, or hardcoded for demo) to verify the iNFT is owned by who we think it is. In read-write mode, the library already verifies that `ownerOf(tokenId) === ownerSigner.address` at construction, so this method is redundant there — but exposed anyway for callers that want an explicit check.

```typescript
async verifyDekValidity(): Promise<boolean>
```
Tries to decrypt the blob with the current DEK. Returns `true` on success, `false` on failure. Useful at orchestrator startup to fail fast if the DEK from the local file is stale (e.g., a real TEE-mediated transfer happened post-hackathon and we still have the old DEK).

---

## 11. Resolved questions (from `clanworld_inft_deployment_notes.md`)

The following were originally open TBDs in v0.1; all have been resolved by reading the ERC-7857 reference implementation and are documented in detail in `clanworld_inft_deployment_notes.md` §3. Summary here for cross-reference; **see deployment notes for the authoritative answers and code samples**.

| # | Question | Resolution |
|---|---|---|
| 1 | Where is the sealed-DEK stored? | **Not stored on-chain.** Owner generates DEK at mint and keeps it locally. Sealing is only used during real TEE-mediated transfer flow (passed as `bytes calldata sealedKey` parameter to `transfer()`). Our `MockOracle` deploy doesn't exercise the real sealing path; the contrived demo transfer just hands over the existing DEK out-of-band. |
| 2 | Re-seal DEK on every metadata update? | **No.** Same DEK across all owner edits; only IV and ciphertext change. |
| 3 | Contract function signature for metadata updates | `updateMetadata(uint256 tokenId, string newEncryptedURI, bytes32 newMetadataHash)` — owner-gated via `require(ownerOf(tokenId) == msg.sender)`. This is the one Clanworld-specific addition to the reference impl; reference impl had no public update function (only update via `transfer()`). |
| 4 | `MetadataUpdated` event includes new URI? | Reference impl: only the hash. Our extension: includes new URI. New event signature: `event MetadataUpdated(uint256 indexed tokenId, bytes32 newHash, string newURI)`. Saves a contract round-trip per event in the watch flow. |
| 5 | ECIES library | `eth-crypto` (npm package). Only relevant for the real TEE-mediated transfer flow, which our `MockOracle` deploy doesn't exercise. The library itself does not implement ECIES — see §13 build order. |
| 6 | AES variant | AES-256-GCM with fresh 12-byte IV per write. Format: `[12 IV | 16 tag | ciphertext]`. Node.js `crypto` module's `createCipheriv` / `createDecipheriv`. |
| 7 | `authorizeUsage()` flow | Out of scope. The hackathon DEK-via-local-file shortcut serves the same purpose without needing a sealed executor TEE. |

### Hash commitment (clarified during research)

The on-chain `metadataHash` is `keccak256(ciphertext)`, **not** `keccak256(plaintext)`. The reference impl's docs example hashed plaintext, which would defeat integrity verification (a malicious storage node could swap ciphertexts for any with matching plaintext-hash). We hash ciphertext so anyone fetching from storage can verify the bytes haven't been tampered with. See deployment notes §3 "Bonus" for the analysis.

This interpretation should be verified with 0G Discord before production; it's the only ERC-7857 conformance question that remains soft.

### Still open (genuinely unresolved)

| # | Question | Resolution path |
|---|---|---|
| 8 | Whether `Indexer.upload()` from `@0glabs/0g-ts-sdk` returns a usable URI directly or just a root hash that we format ourselves | Resolved during implementation by reading SDK source / running integration test |
| 9 | Whether the reference impl's recent `main` branch differs materially from the older `eip-7857-draft` branch the EIP still references | Read the diff before deploying; default to `main` |

---

## 12. Testing strategy

### Unit tests

Use a `MockOracle` and a fake 0G Storage adapter (in-memory). Test:
- Encrypt-decrypt round-trip with a known DEK
- Hash commitment matches after encrypt
- Tail-section parsing handles all edge cases (missing heading, multiple headings, empty tail, empty head)
- All six error classes fire on the right inputs
- Read-only mode rejects all writes
- Watch fires on simulated `MetadataUpdated` events
- Cache invalidation on writes works correctly

### Integration tests

Use the `MockOracle` + a real 0G Storage testnet node. Test:
- Round-trip read/write against actual storage
- Contract update tx submits and confirms
- Watch detects real on-chain events

### Smoke tests

Hit live 0G mainnet with a throwaway wallet. Tests:
- Full mint → upload → read flow
- Owner edit flow

For hackathon: unit tests required. Integration tests if devnet is easy. Smoke tests pre-demo only.

---

## 13. Build order

1. **Skeleton + crypto core** (~2-3 hours). AES-256-GCM encrypt/decrypt with proper IV handling, `keccak256` hash commitment, error classes. Pure-JS, no 0G or chain calls. Unit tests with known vectors. ECIES seal/unseal is **not** required — the library doesn't implement those (sealing happens client-side in the owner UI at mint, and at transfer time inside the TEE oracle, neither of which is in this library).

2. **Schema + parsing** (~2 hours). `ClanIdentityBlob` validation, persistent strategy tail extraction/replacement, error classes. Unit tests.

3. **Storage adapter** (~3-4 hours). Wire `@0glabs/0g-ts-sdk` for blob upload/download. Unit-test against a mock; integration-test against testnet.

4. **Contract adapter** (~3-5 hours). Wire ethers + the ERC-7857 ABI for `getEncryptedURI`, `getMetadataHash`, `ownerOf`, and `updateMetadata` (the Clanworld-specific addition; see deployment notes §3 TBD #3). Test against the reference impl deployed to testnet.

5. **Read-only mode** (~2 hours). Ties together schema + storage + contract on the read path.

6. **Read-write mode** (~3-4 hours). Adds the write path (re-encrypt, upload, contract update, await confirmation).

7. **Watch + reactive flow** (~2-3 hours). Contract event subscription, cache refresh on event.

8. **Owner UI integration** (~separate workstream). Out of scope for this lib spec.

9. **Orchestrator integration** (~separate workstream). Out of scope for this lib spec.

Total library-only work: ~3-4 days for one implementer. SDK quirks, ERC-7857 reference impl divergence, and ECIES library issues can extend this. Build crypto core and schema first to unblock dependent work.

---

## 14. What this spec doesn't cover

- **The ERC-7857 contract itself** — see `clanworld_inft_deployment_notes.md`. We deploy the reference implementation as-is plus one `updateMetadata` function and an extended `MetadataUpdated` event.
- **Transfer flow** — TEE oracle re-encryption, sender / receiver proof construction, contract `transfer()` mechanics. The real ERC-7857 TEE flow is out of hackathon scope; we deploy `MockOracle` which rubber-stamps any proof, and the contrived demo transfer skips real re-encryption. The library doesn't orchestrate transfers either way — it just gets reconstructed with whatever DEK the new owner has after a transfer. See ERC-7857 spec and the reference impl `transfer()` function for the genuine design if implementing later.
- **`authorizeUsage()` / sealed executor pattern** — proper non-owner-but-authorized agent execution. Hackathon uses local DEK file shortcut instead.
- **Owner UI implementation** — frontend forms, wallet connection, file write of DEK. Separate workstream.
- **Orchestrator boot integration** — how the DEK file is loaded, how skills are written to disk, how the agent is spawned. Operational concern, lives in the orchestrator's design.
- **Mint flow** — see `clanworld_inft_deployment_notes.md` §4. Mint is a one-time operation owned by the deployment runbook, not the library.

---

## 15. Decision log

Hard:

- ✅ TypeScript module
- ✅ Two construction modes: `openReadOnly` and `openReadWrite`
- ✅ Both modes take pre-supplied DEK; the distinction is whether the caller has the owner's signer (only read-write does)
- ✅ Read-write mode verifies `ownerOf(tokenId) === ownerSigner.address` at construction
- ✅ Envelope encryption: AES-256-GCM on blob (with fresh IV per write); ECIES on DEK is part of the standard but only relevant during real TEE-mediated transfer, which our `MockOracle` deploy doesn't exercise
- ✅ DEK is fixed at mint and never rotated during owner edits; would only re-key during real TEE-mediated transfer (not exercised in our deploy)
- ✅ Decrypted blob cached in process memory
- ✅ Cache refresh on writes (in-memory) and on `MetadataUpdated` events (re-fetch + re-decrypt with same DEK)
- ✅ Persistent strategy tail uses literal `## Persistent Strategy & Notes` heading as delimiter; exactly one occurrence required
- ✅ Six error classes: `Access`, `Integrity`, `Format`, `Value`, `Transport`, `Version`
- ✅ Hackathon DEK handoff: owner UI writes DEK to local file at mint; orchestrator reads from file at boot
- ✅ Library does not handle ownership transfer; only watches `MetadataUpdated` events
- ✅ `authorizeUsage()` / sealed executor pattern is out of hackathon scope
- ✅ Schema versioning via top-level `version: 1` field; bump on incompatible changes — different from ClanMemory which deliberately doesn't version (one big blob with one schema vs many small values with many shapes)
- ✅ Hash commitment is `keccak256(ciphertext)`, not plaintext; ensures storage-layer integrity check works (see deployment notes §3)
- ✅ Contract function for owner updates: `updateMetadata(tokenId, newURI, newHash)` — Clanworld addition to reference impl
- ✅ `MetadataUpdated` event extended to include `newURI` so watch flow doesn't need a contract round-trip per event

Soft:

- ⚠️ Caching strategy is simple per-instance; no cross-process invalidation
- ⚠️ Watch fallback to polling if 0G chain RPC doesn't support push subscriptions
- ⚠️ Smoke tests against mainnet — only if time
- ⚠️ Hash-commitment-of-ciphertext interpretation should be confirmed via Discord before production deployment

Open:

- ❓ Exact format of `Indexer.upload()` return value from `@0glabs/0g-ts-sdk` (root hash directly vs needs formatting) — resolved during implementation
- ❓ Whether reference impl's `main` branch matches `eip-7857-draft` semantically — read the diff before deploying

Explicit non-goals:

- ❌ Cross-machine DEK distribution (use local file; replace with KMS post-hackathon)
- ❌ `authorizeUsage()` and sealed executor flows
- ❌ Ownership transfer orchestration (the library only reacts to `MetadataUpdated` events)
- ❌ TEE oracle implementation (operated externally by 0G in production; we deploy `MockOracle`)
- ❌ Mint flow (lives in deployment notes / owner UI, not here)
- ❌ Real-time collaborative editing (one writer at a time, last-write-wins)
- ❌ Re-keying the DEK without going through the formal transfer flow

---

## 16. Glossary

- **Blob** — the JSON `ClanIdentityBlob` containing CLAUDE.md, skills, personality, axlPrivateKey
- **Ciphertext** — the AES-encrypted blob, what's stored on 0G Storage
- **DEK** — Data Encryption Key, the symmetric AES-256 key used to encrypt the blob
- **Sealed DEK** — the DEK encrypted with the owner's secp256k1 public key via ECIES; only relevant during real TEE-mediated transfer flow (dormant in our `MockOracle` deploy)
- **Encrypted URI** — pointer (root hash) to the ciphertext on 0G Storage; stored on-chain in `_encryptedURIs[tokenId]`
- **Metadata hash** — hash commitment of the ciphertext; stored on-chain in `_metadataHashes[tokenId]`; integrity check on read
- **Persistent Strategy & Notes** — the owner-editable tail section of `claudeMd`, delimited by an exact heading
- **Static head** — the `claudeMd` content above the persistent strategy delimiter; rules, tools, conventions
- **TEE oracle** — external 0G-operated service that handles re-encryption during ownership transfer; ClanIdentity does not call it directly; our deploy uses `MockOracle` instead, which rubber-stamps any proof and skips real re-encryption
- **Read-only mode** — instance constructed with a pre-supplied DEK; can read and watch but not write
- **Read-write mode** — instance constructed with the owner's signer; can read, write, and watch
