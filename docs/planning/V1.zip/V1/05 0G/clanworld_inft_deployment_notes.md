# Clanworld iNFT — Deployment Notes & Reference Impl Annotations

**Status:** Draft v0.2
**Scope:** Concrete answers to ClanIdentity §11 TBDs from reading the ERC-7857 reference implementation, plus deployment runbook for our specific setup. **Not a contract spec** — we are deploying the reference implementation with one Clanworld-specific addition, not designing a contract from scratch.
**Companion docs:** `clanworld_0g_battleplan_and_spec.md`, `clanworld_clan_identity_spec.md`
**Audience:** Whoever does the contract deployment, owner UI integration, and ClanIdentity implementation.

---

## 1. Sources

The single canonical source is **0gfoundation/0g-agent-nft**. Older references that still appear in 0G docs and EIP text point at `0glabs/0g-agent-nft` — that's the same project under its old org name. Use the current canonical:

- **Reference implementation:** [github.com/0gfoundation/0g-agent-nft](https://github.com/0gfoundation/0g-agent-nft) (main branch, License: CC0-1.0)
- **EIP-7857 specification:** [eips.ethereum.org/EIPS/eip-7857](https://eips.ethereum.org/EIPS/eip-7857)
- **0G ERC-7857 documentation:** [docs.0g.ai/developer-hub/building-on-0g/inft/erc7857](https://docs.0g.ai/developer-hub/building-on-0g/inft/erc7857)
- **0G INFT integration guide:** [docs.0g.ai/developer-hub/building-on-0g/inft/integration](https://docs.0g.ai/developer-hub/building-on-0g/inft/integration)
- **0G INFT overview:** [docs.0g.ai/developer-hub/building-on-0g/inft/inft-overview](https://docs.0g.ai/developer-hub/building-on-0g/inft/inft-overview)
- **0G mainnet (Aristotle) docs:** [docs.0g.ai/developer-hub/mainnet/mainnet-overview](https://docs.0g.ai/developer-hub/mainnet/mainnet-overview)
- **0G testnet (Galileo) docs:** [docs.0g.ai/developer-hub/testnet/testnet-overview](https://docs.0g.ai/developer-hub/testnet/testnet-overview)

Repo structure (from inspecting the README):

```
0g-agent-nft/
├── contracts/        Solidity sources
├── doc/              architecture diagrams (oracle_overview.jpeg, tee_oracle.jpeg, full_flow.jpeg)
├── scripts/          deploy + helper scripts
├── src/tasks/        Hardhat tasks (TypeScript)
├── test/
├── hardhat.config.ts
└── package.json
```

The repo uses Hardhat + pnpm. Solidity 52% / TypeScript 48% by content. The deployment uses an upgradeable proxy pattern — community deployment guides reference both `AgentNFTImpl` and `TEEVerifier` deployed addresses, which means the `AgentNFT` is the proxy and `AgentNFTImpl` is the implementation. We don't need to care about the upgradeability for hackathon — just follow the reference deployment flow.

---

## 2. Network details

### Mainnet — Aristotle (LIVE since September 2025)

| Parameter | Value |
|---|---|
| Network Name | 0G Mainnet |
| Chain ID | 16661 (`0x4115`) |
| Token Symbol | 0G |
| Default RPC | `https://evmrpc.0g.ai` |
| Block Explorer | `https://chainscan.0g.ai` |
| Storage Indexer | `https://indexer-storage-turbo.0g.ai` |
| 0G Storage Flow contract | `0x62D4144dB0F0a6fBBaeb6296c785C71B3D57C526` |
| 0G Storage Mine contract | `0xCd01c5Cd953971CE4C2c9bFb95610236a7F414fe` |
| 0G Storage Reward contract | `0x457aC76B58ffcDc118AABD6DbC63ff9072880870` |
| Recommended 3rd-party RPCs | QuickNode, ThirdWeb, Ankr, dRPC |

### Testnet — Galileo

| Parameter | Value |
|---|---|
| Network Name | 0G-Galileo-Testnet |
| Chain ID | 16602 |
| Token Symbol | 0G |
| Default RPC | `https://evmrpc-testnet.0g.ai` (development only — use 3rd party for stability) |
| Block Explorer | `https://chainscan-galileo.0g.ai` |
| Faucet | `https://faucet.0g.ai` (0.1 0G/day/wallet — request more in Discord if needed) |
| Google Cloud Faucet | `https://cloud.google.com/application/web3/faucet/0g/galileo` |
| 0G Storage Flow contract | `0x22E03a6A89B950F1c82ec5e74F8eCa321a105296` |
| 0G Storage Mine contract | `0x00A9E9604b0538e06b268Fb297Df333337f9593b` |
| 0G Storage Reward contract | `0xA97B57b4BdFEA2D0a25e535bd849ad4e6C440A69` |

### Recommendation for Clanworld

Per battle plan §10: **deploy on mainnet** (Aristotle). The 0.1 OG/day testnet faucet limit is going to be annoying with 4 elders running heartbeats, GLM-5 Compute calls if used, KV writes, and iNFT mint+update transactions. A small mainnet OG balance (a few OG covers the entire demo lifecycle — see Gas costs in §7) is cleaner than rationing testnet drips.

For the iNFT specifically, since we deploy `MockOracle` (which skips real TEE re-encryption on transfer), the prize narrative is the same on mainnet vs testnet — both demonstrate the same `MockOracle`-based contrived transfer with manual DEK handoff. Use mainnet to match the rest of the deployment.

---

## 3. Resolved ClanIdentity §11 TBDs

These were the open questions in the ClanIdentity spec. Answers from reading the reference impl and the standard:

### TBD #1 — Where is the sealed-DEK stored?

**Answer: Not stored in the contract at all.** The reference impl's contract has three mappings:
- `mapping(uint256 => bytes32) _metadataHashes` — hash commitment
- `mapping(uint256 => string) _encryptedURIs` — pointer to ciphertext on 0G Storage
- `mapping(uint256 => mapping(address => bytes)) _authorizations` — for the `authorizeUsage()` flow only, not the DEK

The sealed DEK is **never stored on-chain.** It's:

- Generated client-side at mint time
- Held by the owner locally (UI / wallet / file)
- Passed in as a `bytes calldata sealedKey` parameter to the `transfer()` function during ownership transfer
- "Published" by the contract during transfer via event payload so the receiver can capture it

For Clanworld hackathon scope: since we deploy `MockOracle` and don't perform real TEE-mediated re-keying, the sealed DEK never functionally enters the contract. The contrived demo transfer does pass *some* `bytes calldata sealedKey` parameter into `transfer()` (the function signature requires it), but `MockOracle` accepts it without verifying anything — it could be empty bytes or random garbage. The real DEK is handed over manually between owner UIs out-of-band. Owner generates the DEK at mint, hands it to the orchestrator via the local file flow (battle plan §6), and that's the entire functional lifecycle.

### TBD #2 — Re-seal the DEK on every metadata update?

**Answer: No.** Owner-driven metadata updates use the *same DEK* with a fresh IV per encryption. The DEK sealing only enters the picture during ownership transfer (TEE re-keys on transfer).

For our hackathon: the DEK is fixed at mint. Every owner edit to the persistent strategy or skills re-encrypts with the same DEK and a fresh IV (AES-256-GCM requirement). Cleaner and simpler.

### TBD #3 — Exact contract function signature for metadata updates

**Answer: The reference impl example doesn't include one — we add it.**

Looking at the contract from the docs reference, the only function that mutates `_encryptedURIs` and `_metadataHashes` mid-life is `_updateMetadataAccess`, which is `internal` and called only from `transfer()`. There's no public owner-driven update function.

We need to add one for Clanworld since we want the owner UI to update persistent strategy mid-game without doing a fake transfer. Suggested signature:

```solidity
function updateMetadata(
    uint256 tokenId,
    string calldata newEncryptedURI,
    bytes32 newMetadataHash
) external {
    require(ownerOf(tokenId) == msg.sender, "Not owner");
    _encryptedURIs[tokenId] = newEncryptedURI;
    _metadataHashes[tokenId] = newMetadataHash;
    emit MetadataUpdated(tokenId, newMetadataHash, newEncryptedURI);
}
```

**This is the only Clanworld-specific addition to the reference contract.** Everything else we use as-is.

If we want to be principled about ERC-7857 conformance, we should check whether the standard *forbids* such an extension. Looking at EIP-7857 (still in draft), the standard mandates the `transfer` flow with proofs but doesn't appear to forbid additional owner-only update paths. Adding `updateMetadata` is a Clanworld-specific extension, not a standard violation — but worth noting for any future audit.

### TBD #4 — Does MetadataUpdated event include the new URI?

**Answer: Reference impl event only includes the hash. We extend it to also include the URI.**

The reference impl declares:
```solidity
event MetadataUpdated(uint256 indexed tokenId, bytes32 newHash);
```

For ClanIdentity's `watch` flow, this means the orchestrator would have to do a separate `getEncryptedURI(tokenId)` call after every event. Cheap but adds a round-trip.

Suggested extension (also paired with the new `updateMetadata` function above):
```solidity
event MetadataUpdated(uint256 indexed tokenId, bytes32 newHash, string newURI);
```

Includes the URI in the event payload, so the watch handler has everything it needs in the event itself. Trivial size cost in event logs.

### TBD #5 — ECIES library choice

**Answer: `eth-crypto`** ([npmjs.com/package/eth-crypto](https://www.npmjs.com/package/eth-crypto)). It supports ECIES encrypt/decrypt for secp256k1 keys, which is what wallet keys are. Maintained by Daniel Meyer; widely used; standard pick.

Install: `npm install eth-crypto`

Usage pattern:
```typescript
import EthCrypto from "eth-crypto";

// Seal DEK to recipient pubkey
const sealedDek = await EthCrypto.encryptWithPublicKey(recipientPublicKey, dekHex);
const sealedDekString = EthCrypto.cipher.stringify(sealedDek);

// Unseal DEK with recipient privkey
const sealedDekObj = EthCrypto.cipher.parse(sealedDekString);
const dekHex = await EthCrypto.decryptWithPrivateKey(recipientPrivateKey, sealedDekObj);
```

Note: ECIES uses the wallet's secp256k1 keypair directly. `EthCrypto.publicKeyByPrivateKey(privateKey)` derives the pubkey if you only have the privkey. Make sure to use the **uncompressed pubkey** (without the `0x04` prefix per `eth-crypto`'s convention).

### TBD #6 — AES variant

**Answer: AES-256-GCM with strict per-write fresh IV.** Standard Node.js `crypto` module:

```typescript
import { randomBytes, createCipheriv, createDecipheriv } from "crypto";

function encryptBlob(plaintext: Buffer, dek: Buffer): Buffer {
  const iv = randomBytes(12);  // 96-bit IV per GCM spec
  const cipher = createCipheriv("aes-256-gcm", dek, iv);
  const ct = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([iv, tag, ct]);  // [12 IV | 16 tag | ciphertext]
}

function decryptBlob(blob: Buffer, dek: Buffer): Buffer {
  const iv = blob.subarray(0, 12);
  const tag = blob.subarray(12, 28);
  const ct = blob.subarray(28);
  const decipher = createDecipheriv("aes-256-gcm", dek, iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(ct), decipher.final()]);
}
```

DEK is 32 bytes, IV is 12 bytes (NIST recommendation for GCM), tag is 16 bytes. Never reuse an IV with the same DEK — `randomBytes(12)` is fine for our update frequency (negligible collision risk).

### TBD #7 — Should ClanIdentity handle `authorizeUsage()`?

**Answer: No, explicit non-goal.** The reference impl has `authorizeUsage(tokenId, executor, permissions)` for the sealed-executor pattern. Skipping for hackathon as previously decided. The hackathon DEK-via-local-file shortcut serves the same purpose without TEE infrastructure.

### Bonus — TBD on hash commitment computation

The reference impl uses `keccak256(...)` of various data. Looking at the `MetadataManager` example in the integration guide:

```javascript
const metadataHash = ethers.utils.keccak256(
  ethers.utils.toUtf8Bytes(JSON.stringify(metadata))
);
```

Ambiguity: this hashes the **plaintext metadata**, not the **ciphertext**. But the standard wants integrity of the ciphertext (so the receiver can verify the bytes they got from storage match what was committed on-chain). Using plaintext hash would break that.

**Suggested correction for Clanworld:** hash the ciphertext, not the plaintext:
```typescript
const metadataHash = keccak256(ciphertext);  // ciphertext = output of encryptBlob()
```

This way the on-chain commitment lets anyone fetching the ciphertext verify it wasn't tampered with by the storage layer. The plaintext is recovered via the DEK, which is owner-bound, so the integrity guarantee is end-to-end.

This is a reasonable interpretation; we should run it past 0G Discord if there's any doubt before committing to it in production.

---

## 4. Mint flow

The "cold start" — how a clan iNFT gets created in the first place. This belongs in the deployment notes (not ClanIdentity) because it touches the contract directly and happens once per clan.

### Step-by-step

1. **Owner UI generates the initial blob.** The owner provides:
   - Initial CLAUDE.md (with `## Persistent Strategy & Notes` tail section)
   - Initial skills (Claude Code skill markdown files)
   - Personality (tone + values)
   - Decision on AXL private key inclusion (TBD #7 in battle plan; if yes, generate a fresh AXL keypair and store the private key)

   Compose into a `ClanIdentityBlob` JSON object.

2. **Generate a fresh DEK.** 32 random bytes from `crypto.randomBytes(32)`.

3. **Encrypt the blob.** AES-256-GCM with the DEK and a fresh 12-byte IV. Output is `[IV | tag | ciphertext]`.

4. **Compute the metadata hash.** `keccak256(ciphertext)`.

5. **Upload to 0G Storage.**
   ```typescript
   import { Indexer, ZgFile } from "@0glabs/0g-ts-sdk";
   const file = await ZgFile.fromBuffer(ciphertext, "clanIdentity.bin");
   const [tx, err] = await indexer.upload(file, evmRpc, ownerSigner);
   // capture root hash from tx
   ```
   The root hash returned is the `encryptedURI` (or rather, the root hash forms the URI; check exact format with the SDK).

6. **Mint on-chain.** Owner signs and submits:
   ```typescript
   const tx = await agentNFT.connect(ownerSigner).mint(
     ownerAddress,        // to
     encryptedURI,        // from step 5
     metadataHash,        // from step 4
   );
   const receipt = await tx.wait();
   const tokenId = receipt.events.find(e => e.event === "Transfer").args.tokenId;
   ```
   Note: in the reference impl, `mint()` is `onlyOwner` (contract owner, i.e., the deployer). For our deployment, either:
   - Deployer = clan owner (single-clan demo)
   - Or modify `mint()` to be public-callable with payment / KYC / whatever access-control we want

   For hackathon: easiest to keep `onlyOwner` and have the deployer mint clans on behalf of demo participants. Or remove the modifier entirely and let anyone mint (acceptable for hackathon, document as such).

7. **Save the DEK to the local file.** The owner UI writes the raw DEK as hex to `~/.clanworld/clan-{tokenId}-dek.hex` (mode 0600). The orchestrator is configured to read from this path at boot.

8. **Bind to game contract.** Owner calls the Base/World game contract's `mintClan()` (or whatever it's named in IClanWorld) with the `iftTokenId` set to the value from step 6. Now the cross-chain link is established.

### What "owner" means here

There are now three distinct roles to be careful about:

- **Contract deployer** — deploys the AgentNFT contract on 0G chain. May or may not be `onlyOwner` for `mint()`.
- **iNFT owner** — holder of the ERC-721 token after mint. Can update metadata, can transfer.
- **Agent wallet** — separate wallet with minimal funds, used by the orchestrator for game txs (battle plan §9). Never holds the iNFT.

For demo simplicity: contract deployer == iNFT owner (one wallet does both). Agent wallet is separate. Owner UI runs with the iNFT-owner wallet. Orchestrator runs with the agent wallet.

---

## 5. Cross-chain binding to game contract

Per battle plan §4, the game contract on Base/World stores `Clan.iftTokenId` as an opaque uint256. This is just the iNFT token id from the 0G `AgentNFT` contract.

What's NOT stored on the game contract: the iNFT contract address. That's a deployment constant baked into the orchestrator's config:

```bash
# orchestrator env
INFT_CONTRACT_ADDR=0x...           # AgentNFT proxy address on 0G
INFT_CHAIN_ID=16661                # 0G mainnet
```

The orchestrator uses `iftTokenId` from the game contract + `INFT_CONTRACT_ADDR` from its env to look up the iNFT.

If we ever redeploy the iNFT contract, all clans break and we'd need a migration. Acceptable risk for hackathon.

---

## 6. Deployment runbook

Concrete sequence for getting the iNFT contract deployed and a first clan minted on mainnet.

### Pre-requirements

- `pnpm` installed
- An owner wallet with at least 1 OG on mainnet (sufficient for several deploys + dozens of clan mints/edits at hackathon scale)
- 0G mainnet RPC access (default `https://evmrpc.0g.ai` or a 3rd party)
- Familiarity with Hardhat

### Deployment steps

```bash
# 1. Clone reference impl
git clone https://github.com/0gfoundation/0g-agent-nft.git
cd 0g-agent-nft

# 2. Install dependencies
pnpm install

# 3. Apply our one modification: add updateMetadata function
# Edit contracts/AgentNFT.sol (or wherever the main contract lives in this repo)
# to add the updateMetadata function and extend the MetadataUpdated event
# (see §3 TBD #3 and #4 above)

# 4. Configure mainnet network in hardhat.config.ts
# Add:
#   networks: {
#     "0g-mainnet": {
#       url: "https://evmrpc.0g.ai",
#       chainId: 16661,
#       accounts: [process.env.OWNER_PRIVATE_KEY],
#     }
#   }

# 5. Deploy TEEVerifier (the oracle) and AgentNFT
# The repo's deploy scripts handle this. Check scripts/ for the exact entrypoint.
# Typical sequence:
pnpm hardhat run scripts/deploy.ts --network 0g-mainnet

# Output should give you:
#   TEEVerifier deployed at: 0x...
#   AgentNFTImpl deployed at: 0x...
#   AgentNFT (proxy) deployed at: 0x...

# 6. Save the AgentNFT proxy address to orchestrator config
echo "INFT_CONTRACT_ADDR=0x..." >> .env
```

### First clan mint

```bash
# 7. Use the owner UI (or a script) to mint a clan
# The owner UI does the encrypt→upload→mint→DEK-file flow from §4

# Or for testing, a Hardhat task:
pnpm hardhat clan-mint --network 0g-mainnet \
  --owner 0xOwnerAddress \
  --claudemd ./templates/clan-1-claude.md \
  --skills ./templates/clan-1-skills/ \
  --personality '{"tone":"...","values":"..."}'

# This task should:
# - Read the inputs
# - Generate DEK
# - Encrypt blob
# - Upload to 0G Storage
# - Call AgentNFT.mint() and capture tokenId
# - Save DEK to ~/.clanworld/clan-{tokenId}-dek.hex
# - Print the tokenId for use in IClanWorld.mintClan()

# 8. Bind on game side
pnpm hardhat clan-bind --network base-mainnet \
  --token-id <from previous step> \
  --inft-contract-addr <0G AgentNFT addr>
```

---

## 7. Operational notes

### DEK file format and lifecycle

Format: 64 hex characters (32 bytes), no `0x` prefix, no trailing newline. One file per clan at `~/.clanworld/clan-{tokenId}-dek.hex`. Mode `0600`. Owned by the orchestrator-runtime user.

Lifecycle:
- **Created at mint** by the owner UI (or the mint task in the runbook above)
- **Read at orchestrator boot** to construct `ClanIdentity.openReadOnly`
- **Re-read on `MetadataUpdated` event** to refresh cache (DEK doesn't change, blob does)
- **Replaced on transfer** — for the contrived MockOracle-based demo transfer, the new owner's UI manually receives the DEK from the old owner (out-of-band as part of the demo script) and writes it to their own clan-{tokenId}-dek.hex. Real TEE flow would re-key automatically; we don't.
- **Deleted** when the clan is decommissioned post-demo

### What the contract addresses look like

After deployment, three addresses matter:

| Address | What | Used by |
|---|---|---|
| `TEEVerifier` (or `MockOracle`) | Oracle for transfer proofs | The contract's `transfer()` — we don't call directly |
| `AgentNFTImpl` | Implementation contract behind the proxy | Don't reference directly; just the proxy |
| `AgentNFT` (proxy) | The user-facing contract | ClanIdentity, owner UI, orchestrator |

ClanIdentity config takes the `AgentNFT` proxy address as `inftContractAddress`. We never reference the impl or the verifier directly.

### MockOracle vs real TEE oracle

The reference impl supports both. For hackathon: deploy with `MockOracle` (a simpler oracle that just returns true on any proof). This is fine because:
- We don't have access to a real TEE oracle for the hackathon timeline
- A `MockOracle`-based contrived transfer (rubber-stamped proof + manual DEK handoff between owner UIs) is enough to demonstrate the *intelligence-travels-with-iNFT* narrative for the pitch — see battle plan demo punch line
- Production migration to a real TEE oracle is a future-work item

**Important to surface honestly in the submission README:** with `MockOracle`, the cryptographic guarantee of the real ERC-7857 TEE flow is not enforced. Anyone could construct a "transfer proof" that the mock would accept. Don't let judges or readers believe we're shipping cryptographic transfer security.

What we *do* demonstrate end-to-end: the iNFT contract's storage shape, the owner-driven `updateMetadata()` path, the encrypted blob format, the cross-wallet boot path, the agent picking up its KV memory after ownership change. These are real and verifiable. The TEE oracle's verify-and-re-encrypt step is the only thing stubbed.

### Gas costs

Rough estimates from comparable ERC-721 + extension deployments on EVM chains:

| Operation | Gas estimate |
|---|---|
| Deploy AgentNFT (proxy + impl) | ~3-5M gas |
| Deploy TEEVerifier / MockOracle | ~500k gas |
| `mint()` per clan | ~150-200k gas |
| `updateMetadata()` per edit | ~50-80k gas |

Total for 4 clans + a handful of strategy edits during the demo: well under 1 OG worth of gas. The compute costs (GLM-5 if used, 0G Storage uploads) will dominate any blockchain gas costs by several orders of magnitude.

---

## 8. What this doc doesn't cover

- **The contract source itself** — read the reference impl repo. We're using it largely as-is.
- **Owner UI implementation** — frontend forms, wallet connection logic, file export. Out of scope here.
- **Orchestrator implementation** — DEK file reading, `ClanIdentity` integration. See `clanworld_clan_identity_spec.md`.
- **Transfer flow** — the real TEE re-encryption flow is out of scope for hackathon (no real TEE oracle deployed). The `MockOracle`-based contrived transfer used in the demo is described in §7 ("MockOracle vs real TEE oracle"). For the genuine flow if implementing later, see EIP-7857 and the reference impl's `transfer()` function.
- **Gas optimization** — we don't have meaningful gas pressure at hackathon scale.
- **Multi-chain ownership coordination** — out of scope; addressed by the cross-chain split in battle plan §4.

---

## 9. Decision log

Hard:

- ✅ Use `0gfoundation/0g-agent-nft` reference impl as-is, with two minimal additions:
  - `updateMetadata(tokenId, newURI, newHash)` external function (owner-gated)
  - `MetadataUpdated` event extended to include `newURI`
- ✅ Deploy on 0G mainnet (Aristotle, chain ID 16661)
- ✅ Use `MockOracle` for the deploy; the contrived demo transfer goes through `MockOracle` (which rubber-stamps any proof) plus manual DEK handoff between owner UIs. Real TEE-mediated re-encryption on transfer is not implemented.
- ✅ DEK stored in local file `~/.clanworld/clan-{tokenId}-dek.hex`, mode 0600
- ✅ AES-256-GCM blob encryption with 12-byte IV, 16-byte tag, fresh IV per write
- ✅ `eth-crypto` library identified as the ECIES choice if ever needed. Not actually used in our hackathon deploy — sealing only matters during real TEE-mediated transfer (which our `MockOracle` deploy doesn't do), and we don't seal at mint. Reference is informational for future work.
- ✅ `keccak256(ciphertext)` for the on-chain hash commitment (interpretation; verify with Discord if uncertain)
- ✅ `mint()` access control: deployer-only for hackathon (single deployer mints all 4 clans)
- ✅ Single deployment for hackathon — no migration plan for redeploys
- ✅ Cross-chain binding: orchestrator config holds iNFT contract address; game contract holds only `iftTokenId`

Soft:

- ⚠️ Hash commitment interpretation (plaintext vs ciphertext) — verify with Discord before committing to docs
- ⚠️ `mint()` access control — could be opened up if we want self-service mint flow; default to deployer-only

Open:

- ❓ Whether the reference impl's recent `main` branch differs materially from the older `eip-7857-draft` branch (the EIP still references the draft branch). Resolution: read the diff, default to `main`.
- ❓ Whether `AgentNFT` proxy is a UUPS or Transparent proxy — affects how upgrades work post-deployment. We don't plan to upgrade during hackathon, so deferred.
- ❓ Whether 0G Storage SDK's `Indexer.upload()` returns a usable URI directly or just a root hash that we have to format ourselves. Resolved during implementation.

Explicit non-goals:

- ❌ Building a custom contract from the EIP spec
- ❌ Implementing `authorizeUsage()` flow
- ❌ Real TEE oracle deployment (MockOracle only)
- ❌ Cryptographically-secured transfer flow (MockOracle accepts any proof; the demo transfer is contrived for narrative only)
- ❌ Upgrade or migration tooling
- ❌ Multi-deployer / governance / admin keys beyond a single deployer wallet

---

## 10. Glossary (incremental — see other specs for full)

- **AgentNFT** — the user-facing ERC-7857 contract (proxy address). Same role as "iNFT" / "ERC-7857 contract" in other docs; this is the on-chain name.
- **AgentNFTImpl** — implementation contract behind the AgentNFT proxy. Don't reference directly.
- **TEEVerifier** — the oracle contract. We deploy MockOracle in its place for hackathon.
- **MockOracle** — simpler oracle from the reference impl that returns true on any proof. Used in our deploy in place of `TEEVerifier` for the contrived demo transfer (and for `updateMetadata()` paths, which don't call the oracle anyway). Doesn't enforce any cryptographic guarantee on transfer proofs.
- **DEK** — Data Encryption Key, 32-byte AES-256 key (defined in ClanIdentity spec).
- **iftTokenId** — the field on the game contract's `Clan` struct that stores the AgentNFT token id.
